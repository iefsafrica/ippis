// User roles
export type UserRole = "super_admin" | "admin" | "editor" | "viewer" | string

// Permissions
export type Permission =
  | "view_employees"
  | "create_employees"
  | "edit_employees"
  | "delete_employees"
  | "approve_employees"
  | "reject_employees"
  | "view_documents"
  | "upload_documents"
  | "verify_documents"
  | "reject_documents"
  | "manage_roles"
  | "view_reports"
  | "export_data"
  | "manage_settings"
  | "backup_database"
  | "import_data"

// Role definition
export interface Role {
  id: UserRole
  name: string
  description: string
  permissions: Permission[]
  isDefault?: boolean
}

// User definition
export interface AuthUser {
  id: string
  name: string
  username: string // Added username field
  email: string
  role: UserRole
  department?: string
  avatar?: string
  lastLogin?: Date | string
  permissions?: Permission[]
}

// Auth context state
export interface AuthState {
  user: AuthUser | null
  isAuthenticated: boolean
  isLoading: boolean
}
