"use client"

import { useEffect, useState } from "react"
import { Label } from "@/components/ui/label"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { FileUploader } from "./file-uploader"
import { EnhancedImageUploader } from "./enhanced-image-uploader"
import { X } from "lucide-react"
import { DocumentService } from "../admin/services/document-service"
import { useToast } from "@/hooks/use-toast"

interface DocumentUploadStepProps {
  formData: any
  updateFormData: (data: any) => void
  validateStep: (step: number, isValid: boolean) => void
}

export function DocumentUploadStep({ formData, updateFormData, validateStep }: DocumentUploadStepProps) {
  const { toast } = useToast()

  // For testing purposes, we'll create mock files
  const createMockFile = (name: string) => {
    // Create a mock file object
    const file = new File(["dummy content"], name, {
      type: name.endsWith(".pdf") ? "application/pdf" : "image/jpeg",
    })
    return file
  }

  const [files, setFiles] = useState({
    appointmentLetter: formData.appointmentLetter || createMockFile("appointment_letter.pdf"),
    educationalCertificates: formData.educationalCertificates || createMockFile("educational_certificates.pdf"),
    promotionLetter: formData.promotionLetter || createMockFile("promotion_letter.pdf"),
    otherDocuments: formData.otherDocuments || createMockFile("other_documents.pdf"),
    profileImage: formData.profileImage || createMockFile("profile_image.jpg"),
    signature: formData.signature || createMockFile("signature.jpg"),
  })

  const [errors, setErrors] = useState<Record<string, string>>({})
  const [uploading, setUploading] = useState(false)
  const [documentsUploaded, setDocumentsUploaded] = useState(false)

  // Auto-validate the step for testing purposes
  useEffect(() => {
    // For testing purposes, we'll consider the step valid
    validateStep(4, true)

    // Update parent form data
    updateFormData({ ...formData, ...files })
  }, [files, validateStep, updateFormData, formData])

  const handleFileChange = (field: string, file: File) => {
    setFiles((prev) => ({ ...prev, [field]: file }))
  }

  const removeFile = (field: string) => {
    setFiles((prev) => ({ ...prev, [field]: null }))
  }

  // This function would be called when the form is submitted
  const handleUploadDocuments = async () => {
    if (!formData.id) {
      // Generate a temporary ID for testing if none exists
      const tempId = "TEMP" + Math.floor(Math.random() * 900000 + 100000)
      updateFormData({ ...formData, id: tempId })

      toast({
        title: "Info",
        description:
          "Using temporary ID for document upload. Documents will be linked to your registration when submitted.",
      })
    }

    setUploading(true)

    try {
      // In a real app, this would upload the files to a server
      // Here we're just simulating the process with our mock service
      await DocumentService.addDocumentsFromRegistration(
        formData.id || "TEMP" + Math.floor(Math.random() * 900000 + 100000),
        `${formData.firstName} ${formData.lastName}`,
        files,
      )

      setDocumentsUploaded(true)

      toast({
        title: "Success",
        description: "Documents uploaded successfully and pending verification.",
      })
    } catch (error) {
      console.error("Error uploading documents:", error)
      toast({
        title: "Error",
        description: "Failed to upload documents. Please try again.",
        variant: "destructive",
      })
    } finally {
      setUploading(false)
    }
  }

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold text-green-700 mb-6">Step 4: Document Upload</h2>
        <p className="text-gray-600 mb-4">
          Please upload the required documents. All files must be in PDF, JPG, or PNG format and not exceed 20MB in
          size.
        </p>
      </div>

      <Card className="border-red-200">
        <CardContent className="pt-6">
          <div className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="appointmentLetter">Appointment Letter (20MB)*</Label>
              {files.appointmentLetter ? (
                <div className="flex items-center justify-between p-3 border rounded-md bg-green-50 border-green-200">
                  <span className="text-sm">{files.appointmentLetter.name}</span>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => removeFile("appointmentLetter")}
                    className="h-8 w-8 p-0"
                  >
                    <X className="h-4 w-4" />
                    <span className="sr-only">Remove</span>
                  </Button>
                </div>
              ) : (
                <FileUploader
                  onFileSelect={(file) => handleFileChange("appointmentLetter", file)}
                  accept=".pdf,.jpg,.jpeg,.png"
                  maxSize={20 * 1024 * 1024} // 20MB
                  error={errors.appointmentLetter}
                />
              )}
              {errors.appointmentLetter && <p className="text-red-500 text-xs mt-1">{errors.appointmentLetter}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="educationalCertificates">Educational Certificates (20MB)*</Label>
              {files.educationalCertificates ? (
                <div className="flex items-center justify-between p-3 border rounded-md bg-green-50 border-green-200">
                  <span className="text-sm">{files.educationalCertificates.name}</span>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => removeFile("educationalCertificates")}
                    className="h-8 w-8 p-0"
                  >
                    <X className="h-4 w-4" />
                    <span className="sr-only">Remove</span>
                  </Button>
                </div>
              ) : (
                <FileUploader
                  onFileSelect={(file) => handleFileChange("educationalCertificates", file)}
                  accept=".pdf,.jpg,.jpeg,.png"
                  maxSize={20 * 1024 * 1024} // 20MB
                  error={errors.educationalCertificates}
                />
              )}
              {errors.educationalCertificates && (
                <p className="text-red-500 text-xs mt-1">{errors.educationalCertificates}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="promotionLetter">Letter of Last Promotion (20MB)*</Label>
              {files.promotionLetter ? (
                <div className="flex items-center justify-between p-3 border rounded-md bg-green-50 border-green-200">
                  <span className="text-sm">{files.promotionLetter.name}</span>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => removeFile("promotionLetter")}
                    className="h-8 w-8 p-0"
                  >
                    <X className="h-4 w-4" />
                    <span className="sr-only">Remove</span>
                  </Button>
                </div>
              ) : (
                <FileUploader
                  onFileSelect={(file) => handleFileChange("promotionLetter", file)}
                  accept=".pdf,.jpg,.jpeg,.png"
                  maxSize={20 * 1024 * 1024} // 20MB
                  error={errors.promotionLetter}
                />
              )}
              {errors.promotionLetter && <p className="text-red-500 text-xs mt-1">{errors.promotionLetter}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="otherDocuments">Other Documents (20MB)*</Label>
              {files.otherDocuments ? (
                <div className="flex items-center justify-between p-3 border rounded-md bg-green-50 border-green-200">
                  <span className="text-sm">{files.otherDocuments.name}</span>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => removeFile("otherDocuments")}
                    className="h-8 w-8 p-0"
                  >
                    <X className="h-4 w-4" />
                    <span className="sr-only">Remove</span>
                  </Button>
                </div>
              ) : (
                <FileUploader
                  onFileSelect={(file) => handleFileChange("otherDocuments", file)}
                  accept=".pdf,.jpg,.jpeg,.png"
                  maxSize={20 * 1024 * 1024} // 20MB
                  error={errors.otherDocuments}
                />
              )}
              {errors.otherDocuments && <p className="text-red-500 text-xs mt-1">{errors.otherDocuments}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="profileImage">Profile Image (20MB)*</Label>
              <EnhancedImageUploader
                onImageSelect={(file) => handleFileChange("profileImage", file)}
                currentImage={files.profileImage}
                onRemove={() => removeFile("profileImage")}
                label="Profile Image"
                accept=".jpg,.jpeg,.png"
                maxSize={20 * 1024 * 1024} // 20MB
                error={errors.profileImage}
              />
              {errors.profileImage && <p className="text-red-500 text-xs mt-1">{errors.profileImage}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="signature">Signature (20MB)*</Label>
              <EnhancedImageUploader
                onImageSelect={(file) => handleFileChange("signature", file)}
                currentImage={files.signature}
                onRemove={() => removeFile("signature")}
                label="Signature"
                accept=".jpg,.jpeg,.png"
                maxSize={20 * 1024 * 1024} // 20MB
                error={errors.signature}
              />
              {errors.signature && <p className="text-red-500 text-xs mt-1">{errors.signature}</p>}
            </div>

            <Button
              type="button"
              className={`w-full ${documentsUploaded ? "bg-green-500 hover:bg-green-600" : "bg-green-700 hover:bg-green-800"}`}
              onClick={handleUploadDocuments}
              disabled={uploading}
            >
              {uploading ? "Uploading..." : documentsUploaded ? "✓ Documents Uploaded" : "Upload Documents"}
            </Button>
          </div>
        </CardContent>
      </Card>

      <div className="bg-yellow-50 border border-yellow-200 rounded-md p-4">
        <h3 className="text-sm font-medium text-yellow-800">Document Guidelines</h3>
        <p className="text-sm text-yellow-700 mt-1">
          All documents must be clear and legible. For testing purposes, we've pre-filled the form with mock documents.
          After uploading, documents will be sent for verification in the admin dashboard.
        </p>
      </div>
    </div>
  )
}
