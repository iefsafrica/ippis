"use client"

import { useState, useRef, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { FileUploader } from "./file-uploader"
import { X, Camera, Upload, ImageIcon } from "lucide-react"
import Webcam from "react-webcam"

interface EnhancedImageUploaderProps {
  onImageSelect: (file: File) => void
  currentImage: File | null
  onRemove: () => void
  label: string
  accept?: string
  maxSize?: number
  error?: string
}

export function EnhancedImageUploader({
  onImageSelect,
  currentImage,
  onRemove,
  label,
  accept = ".jpg,.jpeg,.png",
  maxSize = 20 * 1024 * 1024,
  error,
}: EnhancedImageUploaderProps) {
  const [activeTab, setActiveTab] = useState<string>("upload")
  const webcamRef = useRef<Webcam>(null)
  const [isCameraReady, setIsCameraReady] = useState(false)
  const [cameraError, setCameraError] = useState<string | null>(null)

  // Function to handle webcam capture
  const capturePhoto = useCallback(() => {
    if (webcamRef.current) {
      const imageSrc = webcamRef.current.getScreenshot()
      if (imageSrc) {
        // Convert base64 to blob
        fetch(imageSrc)
          .then((res) => res.blob())
          .then((blob) => {
            // Create a File object from the blob
            const file = new File([blob], `${label.toLowerCase().replace(/\s+/g, "-")}-webcam.jpg`, {
              type: "image/jpeg",
            })
            onImageSelect(file)
            setActiveTab("preview")
          })
          .catch((err) => {
            console.error("Error converting webcam image:", err)
            setCameraError("Failed to process webcam image. Please try again.")
          })
      }
    }
  }, [webcamRef, label, onImageSelect])

  // If we already have an image, show the preview
  if (currentImage) {
    return (
      <div className="flex items-center justify-between p-3 border rounded-md bg-green-50 border-green-200">
        <div className="flex items-center gap-3">
          <img
            src={URL.createObjectURL(currentImage) || "/placeholder.svg"}
            alt={`${label} preview`}
            className="h-16 w-16 object-cover rounded-md"
          />
          <span className="text-sm">{currentImage.name}</span>
        </div>
        <Button variant="ghost" size="sm" onClick={onRemove} className="h-8 w-8 p-0">
          <X className="h-4 w-4" />
          <span className="sr-only">Remove</span>
        </Button>
      </div>
    )
  }

  return (
    <Card className="p-0 overflow-hidden">
      <Tabs defaultValue="upload" value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="w-full grid grid-cols-3">
          <TabsTrigger value="upload" className="flex items-center gap-1">
            <Upload className="h-4 w-4" />
            <span>Upload</span>
          </TabsTrigger>
          <TabsTrigger value="camera" className="flex items-center gap-1">
            <Camera className="h-4 w-4" />
            <span>Camera</span>
          </TabsTrigger>
          <TabsTrigger value="dragdrop" className="flex items-center gap-1">
            <ImageIcon className="h-4 w-4" />
            <span>Drag & Drop</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="upload" className="p-4">
          <FileUploader onFileSelect={onImageSelect} accept={accept} maxSize={maxSize} error={error} />
        </TabsContent>

        <TabsContent value="camera" className="p-4">
          <div className="space-y-4">
            <div className="relative bg-black rounded-md overflow-hidden">
              <Webcam
                audio={false}
                ref={webcamRef}
                screenshotFormat="image/jpeg"
                videoConstraints={{
                  width: 480,
                  height: 360,
                  facingMode: "user",
                }}
                onUserMedia={() => {
                  setIsCameraReady(true)
                  setCameraError(null)
                }}
                onUserMediaError={(err) => {
                  console.error("Webcam error:", err)
                  setCameraError("Could not access camera. Please ensure you have granted camera permissions.")
                  setIsCameraReady(false)
                }}
                className="w-full rounded-md"
              />
              {!isCameraReady && !cameraError && (
                <div className="absolute inset-0 flex items-center justify-center bg-gray-900 bg-opacity-75 text-white">
                  <p>Initializing camera...</p>
                </div>
              )}
              {cameraError && (
                <div className="absolute inset-0 flex items-center justify-center bg-gray-900 bg-opacity-75 text-white p-4">
                  <p className="text-center">{cameraError}</p>
                </div>
              )}
            </div>
            <Button
              onClick={capturePhoto}
              disabled={!isCameraReady || !!cameraError}
              className="w-full"
              variant="default"
            >
              <Camera className="h-4 w-4 mr-2" />
              Capture Photo
            </Button>
          </div>
        </TabsContent>

        <TabsContent value="dragdrop" className="p-4">
          <div
            className="border-2 border-dashed rounded-md p-6 text-center cursor-pointer transition-colors border-gray-300 hover:border-gray-400 h-48 flex flex-col items-center justify-center"
            onDragOver={(e) => {
              e.preventDefault()
              e.stopPropagation()
              e.currentTarget.classList.add("border-green-500", "bg-green-50")
            }}
            onDragLeave={(e) => {
              e.preventDefault()
              e.stopPropagation()
              e.currentTarget.classList.remove("border-green-500", "bg-green-50")
            }}
            onDrop={(e) => {
              e.preventDefault()
              e.stopPropagation()
              e.currentTarget.classList.remove("border-green-500", "bg-green-50")

              if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
                const file = e.dataTransfer.files[0]
                // Check file type
                if (accept !== "*") {
                  const acceptedTypes = accept.split(",").map((type) => type.trim())
                  const fileExtension = `.${file.name.split(".").pop()?.toLowerCase()}`
                  const fileType = file.type

                  const isAccepted = acceptedTypes.some((type) => {
                    if (type.startsWith(".")) {
                      return fileExtension === type.toLowerCase()
                    } else {
                      return fileType.match(new RegExp(type.replace("*", ".*")))
                    }
                  })

                  if (!isAccepted) {
                    alert(`File type not accepted. Please upload ${accept} files.`)
                    return
                  }
                }

                // Check file size
                if (file.size > maxSize) {
                  alert(`File size exceeds ${maxSize / (1024 * 1024)}MB limit.`)
                  return
                }

                onImageSelect(file)
              }
            }}
          >
            <ImageIcon className="h-12 w-12 text-gray-400 mb-2" />
            <p className="text-sm text-gray-600 mb-1">Drag and drop your image here</p>
            <p className="text-xs text-gray-500">
              {accept !== "*" ? `Accepted formats: ${accept}` : "All image types accepted"} (Max size:{" "}
              {maxSize / (1024 * 1024)}
              MB)
            </p>
          </div>
        </TabsContent>
      </Tabs>
      {error && <p className="text-red-500 text-xs mt-2 px-4 pb-4">{error}</p>}
    </Card>
  )
}
