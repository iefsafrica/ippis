"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent } from "@/components/ui/card"
import { CheckCircle2, Loader2 } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface VerificationStepProps {
  formData: any
  updateFormData: (data: any) => void
  validateStep: (step: number, isValid: boolean) => void
}

export function VerificationStep({ formData, updateFormData, validateStep }: VerificationStepProps) {
  const { toast } = useToast()
  const [bvnInput, setBvnInput] = useState(formData.bvn || "12345678901")
  const [ninInput, setNinInput] = useState(formData.nin || "12345678901")
  const [verifyingBvn, setVerifyingBvn] = useState(false)
  const [verifyingNin, setVerifyingNin] = useState(false)

  // Pre-set to true for demo purposes
  const [bvnVerified, setBvnVerified] = useState(true)
  const [ninVerified, setNinVerified] = useState(true)

  // Immediately validate the step (for demo purposes)
  if (!formData.bvnVerified || !formData.ninVerified) {
    // Only update once to avoid loops
    setTimeout(() => {
      updateFormData({
        bvn: bvnInput,
        bvnVerified: true,
        nin: ninInput,
        ninVerified: true,
      })
      validateStep(1, true)
    }, 0)
  }

  const handleVerifyBvn = () => {
    setVerifyingBvn(true)

    // Simulate verification
    setTimeout(() => {
      setBvnVerified(true)
      setVerifyingBvn(false)

      updateFormData({
        bvn: bvnInput,
        bvnVerified: true,
      })

      toast({
        title: "BVN Verified",
        description: "Your BVN has been successfully verified.",
      })

      validateStep(1, true)
    }, 1000)
  }

  const handleVerifyNin = () => {
    setVerifyingNin(true)

    // Simulate verification
    setTimeout(() => {
      setNinVerified(true)
      setVerifyingNin(false)

      updateFormData({
        nin: ninInput,
        ninVerified: true,
      })

      toast({
        title: "NIN Verified",
        description: "Your NIN has been successfully verified.",
      })

      validateStep(1, true)
    }, 1000)
  }

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold text-green-700 mb-6">Step 1: Verification</h2>
        <p className="text-gray-600 mb-4">
          Please provide your BVN and NIN for verification. These will be used to validate your identity.
        </p>
      </div>

      <Card className="border-red-200">
        <CardContent className="pt-6">
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="bvn">Bank Verification Number (BVN)*</Label>
              <div className="flex gap-2">
                <Input
                  id="bvn"
                  type="text"
                  placeholder="Enter your 11-digit BVN"
                  value={bvnInput}
                  onChange={(e) => setBvnInput(e.target.value)}
                  maxLength={11}
                  className={bvnVerified ? "border-green-500" : ""}
                />
                <Button
                  type="button"
                  onClick={handleVerifyBvn}
                  disabled={verifyingBvn || bvnVerified}
                  className="bg-green-700 hover:bg-green-800 whitespace-nowrap"
                >
                  {verifyingBvn ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Verifying
                    </>
                  ) : bvnVerified ? (
                    <>
                      <CheckCircle2 className="mr-2 h-4 w-4" /> Verified
                    </>
                  ) : (
                    "Verify BVN"
                  )}
                </Button>
              </div>
              {bvnVerified && (
                <div className="flex items-center text-green-600 text-sm mt-1">
                  <CheckCircle2 className="mr-1 h-4 w-4" /> BVN verified successfully
                </div>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="nin">National Identification Number (NIN)*</Label>
              <div className="flex gap-2">
                <Input
                  id="nin"
                  type="text"
                  placeholder="Enter your 11-digit NIN"
                  value={ninInput}
                  onChange={(e) => setNinInput(e.target.value)}
                  maxLength={11}
                  className={ninVerified ? "border-green-500" : ""}
                />
                <Button
                  type="button"
                  onClick={handleVerifyNin}
                  disabled={verifyingNin || ninVerified}
                  className="bg-green-700 hover:bg-green-800 whitespace-nowrap"
                >
                  {verifyingNin ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Verifying
                    </>
                  ) : ninVerified ? (
                    <>
                      <CheckCircle2 className="mr-2 h-4 w-4" /> Verified
                    </>
                  ) : (
                    "Verify NIN"
                  )}
                </Button>
              </div>
              {ninVerified && (
                <div className="flex items-center text-green-600 text-sm mt-1">
                  <CheckCircle2 className="mr-1 h-4 w-4" /> NIN verified successfully
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="bg-yellow-50 border border-yellow-200 rounded-md p-4">
        <h3 className="text-sm font-medium text-yellow-800">Important Information</h3>
        <p className="text-sm text-yellow-700 mt-1">
          Both BVN and NIN verification are required to proceed with your IPPIS registration. Please ensure that you
          provide accurate information as it will be cross-checked with government databases.
        </p>
      </div>
    </div>
  )
}
