"use client"

import { useEffect, useState } from "react"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent } from "@/components/ui/card"
import { nigerianStates, getLgasByState } from "./nigeria-data"

interface PersonalInfoStepProps {
  formData: any
  updateFormData: (data: any) => void
  validateStep: (step: number, isValid: boolean) => void
}

export function PersonalInfoStep({ formData, updateFormData, validateStep }: PersonalInfoStepProps) {
  const [formState, setFormState] = useState({
    title: formData.title || "Mr",
    surname: formData.surname || "Doe",
    firstName: formData.firstName || "John",
    otherNames: formData.otherNames || "",
    phoneNumber: formData.phoneNumber || "08012345678",
    email: formData.email || "john.doe@example.com",
    dateOfBirth: formData.dateOfBirth || "1990-01-01",
    sex: formData.sex || "Male",
    maritalStatus: formData.maritalStatus || "Single",
    stateOfOrigin: formData.stateOfOrigin || "Lagos",
    lga: formData.lga || "",
    stateOfResidence: formData.stateOfResidence || "Lagos",
    addressStateOfResidence: formData.addressStateOfResidence || "123 Main Street, Lagos",
    nextOfKinName: formData.nextOfKinName || "Jane Doe",
    nextOfKinRelationship: formData.nextOfKinRelationship || "Spouse",
    nextOfKinPhoneNumber: formData.nextOfKinPhoneNumber || "08087654321",
    nextOfKinAddress: formData.nextOfKinAddress || "456 Side Street, Lagos",
  })

  const [errors, setErrors] = useState({})
  const [availableLgas, setAvailableLgas] = useState([])

  useEffect(() => {
    if (formState.stateOfOrigin) {
      const lgas = getLgasByState(formState.stateOfOrigin)
      setAvailableLgas(lgas)

      // Reset LGA if state changes and set to first available LGA
      if (formState.stateOfOrigin !== formData.stateOfOrigin) {
        setFormState((prev) => ({ ...prev, lga: lgas.length > 0 ? lgas[0] : "" }))
      }
    }
  }, [formState.stateOfOrigin, formData.stateOfOrigin])

  // Auto-validate the step for testing purposes
  useEffect(() => {
    // For testing purposes, we'll consider the step valid
    validateStep(2, true)

    // Update parent form data
    updateFormData(formState)
  }, [formState, validateStep, updateFormData])

  const handleChange = (field, value) => {
    setFormState((prev) => ({ ...prev, [field]: value }))
  }

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold text-green-700 mb-6">Step 2: Personal Information</h2>
        <p className="text-gray-600 mb-4">
          Please provide your personal details. All fields marked with an asterisk (*) are required.
        </p>
      </div>

      <Card className="border-red-200">
        <CardContent className="pt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="title">Title*</Label>
              <Select value={formState.title} onValueChange={(value) => handleChange("title", value)}>
                <SelectTrigger id="title" className={errors.title ? "border-red-500" : ""}>
                  <SelectValue placeholder="Select title" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Mr">Mr</SelectItem>
                  <SelectItem value="Mrs">Mrs</SelectItem>
                  <SelectItem value="Miss">Miss</SelectItem>
                  <SelectItem value="Dr">Dr</SelectItem>
                  <SelectItem value="Prof">Prof</SelectItem>
                  <SelectItem value="Chief">Chief</SelectItem>
                </SelectContent>
              </Select>
              {errors.title && <p className="text-red-500 text-xs mt-1">{errors.title}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="surname">Surname*</Label>
              <Input
                id="surname"
                value={formState.surname}
                onChange={(e) => handleChange("surname", e.target.value)}
                className={errors.surname ? "border-red-500" : ""}
              />
              {errors.surname && <p className="text-red-500 text-xs mt-1">{errors.surname}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="firstName">First Name*</Label>
              <Input
                id="firstName"
                value={formState.firstName}
                onChange={(e) => handleChange("firstName", e.target.value)}
                className={errors.firstName ? "border-red-500" : ""}
              />
              {errors.firstName && <p className="text-red-500 text-xs mt-1">{errors.firstName}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="otherNames">Other Names</Label>
              <Input
                id="otherNames"
                value={formState.otherNames}
                onChange={(e) => handleChange("otherNames", e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="phoneNumber">Contact Phone Number*</Label>
              <Input
                id="phoneNumber"
                value={formState.phoneNumber}
                onChange={(e) => handleChange("phoneNumber", e.target.value)}
                maxLength={11}
                className={errors.phoneNumber ? "border-red-500" : ""}
              />
              {errors.phoneNumber && <p className="text-red-500 text-xs mt-1">{errors.phoneNumber}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">E-mail Address*</Label>
              <Input
                id="email"
                type="email"
                value={formState.email}
                onChange={(e) => handleChange("email", e.target.value)}
                className={errors.email ? "border-red-500" : ""}
              />
              {errors.email && <p className="text-red-500 text-xs mt-1">{errors.email}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="dateOfBirth">Date of Birth*</Label>
              <Input
                id="dateOfBirth"
                type="date"
                value={formState.dateOfBirth}
                onChange={(e) => handleChange("dateOfBirth", e.target.value)}
                className={errors.dateOfBirth ? "border-red-500" : ""}
                max={new Date().toISOString().split("T")[0]}
              />
              {errors.dateOfBirth && <p className="text-red-500 text-xs mt-1">{errors.dateOfBirth}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="sex">Sex*</Label>
              <Select value={formState.sex} onValueChange={(value) => handleChange("sex", value)}>
                <SelectTrigger id="sex" className={errors.sex ? "border-red-500" : ""}>
                  <SelectValue placeholder="Select gender" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Male">Male</SelectItem>
                  <SelectItem value="Female">Female</SelectItem>
                </SelectContent>
              </Select>
              {errors.sex && <p className="text-red-500 text-xs mt-1">{errors.sex}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="maritalStatus">Marital Status*</Label>
              <Select value={formState.maritalStatus} onValueChange={(value) => handleChange("maritalStatus", value)}>
                <SelectTrigger id="maritalStatus" className={errors.maritalStatus ? "border-red-500" : ""}>
                  <SelectValue placeholder="Select marital status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Single">Single</SelectItem>
                  <SelectItem value="Married">Married</SelectItem>
                  <SelectItem value="Divorced">Divorced</SelectItem>
                  <SelectItem value="Widowed">Widowed</SelectItem>
                </SelectContent>
              </Select>
              {errors.maritalStatus && <p className="text-red-500 text-xs mt-1">{errors.maritalStatus}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="stateOfOrigin">State of Origin*</Label>
              <Select value={formState.stateOfOrigin} onValueChange={(value) => handleChange("stateOfOrigin", value)}>
                <SelectTrigger id="stateOfOrigin" className={errors.stateOfOrigin ? "border-red-500" : ""}>
                  <SelectValue placeholder="Select state" />
                </SelectTrigger>
                <SelectContent>
                  {nigerianStates.map((state) => (
                    <SelectItem key={state} value={state}>
                      {state}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {errors.stateOfOrigin && <p className="text-red-500 text-xs mt-1">{errors.stateOfOrigin}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="lga">Local Government Area*</Label>
              <Select
                value={formState.lga}
                onValueChange={(value) => handleChange("lga", value)}
                disabled={!formState.stateOfOrigin}
              >
                <SelectTrigger id="lga" className={errors.lga ? "border-red-500" : ""}>
                  <SelectValue placeholder="Select LGA" />
                </SelectTrigger>
                <SelectContent>
                  {availableLgas.map((lga) => (
                    <SelectItem key={lga} value={lga}>
                      {lga}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {errors.lga && <p className="text-red-500 text-xs mt-1">{errors.lga}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="stateOfResidence">State of Residence*</Label>
              <Select
                value={formState.stateOfResidence}
                onValueChange={(value) => handleChange("stateOfResidence", value)}
              >
                <SelectTrigger id="stateOfResidence" className={errors.stateOfResidence ? "border-red-500" : ""}>
                  <SelectValue placeholder="Select state" />
                </SelectTrigger>
                <SelectContent>
                  {nigerianStates.map((state) => (
                    <SelectItem key={state} value={state}>
                      {state}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {errors.stateOfResidence && <p className="text-red-500 text-xs mt-1">{errors.stateOfResidence}</p>}
            </div>

            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="addressStateOfResidence">Address in State of Residence*</Label>
              <Textarea
                id="addressStateOfResidence"
                value={formState.addressStateOfResidence}
                onChange={(e) => handleChange("addressStateOfResidence", e.target.value)}
                className={errors.addressStateOfResidence ? "border-red-500" : ""}
                rows={3}
              />
              {errors.addressStateOfResidence && (
                <p className="text-red-500 text-xs mt-1">{errors.addressStateOfResidence}</p>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="border-red-200">
        <CardContent className="pt-6">
          <h3 className="text-lg font-semibold mb-4">Next of Kin Information</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="nextOfKinName">Next of Kin Name*</Label>
              <Input
                id="nextOfKinName"
                value={formState.nextOfKinName}
                onChange={(e) => handleChange("nextOfKinName", e.target.value)}
                className={errors.nextOfKinName ? "border-red-500" : ""}
              />
              {errors.nextOfKinName && <p className="text-red-500 text-xs mt-1">{errors.nextOfKinName}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="nextOfKinRelationship">Next of Kin Relationship*</Label>
              <Select
                value={formState.nextOfKinRelationship}
                onValueChange={(value) => handleChange("nextOfKinRelationship", value)}
              >
                <SelectTrigger
                  id="nextOfKinRelationship"
                  className={errors.nextOfKinRelationship ? "border-red-500" : ""}
                >
                  <SelectValue placeholder="Select relationship" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Spouse">Spouse</SelectItem>
                  <SelectItem value="Parent">Parent</SelectItem>
                  <SelectItem value="Child">Child</SelectItem>
                  <SelectItem value="Sibling">Sibling</SelectItem>
                  <SelectItem value="Other Relative">Other Relative</SelectItem>
                </SelectContent>
              </Select>
              {errors.nextOfKinRelationship && (
                <p className="text-red-500 text-xs mt-1">{errors.nextOfKinRelationship}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="nextOfKinPhoneNumber">Next of Kin Phone Number*</Label>
              <Input
                id="nextOfKinPhoneNumber"
                value={formState.nextOfKinPhoneNumber}
                onChange={(e) => handleChange("nextOfKinPhoneNumber", e.target.value)}
                maxLength={11}
                className={errors.nextOfKinPhoneNumber ? "border-red-500" : ""}
              />
              {errors.nextOfKinPhoneNumber && (
                <p className="text-red-500 text-xs mt-1">{errors.nextOfKinPhoneNumber}</p>
              )}
            </div>

            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="nextOfKinAddress">Next of Kin Address*</Label>
              <Textarea
                id="nextOfKinAddress"
                value={formState.nextOfKinAddress}
                onChange={(e) => handleChange("nextOfKinAddress", e.target.value)}
                className={errors.nextOfKinAddress ? "border-red-500" : ""}
                rows={3}
              />
              {errors.nextOfKinAddress && <p className="text-red-500 text-xs mt-1">{errors.nextOfKinAddress}</p>}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
