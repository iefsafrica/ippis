"use client"

import { useState, useCallback, useEffect } from "react"
import { VerificationStep } from "./verification-step"
import { PersonalInfoStep } from "./personal-info-step"
import { EmploymentInfoStep } from "./employment-info-step"
import { DocumentUploadStep } from "./document-upload-step"
import { PreviewStep } from "./preview-step"
import { StepIndicator } from "./step-indicator"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card"
import { ArrowLeft, ArrowRight, CheckCircle2, Loader2, Home, FileSearch } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import Image from "next/image"
import Link from "next/link"
import { PendingEmployeeService } from "../admin/services/pending-employee-service"
import { DocumentService } from "../admin/services/document-service"

export default function RegisterForm() {
  const { toast } = useToast()
  const [currentStep, setCurrentStep] = useState(1)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)
  const [registrationId, setRegistrationId] = useState("")
  const [mounted, setMounted] = useState(false)

  // Use useEffect to ensure we're only running client-side code after mount
  useEffect(() => {
    setMounted(true)
  }, [])

  const [formData, setFormData] = useState({
    // Verification data
    bvn: "12345678901",
    bvnVerified: true, // Pre-set to true for demo
    nin: "12345678901",
    ninVerified: true, // Pre-set to true for demo

    // Personal information
    title: "Mr",
    surname: "Doe",
    firstName: "John",
    otherNames: "",
    phoneNumber: "08012345678",
    email: "john.doe@example.com",
    dateOfBirth: "1990-01-01",
    sex: "Male",
    maritalStatus: "Single",
    stateOfOrigin: "Lagos",
    lga: "",
    stateOfResidence: "Lagos",
    addressStateOfResidence: "123 Main Street, Lagos",
    nextOfKinName: "Jane Doe",
    nextOfKinRelationship: "Spouse",
    nextOfKinPhoneNumber: "08087654321",
    nextOfKinAddress: "456 Side Street, Lagos",

    // Employment information
    employmentIdNo: "EMP12345",
    serviceNo: "SVC12345",
    fileNo: "FILE12345",
    rankPosition: "Senior Officer",
    department: "Administration",
    organization: "Federal Ministry of Finance",
    employmentType: "Permanent",
    probationPeriod: "6 Months",
    workLocation: "Abuja",
    dateOfFirstAppointment: "2020-01-01",
    gl: "10",
    step: "5",
    salaryStructure: "CONPSS",
    cadre: "Senior",
    nameOfBank: "Access Bank",
    accountNumber: "0123456789",
    pfaName: "ARM Pension",
    rsapin: "PEN123456789012",
    educationalBackground: "BSc Computer Science, University of Lagos, 2015",
    certifications: "Project Management Professional (PMP), 2018",

    // Document uploads
    appointmentLetter: null,
    educationalCertificates: null,
    promotionLetter: null,
    otherDocuments: null,
    profileImage: null,
    signature: null,

    // Declaration
    declaration: false,
  })

  const [stepValidation, setStepValidation] = useState({
    step1Valid: true, // Pre-set to true for demo
    step2Valid: true, // For demo purposes
    step3Valid: true, // For demo purposes
    step4Valid: true, // For demo purposes
    step5Valid: false,
  })

  // Use useCallback to prevent unnecessary re-renders
  const updateFormData = useCallback((data) => {
    setFormData((prevData) => ({ ...prevData, ...data }))
  }, [])

  // Use useCallback to prevent unnecessary re-renders
  const validateStep = useCallback((step, isValid) => {
    setStepValidation((prev) => {
      // Only update if the value is actually changing to avoid unnecessary re-renders
      if (prev[`step${step}Valid`] !== isValid) {
        return { ...prev, [`step${step}Valid`]: isValid }
      }
      return prev
    })
  }, [])

  const nextStep = () => {
    // Check if the current step is valid before proceeding
    const isCurrentStepValid = stepValidation[`step${currentStep}Valid`]

    if (!isCurrentStepValid) {
      toast({
        title: "Please complete this step",
        description: "Please complete all required fields before proceeding.",
        variant: "destructive",
      })
      return
    }

    if (currentStep < 5) {
      setCurrentStep(currentStep + 1)
      window.scrollTo(0, 0)
    }
  }

  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1)
      window.scrollTo(0, 0)
    }
  }

  const handleSubmit = async () => {
    if (!formData.declaration) {
      toast({
        title: "Declaration Required",
        description: "Please agree to the declaration before submitting.",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    try {
      // Generate a random registration ID
      const generatedId = "IPPIS" + Math.floor(Math.random() * 900000 + 100000)
      setRegistrationId(generatedId)

      // Create a pending employee object from the form data
      const pendingEmployee = {
        name: `${formData.title} ${formData.firstName} ${formData.surname}`,
        email: formData.email,
        department: formData.department,
        position: formData.rankPosition,
        status: "pending_approval",
        submissionDate: new Date().toISOString(),
        source: "form",
        missingFields: [],
      }

      // Submit directly using the addPendingEmployee method
      const result = await PendingEmployeeService.addPendingEmployee(pendingEmployee)

      // Now upload documents with the correct employee ID
      if (
        formData.appointmentLetter ||
        formData.educationalCertificates ||
        formData.promotionLetter ||
        formData.otherDocuments ||
        formData.profileImage ||
        formData.signature
      ) {
        try {
          // Create a files object with all the document files
          const files = {
            appointmentLetter: formData.appointmentLetter,
            educationalCertificates: formData.educationalCertificates,
            promotionLetter: formData.promotionLetter,
            otherDocuments: formData.otherDocuments,
            profileImage: formData.profileImage,
            signature: formData.signature,
          }

          // Upload the documents with the correct employee ID
          await DocumentService.addDocumentsFromRegistration(
            result.id, // Use the ID from the newly created employee
            result.name,
            files,
          )

          console.log("Documents uploaded successfully for employee:", result.id)
        } catch (docError) {
          console.error("Error uploading documents:", docError)
          // Continue with registration even if document upload fails
        }
      }

      // Log success message with more details for debugging
      console.log("Registration successful. Details:", {
        id: result.id,
        name: result.name,
        email: result.email,
        department: result.department,
        submissionDate: result.submissionDate,
      })

      // Set submission as complete
      setIsSubmitted(true)
    } catch (error) {
      console.error("Registration submission error:", error)
      toast({
        title: "Submission Error",
        description: "There was a problem submitting your registration. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const renderStep = () => {
    if (!mounted) return null // Don't render steps until client-side

    switch (currentStep) {
      case 1:
        return <VerificationStep formData={formData} updateFormData={updateFormData} validateStep={validateStep} />
      case 2:
        return <PersonalInfoStep formData={formData} updateFormData={updateFormData} validateStep={validateStep} />
      case 3:
        return <EmploymentInfoStep formData={formData} updateFormData={updateFormData} validateStep={validateStep} />
      case 4:
        return <DocumentUploadStep formData={formData} updateFormData={updateFormData} validateStep={validateStep} />
      case 5:
        return <PreviewStep formData={formData} updateFormData={updateFormData} validateStep={validateStep} />
      default:
        return <VerificationStep formData={formData} updateFormData={updateFormData} validateStep={validateStep} />
    }
  }

  const isNextDisabled = () => {
    return !stepValidation[`step${currentStep}Valid`]
  }

  // If not yet client-side rendered, show a simple loading state
  if (!mounted) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-red-50 to-white py-8 px-4">
        <div className="container max-w-5xl mx-auto">
          <div className="h-96 bg-gray-100 rounded-md animate-pulse"></div>
        </div>
      </div>
    )
  }

  // If the form has been submitted, show the success message
  if (isSubmitted) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-red-50 to-white py-8 px-4">
        <div className="container max-w-3xl mx-auto">
          <div className="flex items-center justify-center mb-8">
            <div className="flex items-center gap-2">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Coat_of_arms_of_Nigeria.svg-IFrFqiae8fXtNsVx4Ip0AeHFPjj7Mp.png"
                width={50}
                height={50}
                alt="Coat of Arms of Nigeria"
                className="h-12 w-auto"
              />
              <span className="text-2xl font-bold">IPPIS Registration</span>
            </div>
          </div>

          <Card className="border-green-200 shadow-lg">
            <CardHeader className="bg-green-50 border-b border-green-100">
              <div className="flex items-center justify-center mb-4">
                <div className="bg-green-100 p-3 rounded-full">
                  <CheckCircle2 className="h-12 w-12 text-green-700" />
                </div>
              </div>
              <CardTitle className="text-2xl text-center text-green-700">Registration Successful!</CardTitle>
              <CardDescription className="text-center text-base">
                Thank you for completing your employee registration
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-6 space-y-6">
              <div className="text-center">
                <p className="text-sm text-gray-500 mb-1">Registration ID</p>
                <p className="text-2xl font-bold text-gray-800">{registrationId}</p>
                <p className="text-sm text-gray-500 mt-1">Please save this ID for future reference</p>
              </div>

              <div className="bg-green-50 p-4 rounded-lg border border-green-100">
                <h3 className="font-semibold text-green-800 mb-2">Database Record Created</h3>
                <p className="text-sm text-gray-700">
                  Your registration information has been successfully saved to our database.
                </p>
              </div>

              <div>
                <h3 className="font-semibold mb-2">Next Steps:</h3>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-start">
                    <span className="bg-green-100 p-1 rounded-full mr-2 mt-0.5">
                      <CheckCircle2 className="h-3 w-3 text-green-700" />
                    </span>
                    <span>
                      A confirmation email has been sent to <span className="font-medium">{formData.email}</span> with
                      your registration details.
                    </span>
                  </li>
                  <li className="flex items-start">
                    <span className="bg-green-100 p-1 rounded-full mr-2 mt-0.5">
                      <CheckCircle2 className="h-3 w-3 text-green-700" />
                    </span>
                    <span>
                      Your registration will be reviewed by the HR department. This process typically takes 3-5 business
                      days.
                    </span>
                  </li>
                  <li className="flex items-start">
                    <span className="bg-green-100 p-1 rounded-full mr-2 mt-0.5">
                      <CheckCircle2 className="h-3 w-3 text-green-700" />
                    </span>
                    <span>
                      Please bring original copies of all uploaded documents on your first day for verification.
                    </span>
                  </li>
                </ul>
              </div>

              <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-100">
                <p className="text-sm text-gray-700">
                  <span className="font-semibold">
                    Dear {formData.title} {formData.firstName} {formData.surname},
                  </span>
                  <br />
                  Welcome to the Integrated Payroll and Personnel Information System (IPPIS). Your registration has been
                  received and is being processed. If you have any questions, please contact our support team at
                  support@ippis.gov.ng.
                </p>
              </div>
            </CardContent>
            <CardFooter className="flex flex-col sm:flex-row gap-3 justify-center pt-2 pb-6">
              <Link href="/">
                <Button
                  variant="outline"
                  className="border-green-700 text-green-700 hover:bg-green-50 w-full sm:w-auto"
                >
                  <Home className="mr-2 h-4 w-4" /> Return to Home
                </Button>
              </Link>
              <Link href="/track">
                <Button className="bg-green-700 hover:bg-green-800 w-full sm:w-auto">
                  <FileSearch className="mr-2 h-4 w-4" /> Track Application Status
                </Button>
              </Link>
              <Link href="/admin">
                <Button variant="outline" className="border-blue-700 text-blue-700 hover:bg-blue-50 w-full sm:w-auto">
                  View in Admin Dashboard
                </Button>
              </Link>
            </CardFooter>
          </Card>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-red-50 to-white py-8 px-4">
      <div className="container max-w-5xl mx-auto">
        <div className="flex items-center justify-center mb-8">
          <Link href="/portal" className="flex items-center gap-2">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Coat_of_arms_of_Nigeria.svg-IFrFqiae8fXtNsVx4Ip0AeHFPjj7Mp.png"
              width={50}
              height={50}
              alt="Coat of Arms of Nigeria"
              className="h-12 w-auto"
            />
            <span className="text-2xl font-bold">IPPIS Registration</span>
          </Link>
        </div>

        <Card className="border-gray-200 shadow-md mb-8">
          <CardHeader className="bg-white border-b border-gray-100 pb-4">
            <CardTitle className="text-xl text-green-700 text-center">Employee Registration Form</CardTitle>
            <CardDescription className="text-center">
              Complete the following steps to register as a government employee in the IPPIS system
            </CardDescription>
          </CardHeader>
          <CardContent className="pt-6 pb-0">
            <StepIndicator currentStep={currentStep} />
          </CardContent>
        </Card>

        <Card className="border-gray-200 shadow-md">
          <CardContent className="pt-6">
            {renderStep()}

            <div className="flex justify-between mt-8">
              {currentStep > 1 ? (
                <Button
                  type="button"
                  variant="outline"
                  onClick={prevStep}
                  className="border-green-700 text-green-700 hover:bg-green-50"
                >
                  <ArrowLeft className="mr-2 h-4 w-4" /> Previous
                </Button>
              ) : (
                <div></div>
              )}

              {currentStep < 5 ? (
                <Button
                  type="button"
                  onClick={nextStep}
                  disabled={isNextDisabled()}
                  className="bg-green-700 hover:bg-green-800"
                >
                  Next <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              ) : (
                <Button
                  type="button"
                  onClick={handleSubmit}
                  disabled={isSubmitting || !formData.declaration}
                  className="bg-green-700 hover:bg-green-800"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Submitting
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="mr-2 h-4 w-4" /> Submit Registration
                    </>
                  )}
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
