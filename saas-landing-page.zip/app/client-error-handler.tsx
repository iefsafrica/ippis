"use client"

import { useEffect } from "react"

export default function ClientErrorHandler() {
  useEffect(() => {
    // Handle unhandled promise rejections
    const handleUnhandledRejection = (event: PromiseRejectionEvent) => {
      console.error("Unhandled promise rejection:", event.reason)
      // Prevent the default browser behavior (which would log the error)
      event.preventDefault()
    }

    // Handle runtime errors
    const handleError = (event: ErrorEvent) => {
      console.error("Runtime error caught:", event.error)
      // Prevent the default browser behavior (which would log the error)
      event.preventDefault()
    }

    // Add event listeners
    window.addEventListener("unhandledrejection", handleUnhandledRejection)
    window.addEventListener("error", handleError)

    // Clean up event listeners on unmount
    return () => {
      window.removeEventListener("unhandledrejection", handleUnhandledRejection)
      window.removeEventListener("error", handleError)
    }
  }, [])

  // This component doesn't render anything
  return null
}
