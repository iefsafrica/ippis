"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Menu, FileText } from "lucide-react"

export function MobileNav() {
  const [open, setOpen] = useState(false)

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button variant="ghost" className="md:hidden p-0 w-10 h-10">
          <Menu className="h-6 w-6" />
          <span className="sr-only">Toggle menu</span>
        </Button>
      </SheetTrigger>
      <SheetContent side="left" className="flex flex-col">
        <div className="flex items-center gap-2 mb-8 mt-4">
          <Image
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Coat_of_arms_of_Nigeria.svg-IFrFqiae8fXtNsVx4Ip0AeHFPjj7Mp.png"
            width={30}
            height={30}
            alt="Coat of Arms of Nigeria"
            className="h-8 w-auto"
          />
          <span className="text-xl font-bold">IPPIS</span>
        </div>
        <nav className="flex flex-col gap-4">
          <Link href="/" className="text-base font-medium text-green-700 font-bold" onClick={() => setOpen(false)}>
            Home
          </Link>
          <Link
            href="#features"
            className="text-base font-medium hover:text-green-700 transition-colors"
            onClick={() => setOpen(false)}
          >
            Features
          </Link>
          <Link
            href="#benefits"
            className="text-base font-medium hover:text-green-700 transition-colors"
            onClick={() => setOpen(false)}
          >
            Benefits
          </Link>
          <Link
            href="#testimonials"
            className="text-base font-medium hover:text-green-700 transition-colors"
            onClick={() => setOpen(false)}
          >
            Testimonials
          </Link>
          <Link
            href="#contact"
            className="text-base font-medium hover:text-green-700 transition-colors"
            onClick={() => setOpen(false)}
          >
            Contact
          </Link>
          <Link
            href="/test-form"
            className="flex items-center gap-2 rounded-lg px-3 py-2 text-gray-500 transition-all hover:text-gray-900"
            onClick={() => setOpen(false)}
          >
            <FileText className="h-5 w-5" />
            <span>Test Form</span>
          </Link>
        </nav>
        <div className="mt-auto pt-4 border-t">
          <div className="flex flex-col gap-2">
            <Link
              href="#"
              className="text-sm font-medium hover:underline underline-offset-4"
              onClick={() => setOpen(false)}
            >
              Log in
            </Link>
            <Link href="/portal">
              <Button className="bg-green-700 hover:bg-green-800 w-full" onClick={() => setOpen(false)}>
                Employee Portal
              </Button>
            </Link>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  )
}
