import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Check,
  ChevronRight,
  Database,
  FileText,
  Globe,
  BarChart,
  Shield,
  Users,
  Facebook,
  Twitter,
  Mail,
  Phone,
  ArrowRight,
} from "lucide-react"
// Import the MobileNav component
import { MobileNav } from "./mobile-nav"

// Import the new sections
import { NewsSection } from "./news-section"
import { FaqSection } from "./faq-section"
import { TimelineSection } from "./timeline-section"

export const metadata = {
  title: "IPPIS - Integrated Personnel and Payroll Information System",
  description:
    "The official homepage of Nigeria's Integrated Personnel and Payroll Information System (IPPIS). A centralized platform for managing government employee data and payroll processing.",
}

export default function LandingPage() {
  return (
    <div className="flex min-h-screen flex-col">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-white shadow-sm">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Coat_of_arms_of_Nigeria.svg-IFrFqiae8fXtNsVx4Ip0AeHFPjj7Mp.png"
              width={40}
              height={40}
              alt="Coat of Arms of Nigeria"
              className="h-10 w-auto"
            />
            <span className="text-xl font-bold">IPPIS</span>
          </div>
          <nav className="hidden md:flex gap-8">
            <Link href="/" className="text-sm font-medium text-green-700 font-bold">
              Home
            </Link>
            <Link href="#features" className="text-sm font-medium hover:text-green-700 transition-colors">
              Features
            </Link>
            <Link href="#benefits" className="text-sm font-medium hover:text-green-700 transition-colors">
              Benefits
            </Link>
            <Link href="#testimonials" className="text-sm font-medium hover:text-green-700 transition-colors">
              Testimonials
            </Link>
            <Link href="#contact" className="text-sm font-medium hover:text-green-700 transition-colors">
              Contact
            </Link>
          </nav>
          <div className="flex items-center gap-4">
            <div className="hidden md:block">
              <Link href="/login" className="text-sm font-medium hover:underline underline-offset-4">
                Log in
              </Link>
            </div>
            <Link href="/portal">
              <Button className="hidden md:inline-flex bg-green-700 hover:bg-green-800">Employee Portal</Button>
            </Link>
            <MobileNav />
          </div>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section className="w-full py-20 md:py-28 bg-gradient-to-b from-red-50 to-white">
          <div className="container px-4 md:px-6">
            <div className="grid gap-8 lg:grid-cols-[1fr_400px] lg:gap-12 xl:grid-cols-[1fr_600px]">
              <div className="flex flex-col justify-center space-y-6">
                <div className="space-y-4">
                  <div className="inline-flex items-center rounded-full border border-green-200 bg-green-50 px-3 py-1 text-sm text-green-700">
                    <span className="font-medium">Federal Government of Nigeria</span>
                  </div>
                  <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none">
                    Integrated Personnel and Payroll Information System
                  </h1>
                  <p className="max-w-[600px] text-gray-600 md:text-xl">
                    A centralized, efficient, and secure platform for managing government employee data, payroll
                    processing, and personnel information.
                  </p>
                </div>
                <div className="flex flex-col gap-3 min-[400px]:flex-row">
                  <Link href="/portal">
                    <Button size="lg" className="bg-green-700 hover:bg-green-800">
                      Access Portal
                      <ChevronRight className="ml-2 h-4 w-4" />
                    </Button>
                  </Link>
                </div>
                <div className="flex items-center space-x-4 text-sm">
                  <div className="text-gray-500">
                    Trusted by <span className="font-medium text-gray-700">government agencies</span> nationwide
                  </div>
                </div>
              </div>
              <div className="relative mx-auto aspect-video overflow-hidden rounded-xl sm:w-full lg:order-last">
                <div className="absolute inset-0 bg-gradient-to-r from-green-50 to-red-50 opacity-30 rounded-xl"></div>
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Coat_of_arms_of_Nigeria.svg-IFrFqiae8fXtNsVx4Ip0AeHFPjj7Mp.png"
                  width={550}
                  height={550}
                  alt="Coat of Arms of Nigeria"
                  className="mx-auto h-full w-auto object-contain p-8"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Stats Section */}
        <section className="w-full py-12 bg-white border-y border-gray-100">
          <div className="container px-4 md:px-6">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
              <div className="space-y-2">
                <h3 className="text-3xl font-bold text-green-700">2.1M+</h3>
                <p className="text-sm text-gray-500">Employees Registered</p>
              </div>
              <div className="space-y-2">
                <h3 className="text-3xl font-bold text-green-700">800+</h3>
                <p className="text-sm text-gray-500">Government MDAs</p>
              </div>
              <div className="space-y-2">
                <h3 className="text-3xl font-bold text-green-700">₦120B+</h3>
                <p className="text-sm text-gray-500">Monthly Payroll</p>
              </div>
              <div className="space-y-2">
                <h3 className="text-3xl font-bold text-green-700">15+</h3>
                <p className="text-sm text-gray-500">Years of Service</p>
              </div>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section id="features" className="w-full py-20 bg-gray-50">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
              <div className="inline-flex items-center rounded-full border border-green-200 bg-green-50 px-3 py-1 text-sm text-green-700">
                <span className="font-medium">Core Features</span>
              </div>
              <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">Comprehensive Payroll Management</h2>
              <p className="max-w-[900px] text-gray-600 md:text-xl">
                IPPIS provides a robust platform for managing personnel data, processing payroll, and ensuring accurate
                and timely payments for all government employees.
              </p>
            </div>
            <div className="mx-auto grid max-w-5xl items-center gap-6 md:grid-cols-2 lg:grid-cols-3">
              <Card className="border-gray-200 shadow-sm hover:shadow-md transition-shadow">
                <CardHeader className="pb-2">
                  <div className="w-12 h-12 rounded-lg bg-green-100 flex items-center justify-center mb-3">
                    <Database className="h-6 w-6 text-green-700" />
                  </div>
                  <CardTitle className="text-xl">Centralized Database</CardTitle>
                  <CardDescription className="text-gray-600">
                    Secure storage of all employee records in a single, accessible system.
                  </CardDescription>
                </CardHeader>
              </Card>
              <Card className="border-gray-200 shadow-sm hover:shadow-md transition-shadow">
                <CardHeader className="pb-2">
                  <div className="w-12 h-12 rounded-lg bg-green-100 flex items-center justify-center mb-3">
                    <Shield className="h-6 w-6 text-green-700" />
                  </div>
                  <CardTitle className="text-xl">Enhanced Security</CardTitle>
                  <CardDescription className="text-gray-600">
                    Advanced encryption and multi-factor authentication to protect sensitive data.
                  </CardDescription>
                </CardHeader>
              </Card>
              <Card className="border-gray-200 shadow-sm hover:shadow-md transition-shadow">
                <CardHeader className="pb-2">
                  <div className="w-12 h-12 rounded-lg bg-green-100 flex items-center justify-center mb-3">
                    <FileText className="h-6 w-6 text-green-700" />
                  </div>
                  <CardTitle className="text-xl">Automated Payroll</CardTitle>
                  <CardDescription className="text-gray-600">
                    Streamlined processing of salaries, deductions, and benefits with minimal manual intervention.
                  </CardDescription>
                </CardHeader>
              </Card>
              <Card className="border-gray-200 shadow-sm hover:shadow-md transition-shadow">
                <CardHeader className="pb-2">
                  <div className="w-12 h-12 rounded-lg bg-green-100 flex items-center justify-center mb-3">
                    <BarChart className="h-6 w-6 text-green-700" />
                  </div>
                  <CardTitle className="text-xl">Comprehensive Reporting</CardTitle>
                  <CardDescription className="text-gray-600">
                    Generate detailed reports on payroll, personnel, and financial metrics.
                  </CardDescription>
                </CardHeader>
              </Card>
              <Card className="border-gray-200 shadow-sm hover:shadow-md transition-shadow">
                <CardHeader className="pb-2">
                  <div className="w-12 h-12 rounded-lg bg-green-100 flex items-center justify-center mb-3">
                    <Users className="h-6 w-6 text-green-700" />
                  </div>
                  <CardTitle className="text-xl">Employee Self-Service</CardTitle>
                  <CardDescription className="text-gray-600">
                    Allow employees to access their information, payslips, and tax documents online.
                  </CardDescription>
                </CardHeader>
              </Card>
              <Card className="border-gray-200 shadow-sm hover:shadow-md transition-shadow">
                <CardHeader className="pb-2">
                  <div className="w-12 h-12 rounded-lg bg-green-100 flex items-center justify-center mb-3">
                    <Globe className="h-6 w-6 text-green-700" />
                  </div>
                  <CardTitle className="text-xl">Nationwide Integration</CardTitle>
                  <CardDescription className="text-gray-600">
                    Seamless connection with other government systems and financial institutions.
                  </CardDescription>
                </CardHeader>
              </Card>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="w-full py-16 bg-green-700">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <h2 className="text-3xl font-bold tracking-tighter md:text-4xl text-white">
                Ready to streamline your payroll process?
              </h2>
              <p className="max-w-[600px] text-green-100 md:text-xl">
                Join thousands of government agencies already benefiting from IPPIS.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 mt-4">
                <Link href="/register">
                  <Button size="lg" className="bg-white text-green-700 hover:bg-gray-100">
                    Register Now
                  </Button>
                </Link>
                <Link href="/contact">
                  <Button size="lg" variant="outline" className="border-white text-white hover:bg-green-800">
                    Contact Support
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* News Section */}
        <NewsSection />

        {/* Benefits Section */}
        <section id="benefits" className="w-full py-20 bg-gray-50">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
              <div className="inline-flex items-center rounded-full border border-green-200 bg-green-50 px-3 py-1 text-sm text-green-700">
                <span className="font-medium">Key Benefits</span>
              </div>
              <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">Transforming Government Payroll</h2>
              <p className="max-w-[900px] text-gray-600 md:text-xl">
                IPPIS delivers significant advantages to both government agencies and employees through modernized
                payroll management.
              </p>
            </div>
            <div className="mx-auto grid max-w-5xl gap-8 lg:grid-cols-2">
              <div className="space-y-6 bg-white p-8 rounded-xl shadow-sm">
                <div className="inline-flex h-12 w-12 items-center justify-center rounded-lg bg-green-100">
                  <FileText className="h-6 w-6 text-green-700" />
                </div>
                <h3 className="text-xl font-bold text-green-700">For Government Agencies</h3>
                <ul className="space-y-3">
                  <li className="flex items-start gap-3">
                    <div className="flex-shrink-0 mt-1">
                      <div className="h-5 w-5 rounded-full bg-green-100 flex items-center justify-center">
                        <Check className="h-3 w-3 text-green-700" />
                      </div>
                    </div>
                    <span className="text-gray-600">Elimination of ghost workers and payroll fraud</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="flex-shrink-0 mt-1">
                      <div className="h-5 w-5 rounded-full bg-green-100 flex items-center justify-center">
                        <Check className="h-3 w-3 text-green-700" />
                      </div>
                    </div>
                    <span className="text-gray-600">Significant cost savings through process automation</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="flex-shrink-0 mt-1">
                      <div className="h-5 w-5 rounded-full bg-green-100 flex items-center justify-center">
                        <Check className="h-3 w-3 text-green-700" />
                      </div>
                    </div>
                    <span className="text-gray-600">Improved budgeting and financial planning</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="flex-shrink-0 mt-1">
                      <div className="h-5 w-5 rounded-full bg-green-100 flex items-center justify-center">
                        <Check className="h-3 w-3 text-green-700" />
                      </div>
                    </div>
                    <span className="text-gray-600">Enhanced compliance with tax and regulatory requirements</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="flex-shrink-0 mt-1">
                      <div className="h-5 w-5 rounded-full bg-green-100 flex items-center justify-center">
                        <Check className="h-3 w-3 text-green-700" />
                      </div>
                    </div>
                    <span className="text-gray-600">Standardized payroll processes across all departments</span>
                  </li>
                </ul>
                <div className="pt-4">
                  <Link href="/agency-benefits">
                    <Button variant="outline" className="border-green-700 text-green-700 hover:bg-green-50">
                      Learn More <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </Link>
                </div>
              </div>
              <div className="space-y-6 bg-white p-8 rounded-xl shadow-sm">
                <div className="inline-flex h-12 w-12 items-center justify-center rounded-lg bg-green-100">
                  <Users className="h-6 w-6 text-green-700" />
                </div>
                <h3 className="text-xl font-bold text-green-700">For Employees</h3>
                <ul className="space-y-3">
                  <li className="flex items-start gap-3">
                    <div className="flex-shrink-0 mt-1">
                      <div className="h-5 w-5 rounded-full bg-green-100 flex items-center justify-center">
                        <Check className="h-3 w-3 text-green-700" />
                      </div>
                    </div>
                    <span className="text-gray-600">Timely and accurate salary payments</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="flex-shrink-0 mt-1">
                      <div className="h-5 w-5 rounded-full bg-green-100 flex items-center justify-center">
                        <Check className="h-3 w-3 text-green-700" />
                      </div>
                    </div>
                    <span className="text-gray-600">24/7 access to personal employment information</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="flex-shrink-0 mt-1">
                      <div className="h-5 w-5 rounded-full bg-green-100 flex items-center justify-center">
                        <Check className="h-3 w-3 text-green-700" />
                      </div>
                    </div>
                    <span className="text-gray-600">Easy retrieval of payslips and tax documents</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="flex-shrink-0 mt-1">
                      <div className="h-5 w-5 rounded-full bg-green-100 flex items-center justify-center">
                        <Check className="h-3 w-3 text-green-700" />
                      </div>
                    </div>
                    <span className="text-gray-600">Transparent calculation of deductions and benefits</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="flex-shrink-0 mt-1">
                      <div className="h-5 w-5 rounded-full bg-green-100 flex items-center justify-center">
                        <Check className="h-3 w-3 text-green-700" />
                      </div>
                    </div>
                    <span className="text-gray-600">Simplified process for updating personal information</span>
                  </li>
                </ul>
                <div className="pt-4">
                  <Link href="/employee-benefits">
                    <Button variant="outline" className="border-green-700 text-green-700 hover:bg-green-50">
                      Learn More <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Testimonials Section */}
        <section id="testimonials" className="w-full py-20 bg-white">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
              <div className="inline-flex items-center rounded-full border border-green-200 bg-green-50 px-3 py-1 text-sm text-green-700">
                <span className="font-medium">Success Stories</span>
              </div>
              <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">Trusted by Government Agencies</h2>
              <p className="max-w-[900px] text-gray-600 md:text-xl">
                Hear from the departments and employees who have experienced the benefits of IPPIS.
              </p>
            </div>
            <div className="mx-auto grid max-w-5xl gap-6 md:grid-cols-2">
              <Card className="border-gray-200 shadow-sm hover:shadow-md transition-shadow">
                <CardContent className="pt-6">
                  <div className="flex items-start gap-4">
                    <div className="h-12 w-12 rounded-full bg-green-100 flex items-center justify-center">
                      <span className="text-sm font-medium text-green-800">JA</span>
                    </div>
                    <div>
                      <div className="font-semibold text-lg">Dr. James Adamu</div>
                      <div className="text-sm text-gray-500 mb-4">Director, Ministry of Finance</div>
                      <div className="text-gray-600 italic">
                        "IPPIS has revolutionized our payroll management. We've eliminated ghost workers and saved
                        millions in government funds that can now be directed to critical infrastructure projects."
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card className="border-gray-200 shadow-sm hover:shadow-md transition-shadow">
                <CardContent className="pt-6">
                  <div className="flex items-start gap-4">
                    <div className="h-12 w-12 rounded-full bg-green-100 flex items-center justify-center">
                      <span className="text-sm font-medium text-green-800">SO</span>
                    </div>
                    <div>
                      <div className="font-semibold text-lg">Sarah Okonkwo</div>
                      <div className="text-sm text-gray-500 mb-4">Head of HR, Ministry of Education</div>
                      <div className="text-gray-600 italic">
                        "The implementation of IPPIS has streamlined our personnel management processes. What used to
                        take weeks now happens in minutes, allowing our HR team to focus on strategic initiatives."
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card className="border-gray-200 shadow-sm hover:shadow-md transition-shadow">
                <CardContent className="pt-6">
                  <div className="flex items-start gap-4">
                    <div className="h-12 w-12 rounded-full bg-green-100 flex items-center justify-center">
                      <span className="text-sm font-medium text-green-800">MI</span>
                    </div>
                    <div>
                      <div className="font-semibold text-lg">Mohammed Ibrahim</div>
                      <div className="text-sm text-gray-500 mb-4">Senior Teacher, Public School System</div>
                      <div className="text-gray-600 italic">
                        "As a government employee, IPPIS has made a significant difference in my life. My salary is paid
                        promptly, and I can easily access my payslips and tax information online anytime I need them."
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card className="border-gray-200 shadow-sm hover:shadow-md transition-shadow">
                <CardContent className="pt-6">
                  <div className="flex items-start gap-4">
                    <div className="h-12 w-12 rounded-full bg-green-100 flex items-center justify-center">
                      <span className="text-sm font-medium text-green-800">FO</span>
                    </div>
                    <div>
                      <div className="font-semibold text-lg">Fatima Osei</div>
                      <div className="text-sm text-gray-500 mb-4">Accountant General's Office</div>
                      <div className="text-gray-600 italic">
                        "The reporting capabilities of IPPIS have transformed our financial oversight. We now have
                        real-time visibility into payroll expenditures across all government departments, enabling
                        better fiscal management."
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* FAQ Section */}
        <FaqSection />

        {/* Timeline Section */}
        <TimelineSection />

        {/* Contact Section */}
        <section id="contact" className="w-full py-20 bg-white">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
              <div className="inline-flex items-center rounded-full border border-green-200 bg-green-50 px-3 py-1 text-sm text-green-700">
                <span className="font-medium">Get in Touch</span>
              </div>
              <h2 className="text-3xl font-bold tracking-tighter md:text-4xl">Contact Us</h2>
              <p className="max-w-[900px] text-gray-600 md:text-xl">
                Have questions about IPPIS? Our team is here to help you navigate the system and address any concerns.
              </p>
            </div>
            <div className="mx-auto grid max-w-5xl gap-8 lg:grid-cols-2">
              <Card className="border-gray-200 shadow-sm">
                <CardHeader>
                  <CardTitle className="text-xl text-green-700">Contact Information</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div className="flex items-start gap-4">
                      <div className="flex-shrink-0">
                        <div className="h-10 w-10 rounded-lg bg-green-100 flex items-center justify-center">
                          <Mail className="h-5 w-5 text-green-700" />
                        </div>
                      </div>
                      <div>
                        <div className="font-medium text-gray-900">Email</div>
                        <div className="text-sm text-gray-600 mt-1">support@ippis.gov.ng</div>
                      </div>
                    </div>
                    <div className="flex items-start gap-4">
                      <div className="flex-shrink-0">
                        <div className="h-10 w-10 rounded-lg bg-green-100 flex items-center justify-center">
                          <Phone className="h-5 w-5 text-green-700" />
                        </div>
                      </div>
                      <div>
                        <div className="font-medium text-gray-900">Phone</div>
                        <div className="text-sm text-gray-600 mt-1">+234 (0) 1234 5678</div>
                        <div className="text-sm text-gray-600">Monday - Friday, 8am - 5pm</div>
                      </div>
                    </div>
                    <div className="flex items-start gap-4">
                      <div className="flex-shrink-0">
                        <div className="h-10 w-10 rounded-lg bg-green-100 flex items-center justify-center">
                          <Globe className="h-5 w-5 text-green-700" />
                        </div>
                      </div>
                      <div>
                        <div className="font-medium text-gray-900">Headquarters</div>
                        <div className="text-sm text-gray-600 mt-1">
                          Federal Secretariat Complex
                          <br />
                          Phase II, Shehu Shagari Way
                          <br />
                          Central Business District
                          <br />
                          Abuja, Nigeria
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card className="border-gray-200 shadow-sm">
                <CardHeader>
                  <CardTitle className="text-xl text-green-700">Send a Message</CardTitle>
                </CardHeader>
                <CardContent>
                  <form className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <label htmlFor="first-name" className="text-sm font-medium text-gray-700">
                          First name
                        </label>
                        <input
                          id="first-name"
                          className="flex h-10 w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-gray-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-green-600 focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                          placeholder="John"
                        />
                      </div>
                      <div className="space-y-2">
                        <label htmlFor="last-name" className="text-sm font-medium text-gray-700">
                          Last name
                        </label>
                        <input
                          id="last-name"
                          className="flex h-10 w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-gray-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-green-600 focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                          placeholder="Doe"
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="email" className="text-sm font-medium text-gray-700">
                        Email
                      </label>
                      <input
                        id="email"
                        type="email"
                        className="flex h-10 w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-gray-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-green-600 focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                        placeholder="john.doe@example.com"
                      />
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="message" className="text-sm font-medium text-gray-700">
                        Message
                      </label>
                      <textarea
                        id="message"
                        className="flex min-h-[120px] w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm ring-offset-background placeholder:text-gray-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-green-600 focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                        placeholder="Type your message here."
                      ></textarea>
                    </div>
                    <Button className="w-full bg-green-700 hover:bg-green-800">Send Message</Button>
                  </form>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="w-full border-t py-12 bg-gray-50">
        <div className="container px-4 md:px-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-8">
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Coat_of_arms_of_Nigeria.svg-IFrFqiae8fXtNsVx4Ip0AeHFPjj7Mp.png"
                  width={30}
                  height={30}
                  alt="Coat of Arms of Nigeria"
                  className="h-8 w-auto"
                />
                <span className="text-lg font-bold">IPPIS</span>
              </div>
              <p className="text-sm text-gray-600">
                The official platform for managing government employee data and payroll processing in Nigeria.
              </p>
              <div className="flex items-center gap-4">
                <Link href="#" className="text-gray-500 hover:text-green-700">
                  <Twitter className="h-5 w-5" />
                  <span className="sr-only">Twitter</span>
                </Link>
                <Link href="#" className="text-gray-500 hover:text-green-700">
                  <Facebook className="h-5 w-5" />
                  <span className="sr-only">Facebook</span>
                </Link>
              </div>
            </div>
            <div className="space-y-4">
              <h3 className="text-sm font-semibold text-gray-900">Quick Links</h3>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="/" className="text-gray-600 hover:text-green-700">
                    Home
                  </Link>
                </li>
                <li>
                  <Link href="/about" className="text-gray-600 hover:text-green-700">
                    About IPPIS
                  </Link>
                </li>
                <li>
                  <Link href="/portal" className="text-gray-600 hover:text-green-700">
                    Employee Portal
                  </Link>
                </li>
                <li>
                  <Link href="/register" className="text-gray-600 hover:text-green-700">
                    Registration
                  </Link>
                </li>
                <li>
                  <Link href="/contact" className="text-gray-600 hover:text-green-700">
                    Contact Us
                  </Link>
                </li>
              </ul>
            </div>
            <div className="space-y-4">
              <h3 className="text-sm font-semibold text-gray-900">Resources</h3>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="/faq" className="text-gray-600 hover:text-green-700">
                    FAQs
                  </Link>
                </li>
                <li>
                  <Link href="/guides" className="text-gray-600 hover:text-green-700">
                    User Guides
                  </Link>
                </li>
                <li>
                  <Link href="/downloads" className="text-gray-600 hover:text-green-700">
                    Downloads
                  </Link>
                </li>
                <li>
                  <Link href="/news" className="text-gray-600 hover:text-green-700">
                    News & Updates
                  </Link>
                </li>
                <li>
                  <Link href="/support" className="text-gray-600 hover:text-green-700">
                    Support
                  </Link>
                </li>
              </ul>
            </div>
            <div className="space-y-4">
              <h3 className="text-sm font-semibold text-gray-900">Legal</h3>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="/terms" className="text-gray-600 hover:text-green-700">
                    Terms of Service
                  </Link>
                </li>
                <li>
                  <Link href="/privacy" className="text-gray-600 hover:text-green-700">
                    Privacy Policy
                  </Link>
                </li>
                <li>
                  <Link href="/cookies" className="text-gray-600 hover:text-green-700">
                    Cookie Policy
                  </Link>
                </li>
                <li>
                  <Link href="/disclaimer" className="text-gray-600 hover:text-green-700">
                    Disclaimer
                  </Link>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-200 pt-8">
            <p className="text-center text-sm text-gray-500">
              © {new Date().getFullYear()} Integrated Personnel and Payroll Information System. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}
