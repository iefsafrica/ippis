import AdminLoginPage from "../login-admin"

export default function AdminLoginRoute() {
  return <AdminLoginPage />
}
