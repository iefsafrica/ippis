import type { Metadata } from "next"
import ClientWrapper from "./client-wrapper"

export const metadata: Metadata = {
  title: "IPPIS Admin Dashboard",
  description: "Integrated Personnel and Payroll Information System Admin Dashboard",
}

export default function AdminDashboard() {
  return <ClientWrapper />
}

// app/admin/page.tsx (Original content moved to ClientWrapper)
