"use client"

import { Suspense } from "react"
import { Loader2 } from "lucide-react"
import { SettingsContent } from "./settings-content"

export default function ClientWrapper() {
  return (
    <Suspense
      fallback={
        <div className="flex items-center justify-center h-[calc(100vh-200px)]">
          <div className="flex flex-col items-center">
            <Loader2 className="h-8 w-8 text-green-700 animate-spin mb-4" />
            <p className="text-muted-foreground">Loading settings...</p>
          </div>
        </div>
      }
    >
      <SettingsContent />
    </Suspense>
  )
}
