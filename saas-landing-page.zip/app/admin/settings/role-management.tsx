"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { RoleService } from "../services/role-service"
import type { Role, Permission, UserRole } from "@/app/types/auth-types"
import { useAuth } from "@/app/contexts/auth-context"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Loader2, Plus, Edit, Trash2 } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"

// Group permissions by category for better UI organization
const permissionGroups = [
  {
    name: "Employee Management",
    permissions: [
      { id: "view_employees", label: "View Employees" },
      { id: "create_employees", label: "Create Employees" },
      { id: "edit_employees", label: "Edit Employees" },
      { id: "delete_employees", label: "Delete Employees" },
      { id: "approve_employees", label: "Approve Employees" },
      { id: "reject_employees", label: "Reject Employees" },
    ],
  },
  {
    name: "Document Management",
    permissions: [
      { id: "view_documents", label: "View Documents" },
      { id: "upload_documents", label: "Upload Documents" },
      { id: "verify_documents", label: "Verify Documents" },
      { id: "reject_documents", label: "Reject Documents" },
    ],
  },
  {
    name: "System Management",
    permissions: [
      { id: "manage_roles", label: "Manage Roles" },
      { id: "view_reports", label: "View Reports" },
      { id: "export_data", label: "Export Data" },
      { id: "manage_settings", label: "Manage Settings" },
      { id: "backup_database", label: "Backup Database" },
      { id: "import_data", label: "Import Data" },
    ],
  },
]

export default function RoleManagement() {
  const [roles, setRoles] = useState<Role[]>([])
  const [loading, setLoading] = useState(true)
  const [editingRole, setEditingRole] = useState<Role | null>(null)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false)
  const [roleToDelete, setRoleToDelete] = useState<UserRole | null>(null)
  const { user, hasPermission } = useAuth()
  const { toast } = useToast()

  // Form state
  const [formData, setFormData] = useState<{
    name: string
    description: string
    permissions: Permission[]
  }>({
    name: "",
    description: "",
    permissions: [],
  })

  // Load roles on component mount
  useEffect(() => {
    const loadRoles = async () => {
      try {
        const data = await RoleService.getRoles()
        setRoles(data)
      } catch (error) {
        console.error("Failed to load roles:", error)
        toast({
          title: "Error",
          description: "Failed to load roles",
          variant: "destructive",
        })
      } finally {
        setLoading(false)
      }
    }

    loadRoles()
  }, [toast])

  // Handle opening the edit dialog
  const handleEditRole = async (roleId: UserRole) => {
    try {
      const role = await RoleService.getRoleById(roleId)
      if (role) {
        setEditingRole(role)
        setFormData({
          name: role.name,
          description: role.description,
          permissions: [...role.permissions],
        })
        setIsDialogOpen(true)
      }
    } catch (error) {
      console.error("Failed to load role details:", error)
      toast({
        title: "Error",
        description: "Failed to load role details",
        variant: "destructive",
      })
    }
  }

  // Handle opening the create dialog
  const handleCreateRole = () => {
    setEditingRole(null)
    setFormData({
      name: "",
      description: "",
      permissions: [],
    })
    setIsDialogOpen(true)
  }

  // Handle form input changes
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  // Handle permission checkbox changes
  const handlePermissionChange = (permission: Permission, checked: boolean) => {
    setFormData((prev) => {
      if (checked) {
        return { ...prev, permissions: [...prev.permissions, permission] }
      } else {
        return { ...prev, permissions: prev.permissions.filter((p) => p !== permission) }
      }
    })
  }

  // Handle form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    try {
      if (editingRole) {
        // Update existing role
        await RoleService.updateRole(editingRole.id, {
          name: formData.name,
          description: formData.description,
          permissions: formData.permissions,
        })
        toast({
          title: "Success",
          description: `Role "${formData.name}" has been updated`,
        })
      } else {
        // Create new role
        await RoleService.createRole({
          name: formData.name,
          description: formData.description,
          permissions: formData.permissions,
        })
        toast({
          title: "Success",
          description: `Role "${formData.name}" has been created`,
        })
      }

      // Refresh roles list
      const updatedRoles = await RoleService.getRoles()
      setRoles(updatedRoles)
      setIsDialogOpen(false)
    } catch (error) {
      console.error("Failed to save role:", error)
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to save role",
        variant: "destructive",
      })
    }
  }

  // Handle role deletion
  const handleDeleteRole = async () => {
    if (!roleToDelete) return

    try {
      await RoleService.deleteRole(roleToDelete)
      toast({
        title: "Success",
        description: "Role has been deleted",
      })

      // Refresh roles list
      const updatedRoles = await RoleService.getRoles()
      setRoles(updatedRoles)
    } catch (error) {
      console.error("Failed to delete role:", error)
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to delete role",
        variant: "destructive",
      })
    } finally {
      setDeleteDialogOpen(false)
      setRoleToDelete(null)
    }
  }

  // Handle reset to default roles
  const handleResetRoles = async () => {
    try {
      await RoleService.resetToDefault()
      toast({
        title: "Success",
        description: "Roles have been reset to default",
      })

      // Refresh roles list
      const updatedRoles = await RoleService.getRoles()
      setRoles(updatedRoles)
    } catch (error) {
      console.error("Failed to reset roles:", error)
      toast({
        title: "Error",
        description: "Failed to reset roles",
        variant: "destructive",
      })
    }
  }

  // Check if current user can manage roles
  const canManageRoles = hasPermission("manage_roles")

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-green-600" />
      </div>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Role Management</CardTitle>
        <CardDescription>Manage user roles and permissions in the system</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-medium">System Roles</h3>
          {canManageRoles && (
            <div className="flex space-x-2">
              <Button onClick={handleCreateRole} size="sm">
                <Plus className="h-4 w-4 mr-1" /> Add Role
              </Button>
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="outline" size="sm">
                    Reset to Default
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Reset Roles</AlertDialogTitle>
                    <AlertDialogDescription>
                      This will reset all roles to their default settings. Any custom roles will be deleted. This action
                      cannot be undone.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction onClick={handleResetRoles}>Continue</AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </div>
          )}
        </div>

        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Role Name</TableHead>
              <TableHead>Description</TableHead>
              <TableHead>Permissions</TableHead>
              {canManageRoles && <TableHead className="w-24">Actions</TableHead>}
            </TableRow>
          </TableHeader>
          <TableBody>
            {roles.map((role) => (
              <TableRow key={role.id}>
                <TableCell className="font-medium">{role.name}</TableCell>
                <TableCell>{role.description}</TableCell>
                <TableCell>
                  <div className="flex flex-wrap gap-1">
                    {role.permissions.slice(0, 3).map((permission) => (
                      <Badge key={permission} variant="outline" className="bg-green-50 text-green-700 border-green-200">
                        {permission.replace(/_/g, " ")}
                      </Badge>
                    ))}
                    {role.permissions.length > 3 && (
                      <Badge variant="outline" className="bg-gray-50 text-gray-700 border-gray-200">
                        +{role.permissions.length - 3} more
                      </Badge>
                    )}
                  </div>
                </TableCell>
                {canManageRoles && (
                  <TableCell>
                    <div className="flex space-x-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleEditRole(role.id)}
                        disabled={role.isDefault && user?.role !== "super_admin"}
                      >
                        <Edit className="h-4 w-4" />
                        <span className="sr-only">Edit</span>
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => {
                          setRoleToDelete(role.id)
                          setDeleteDialogOpen(true)
                        }}
                        disabled={role.isDefault}
                      >
                        <Trash2 className="h-4 w-4 text-red-500" />
                        <span className="sr-only">Delete</span>
                      </Button>
                    </div>
                  </TableCell>
                )}
              </TableRow>
            ))}
          </TableBody>
        </Table>

        {/* Role Edit/Create Dialog */}
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{editingRole ? "Edit Role" : "Create New Role"}</DialogTitle>
              <DialogDescription>
                {editingRole
                  ? "Update the role details and permissions"
                  : "Define a new role with specific permissions"}
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit}>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="name" className="text-right">
                    Role Name
                  </Label>
                  <Input
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    className="col-span-3"
                    required
                    disabled={editingRole?.isDefault}
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="description" className="text-right">
                    Description
                  </Label>
                  <Textarea
                    id="description"
                    name="description"
                    value={formData.description}
                    onChange={handleInputChange}
                    className="col-span-3"
                    rows={3}
                  />
                </div>

                <div className="grid grid-cols-1 gap-6 mt-4">
                  <Label className="text-lg font-medium">Permissions</Label>

                  {permissionGroups.map((group) => (
                    <div key={group.name} className="space-y-2">
                      <h4 className="font-medium text-sm text-gray-500">{group.name}</h4>
                      <div className="grid grid-cols-2 gap-2">
                        {group.permissions.map((perm) => (
                          <div key={perm.id} className="flex items-center space-x-2">
                            <Checkbox
                              id={perm.id}
                              checked={formData.permissions.includes(perm.id as Permission)}
                              onCheckedChange={(checked) =>
                                handlePermissionChange(perm.id as Permission, checked === true)
                              }
                              disabled={
                                editingRole?.id === "super_admin" ||
                                (perm.id === "manage_roles" && user?.role !== "super_admin")
                              }
                            />
                            <Label htmlFor={perm.id} className="text-sm font-normal">
                              {perm.label}
                            </Label>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit">Save</Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>

        {/* Delete Confirmation Dialog */}
        <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Are you sure?</AlertDialogTitle>
              <AlertDialogDescription>
                This action cannot be undone. This will permanently delete the role and remove it from the system.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={handleDeleteRole} className="bg-red-600 hover:bg-red-700">
                Delete
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </CardContent>
    </Card>
  )
}
