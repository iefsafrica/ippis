"use client"

import { useState } from "react"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { Save, Mail, Database, Loader2, AlertTriangle } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Separator } from "@/components/ui/separator"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

const emailSettingsSchema = z.object({
  smtpServer: z.string().min(1, { message: "SMTP server is required" }),
  smtpPort: z.string().min(1, { message: "SMTP port is required" }),
  smtpUsername: z.string().min(1, { message: "SMTP username is required" }),
  smtpPassword: z.string().min(1, { message: "SMTP password is required" }),
  senderEmail: z.string().email({ message: "Please enter a valid email" }),
  senderName: z.string().min(1, { message: "Sender name is required" }),
  enableEmailNotifications: z.boolean(),
})

const backupSettingsSchema = z.object({
  backupFrequency: z.enum(["daily", "weekly", "monthly"]),
  backupTime: z.string().min(1, { message: "Backup time is required" }),
  retentionPeriod: z.string().min(1, { message: "Retention period is required" }),
  backupLocation: z.string().min(1, { message: "Backup location is required" }),
  enableAutomaticBackups: z.boolean(),
})

const systemSettingsSchema = z.object({
  systemName: z.string().min(1, { message: "System name is required" }),
  systemUrl: z.string().url({ message: "Please enter a valid URL" }),
  maxUploadSize: z.string().min(1, { message: "Max upload size is required" }),
  allowedFileTypes: z.string().min(1, { message: "Allowed file types are required" }),
  sessionTimeout: z.string().min(1, { message: "Session timeout is required" }),
  maintenanceMode: z.boolean(),
  maintenanceMessage: z.string().optional(),
})

type EmailSettingsValues = z.infer<typeof emailSettingsSchema>
type BackupSettingsValues = z.infer<typeof backupSettingsSchema>
type SystemSettingsValues = z.infer<typeof systemSettingsSchema>

export default function SystemSettings() {
  const [isLoading, setIsLoading] = useState(false)

  // Email settings form
  const emailForm = useForm<EmailSettingsValues>({
    resolver: zodResolver(emailSettingsSchema),
    defaultValues: {
      smtpServer: "smtp.ippis.gov.ng",
      smtpPort: "587",
      smtpUsername: "notifications@ippis.gov.ng",
      smtpPassword: "••••••••••••",
      senderEmail: "no-reply@ippis.gov.ng",
      senderName: "IPPIS Notification System",
      enableEmailNotifications: true,
    },
  })

  // Backup settings form
  const backupForm = useForm<BackupSettingsValues>({
    resolver: zodResolver(backupSettingsSchema),
    defaultValues: {
      backupFrequency: "daily",
      backupTime: "02:00",
      retentionPeriod: "30",
      backupLocation: "/var/backups/ippis",
      enableAutomaticBackups: true,
    },
  })

  // System settings form
  const systemForm = useForm<SystemSettingsValues>({
    resolver: zodResolver(systemSettingsSchema),
    defaultValues: {
      systemName: "Integrated Personnel and Payroll Information System",
      systemUrl: "https://ippis.gov.ng",
      maxUploadSize: "10",
      allowedFileTypes: "pdf,jpg,png,doc,docx",
      sessionTimeout: "30",
      maintenanceMode: false,
      maintenanceMessage: "The system is currently undergoing scheduled maintenance. Please try again later.",
    },
  })

  function onEmailSubmit(data: EmailSettingsValues) {
    setIsLoading(true)
    // Simulate API call
    setTimeout(() => {
      console.log(data)
      setIsLoading(false)
    }, 1000)
  }

  function onBackupSubmit(data: BackupSettingsValues) {
    setIsLoading(true)
    // Simulate API call
    setTimeout(() => {
      console.log(data)
      setIsLoading(false)
    }, 1000)
  }

  function onSystemSubmit(data: SystemSettingsValues) {
    setIsLoading(true)
    // Simulate API call
    setTimeout(() => {
      console.log(data)
      setIsLoading(false)
    }, 1000)
  }

  function triggerManualBackup() {
    setIsLoading(true)
    // Simulate API call
    setTimeout(() => {
      console.log("Manual backup triggered")
      setIsLoading(false)
    }, 2000)
  }

  return (
    <Tabs defaultValue="general" className="w-full">
      <TabsList className="mb-4">
        <TabsTrigger value="general">General</TabsTrigger>
        <TabsTrigger value="email">Email</TabsTrigger>
        <TabsTrigger value="backup">Backup & Recovery</TabsTrigger>
      </TabsList>

      <TabsContent value="general">
        <Form {...systemForm}>
          <form onSubmit={systemForm.handleSubmit(onSystemSubmit)} className="space-y-6">
            <div>
              <h3 className="text-lg font-medium">System Configuration</h3>
              <p className="text-sm text-muted-foreground mb-4">Configure system-wide settings and defaults</p>

              <div className="grid gap-4 md:grid-cols-2">
                <FormField
                  control={systemForm.control}
                  name="systemName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>System Name</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormDescription>The name displayed throughout the application</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={systemForm.control}
                  name="systemUrl"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>System URL</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormDescription>The base URL for the application</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </div>

            <Separator />

            <div>
              <h3 className="text-lg font-medium">File Upload Settings</h3>
              <p className="text-sm text-muted-foreground mb-4">Configure file upload limits and restrictions</p>

              <div className="grid gap-4 md:grid-cols-2">
                <FormField
                  control={systemForm.control}
                  name="maxUploadSize"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Maximum Upload Size (MB)</FormLabel>
                      <FormControl>
                        <Input type="number" {...field} />
                      </FormControl>
                      <FormDescription>Maximum file size in megabytes</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={systemForm.control}
                  name="allowedFileTypes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Allowed File Types</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormDescription>Comma-separated list of allowed file extensions</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </div>

            <Separator />

            <div>
              <h3 className="text-lg font-medium">Security Settings</h3>
              <p className="text-sm text-muted-foreground mb-4">Configure security-related settings</p>

              <FormField
                control={systemForm.control}
                name="sessionTimeout"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Session Timeout (minutes)</FormLabel>
                    <FormControl>
                      <Input type="number" {...field} />
                    </FormControl>
                    <FormDescription>Time in minutes before an inactive session expires</FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <Separator />

            <div>
              <h3 className="text-lg font-medium">Maintenance Mode</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Enable maintenance mode to temporarily restrict access to the system
              </p>

              <div className="space-y-4">
                <FormField
                  control={systemForm.control}
                  name="maintenanceMode"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                      <div className="space-y-0.5">
                        <FormLabel className="text-base">Maintenance Mode</FormLabel>
                        <FormDescription>When enabled, only administrators can access the system</FormDescription>
                      </div>
                      <FormControl>
                        <Switch checked={field.value} onCheckedChange={field.onChange} />
                      </FormControl>
                    </FormItem>
                  )}
                />

                <FormField
                  control={systemForm.control}
                  name="maintenanceMessage"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Maintenance Message</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Enter the message to display during maintenance"
                          className="resize-none"
                          {...field}
                          value={field.value || ""}
                        />
                      </FormControl>
                      <FormDescription>This message will be displayed to users during maintenance</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </div>

            <Button type="submit" disabled={isLoading}>
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Saving...
                </>
              ) : (
                <>
                  <Save className="mr-2 h-4 w-4" />
                  Save Changes
                </>
              )}
            </Button>
          </form>
        </Form>
      </TabsContent>

      <TabsContent value="email">
        <Form {...emailForm}>
          <form onSubmit={emailForm.handleSubmit(onEmailSubmit)} className="space-y-6">
            <div>
              <h3 className="text-lg font-medium">Email Server Configuration</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Configure the email server settings for system notifications
              </p>

              <div className="grid gap-4 md:grid-cols-2">
                <FormField
                  control={emailForm.control}
                  name="smtpServer"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>SMTP Server</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={emailForm.control}
                  name="smtpPort"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>SMTP Port</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={emailForm.control}
                  name="smtpUsername"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>SMTP Username</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={emailForm.control}
                  name="smtpPassword"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>SMTP Password</FormLabel>
                      <FormControl>
                        <Input type="password" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </div>

            <Separator />

            <div>
              <h3 className="text-lg font-medium">Email Sender Settings</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Configure the default sender information for system emails
              </p>

              <div className="grid gap-4 md:grid-cols-2">
                <FormField
                  control={emailForm.control}
                  name="senderEmail"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Sender Email</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormDescription>The email address that will appear in the "From" field</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={emailForm.control}
                  name="senderName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Sender Name</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormDescription>The name that will appear in the "From" field</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </div>

            <Separator />

            <div>
              <h3 className="text-lg font-medium">Email Notifications</h3>
              <p className="text-sm text-muted-foreground mb-4">Configure email notification settings</p>

              <FormField
                control={emailForm.control}
                name="enableEmailNotifications"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                    <div className="space-y-0.5">
                      <FormLabel className="text-base">Enable Email Notifications</FormLabel>
                      <FormDescription>
                        When enabled, the system will send email notifications for various events
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch checked={field.value} onCheckedChange={field.onChange} />
                    </FormControl>
                  </FormItem>
                )}
              />
            </div>

            <div className="flex gap-4">
              <Button type="submit" disabled={isLoading}>
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Saving...
                  </>
                ) : (
                  <>
                    <Save className="mr-2 h-4 w-4" />
                    Save Changes
                  </>
                )}
              </Button>

              <Button type="button" variant="outline">
                <Mail className="mr-2 h-4 w-4" />
                Test Connection
              </Button>
            </div>
          </form>
        </Form>
      </TabsContent>

      <TabsContent value="backup">
        <Form {...backupForm}>
          <form onSubmit={backupForm.handleSubmit(onBackupSubmit)} className="space-y-6">
            <div>
              <h3 className="text-lg font-medium">Backup Configuration</h3>
              <p className="text-sm text-muted-foreground mb-4">Configure automatic database backup settings</p>

              <div className="grid gap-4 md:grid-cols-2">
                <FormField
                  control={backupForm.control}
                  name="backupFrequency"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Backup Frequency</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select frequency" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="daily">Daily</SelectItem>
                          <SelectItem value="weekly">Weekly</SelectItem>
                          <SelectItem value="monthly">Monthly</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormDescription>How often backups should be performed</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={backupForm.control}
                  name="backupTime"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Backup Time</FormLabel>
                      <FormControl>
                        <Input type="time" {...field} />
                      </FormControl>
                      <FormDescription>The time when backups should be performed</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={backupForm.control}
                  name="retentionPeriod"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Retention Period (days)</FormLabel>
                      <FormControl>
                        <Input type="number" {...field} />
                      </FormControl>
                      <FormDescription>Number of days to keep backups before deletion</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={backupForm.control}
                  name="backupLocation"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Backup Location</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormDescription>Directory path where backups will be stored</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </div>

            <Separator />

            <div>
              <h3 className="text-lg font-medium">Automatic Backups</h3>
              <p className="text-sm text-muted-foreground mb-4">Enable or disable automatic backups</p>

              <FormField
                control={backupForm.control}
                name="enableAutomaticBackups"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                    <div className="space-y-0.5">
                      <FormLabel className="text-base">Enable Automatic Backups</FormLabel>
                      <FormDescription>
                        When enabled, the system will automatically create backups according to the schedule
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch checked={field.value} onCheckedChange={field.onChange} />
                    </FormControl>
                  </FormItem>
                )}
              />
            </div>

            <Separator />

            <div>
              <h3 className="text-lg font-medium">Manual Backup</h3>
              <p className="text-sm text-muted-foreground mb-4">Create a manual backup of the database</p>

              <Card>
                <CardHeader>
                  <CardTitle>Create Manual Backup</CardTitle>
                  <CardDescription>Create an immediate backup of the database</CardDescription>
                </CardHeader>
                <CardContent>
                  <Alert>
                    <AlertTriangle className="h-4 w-4" />
                    <AlertTitle>Important</AlertTitle>
                    <AlertDescription>
                      Creating a manual backup may temporarily affect system performance. It's recommended to perform
                      this operation during off-peak hours.
                    </AlertDescription>
                  </Alert>
                </CardContent>
                <CardFooter>
                  <Button type="button" onClick={triggerManualBackup} disabled={isLoading}>
                    {isLoading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Creating Backup...
                      </>
                    ) : (
                      <>
                        <Database className="mr-2 h-4 w-4" />
                        Create Backup Now
                      </>
                    )}
                  </Button>
                </CardFooter>
              </Card>
            </div>

            <div className="flex gap-4">
              <Button type="submit" disabled={isLoading}>
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Saving...
                  </>
                ) : (
                  <>
                    <Save className="mr-2 h-4 w-4" />
                    Save Changes
                  </>
                )}
              </Button>
            </div>
          </form>
        </Form>
      </TabsContent>
    </Tabs>
  )
}
