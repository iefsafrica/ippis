"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useAuth } from "@/app/contexts/auth-context"
import type { AuthUser, UserRole } from "@/app/types/auth-types"
import { RoleService } from "../services/role-service"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Loader2, Edit, UserPlus, Trash2, Search } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"

// Mock user service for demonstration
const UserService = {
  getUsers: async (): Promise<AuthUser[]> => {
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 500))

    return [
      {
        id: "user-1",
        name: "Admin User",
        email: "admin@ippis.gov.ng",
        role: "admin",
        department: "IT",
        lastLogin: new Date().toISOString(),
        avatar: "/placeholder.svg?height=32&width=32",
      },
      {
        id: "user-2",
        name: "John Doe",
        email: "john.doe@ippis.gov.ng",
        role: "editor",
        department: "Finance",
        lastLogin: new Date(Date.now() - 86400000).toISOString(),
        avatar: "/placeholder.svg?height=32&width=32",
      },
      {
        id: "user-3",
        name: "Jane Smith",
        email: "jane.smith@ippis.gov.ng",
        role: "viewer",
        department: "HR",
        lastLogin: new Date(Date.now() - 172800000).toISOString(),
        avatar: "/placeholder.svg?height=32&width=32",
      },
      {
        id: "user-4",
        name: "Super Admin",
        email: "super.admin@ippis.gov.ng",
        role: "super_admin",
        department: "Executive",
        lastLogin: new Date(Date.now() - 259200000).toISOString(),
        avatar: "/placeholder.svg?height=32&width=32",
      },
    ]
  },

  createUser: async (user: Omit<AuthUser, "id">): Promise<AuthUser> => {
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 800))

    return {
      id: `user-${Math.floor(Math.random() * 1000)}`,
      ...user,
      lastLogin: new Date().toISOString(),
    }
  },

  updateUser: async (id: string, updates: Partial<AuthUser>): Promise<AuthUser> => {
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 600))

    // In a real app, this would update the user in the database
    return {
      id,
      name: updates.name || "Updated User",
      email: updates.email || "updated@example.com",
      role: updates.role || "viewer",
      department: updates.department || "General",
      lastLogin: new Date().toISOString(),
      avatar: updates.avatar || "/placeholder.svg?height=32&width=32",
    }
  },

  deleteUser: async (id: string): Promise<boolean> => {
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 500))

    // In a real app, this would delete the user from the database
    return true
  },
}

export default function UserManagement() {
  const [users, setUsers] = useState<AuthUser[]>([])
  const [roles, setRoles] = useState<{ id: UserRole; name: string }[]>([])
  const [loading, setLoading] = useState(true)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [editingUser, setEditingUser] = useState<AuthUser | null>(null)
  const [userToDelete, setUserToDelete] = useState<AuthUser | null>(null)
  const [searchQuery, setSearchQuery] = useState("")
  const { user: currentUser, hasPermission } = useAuth()
  const { toast } = useToast()

  // Form state
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    role: "viewer" as UserRole,
    department: "",
  })

  // Load users and roles on component mount
  useEffect(() => {
    const loadData = async () => {
      try {
        const [usersData, rolesData] = await Promise.all([UserService.getUsers(), RoleService.getRoles()])

        setUsers(usersData)
        setRoles(rolesData.map((role) => ({ id: role.id, name: role.name })))
      } catch (error) {
        console.error("Failed to load data:", error)
        toast({
          title: "Error",
          description: "Failed to load users and roles",
          variant: "destructive",
        })
      } finally {
        setLoading(false)
      }
    }

    loadData()
  }, [toast])

  // Handle opening the edit dialog
  const handleEditUser = (user: AuthUser) => {
    setEditingUser(user)
    setFormData({
      name: user.name,
      email: user.email,
      role: user.role,
      department: user.department || "",
    })
    setIsDialogOpen(true)
  }

  // Handle opening the create dialog
  const handleCreateUser = () => {
    setEditingUser(null)
    setFormData({
      name: "",
      email: "",
      role: "viewer",
      department: "",
    })
    setIsDialogOpen(true)
  }

  // Handle opening the delete dialog
  const handleDeleteUser = (user: AuthUser) => {
    setUserToDelete(user)
    setIsDeleteDialogOpen(true)
  }

  // Handle confirming user deletion
  const confirmDeleteUser = async () => {
    if (!userToDelete) return

    try {
      setLoading(true)
      const success = await UserService.deleteUser(userToDelete.id)

      if (success) {
        setUsers(users.filter((user) => user.id !== userToDelete.id))
        toast({
          title: "User deleted",
          description: `${userToDelete.name} has been removed from the system`,
        })
      }
    } catch (error) {
      console.error("Failed to delete user:", error)
      toast({
        title: "Error",
        description: "Failed to delete user",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
      setIsDeleteDialogOpen(false)
      setUserToDelete(null)
    }
  }

  // Handle form input changes
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  // Handle role selection
  const handleRoleChange = (value: string) => {
    setFormData((prev) => ({ ...prev, role: value as UserRole }))
  }

  // Handle search input
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value)
  }

  // Handle form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    try {
      setLoading(true)

      if (editingUser) {
        // Update existing user
        const updatedUser = await UserService.updateUser(editingUser.id, formData)
        setUsers(users.map((user) => (user.id === editingUser.id ? updatedUser : user)))
        toast({
          title: "Success",
          description: `User "${formData.name}" has been updated`,
        })
      } else {
        // Create new user
        const newUser = await UserService.createUser(formData)
        setUsers([...users, newUser])
        toast({
          title: "Success",
          description: `User "${formData.name}" has been created`,
        })
      }

      setIsDialogOpen(false)
    } catch (error) {
      console.error("Failed to save user:", error)
      toast({
        title: "Error",
        description: "Failed to save user",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  // Format role name for display
  const formatRoleName = (role: string) => {
    return role
      .split("_")
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(" ")
  }

  // Format date for display
  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return new Intl.DateTimeFormat("en-US", {
      dateStyle: "medium",
      timeStyle: "short",
    }).format(date)
  }

  // Filter users based on search query
  const filteredUsers = users.filter((user) => {
    const searchLower = searchQuery.toLowerCase()
    return (
      user.name.toLowerCase().includes(searchLower) ||
      user.email.toLowerCase().includes(searchLower) ||
      user.department?.toLowerCase().includes(searchLower) ||
      formatRoleName(user.role).toLowerCase().includes(searchLower)
    )
  })

  // Check if current user can manage users
  const canManageUsers = hasPermission("manage_roles")

  // Check if a user can be edited or deleted
  const canModifyUser = (userToCheck: AuthUser) => {
    // Super admins can only be modified by other super admins
    if (userToCheck.role === "super_admin" && currentUser?.role !== "super_admin") {
      return false
    }

    // Users cannot delete themselves
    if (userToCheck.id === currentUser?.id) {
      return false
    }

    return true
  }

  if (loading && users.length === 0) {
    return (
      <div className="flex justify-center items-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-green-600" />
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-medium">System Users</h3>
        <div className="flex gap-2">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search users..."
              className="w-[200px] pl-8 md:w-[300px]"
              value={searchQuery}
              onChange={handleSearchChange}
            />
          </div>
          {canManageUsers && (
            <Button onClick={handleCreateUser} size="sm">
              <UserPlus className="h-4 w-4 mr-1" /> Add User
            </Button>
          )}
        </div>
      </div>

      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>User</TableHead>
            <TableHead>Role</TableHead>
            <TableHead>Department</TableHead>
            <TableHead>Last Login</TableHead>
            {canManageUsers && <TableHead className="w-24 text-right">Actions</TableHead>}
          </TableRow>
        </TableHeader>
        <TableBody>
          {filteredUsers.length === 0 ? (
            <TableRow>
              <TableCell colSpan={canManageUsers ? 5 : 4} className="text-center py-8 text-muted-foreground">
                {searchQuery ? "No users match your search" : "No users found"}
              </TableCell>
            </TableRow>
          ) : (
            filteredUsers.map((user) => (
              <TableRow key={user.id}>
                <TableCell>
                  <div className="flex items-center space-x-3">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={user.avatar || "/placeholder.svg?height=32&width=32"} alt={user.name} />
                      <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="font-medium">{user.name}</div>
                      <div className="text-sm text-muted-foreground">{user.email}</div>
                    </div>
                  </div>
                </TableCell>
                <TableCell>
                  <Badge
                    variant={
                      user.role === "super_admin"
                        ? "default"
                        : user.role === "admin"
                          ? "secondary"
                          : user.role === "editor"
                            ? "outline"
                            : "secondary"
                    }
                    className="capitalize"
                  >
                    {formatRoleName(user.role)}
                  </Badge>
                </TableCell>
                <TableCell>{user.department || "—"}</TableCell>
                <TableCell>{user.lastLogin ? formatDate(user.lastLogin) : "Never"}</TableCell>
                {canManageUsers && (
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleEditUser(user)}
                        disabled={!canModifyUser(user)}
                        title="Edit user"
                      >
                        <Edit className="h-4 w-4" />
                        <span className="sr-only">Edit</span>
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleDeleteUser(user)}
                        disabled={!canModifyUser(user)}
                        title="Delete user"
                      >
                        <Trash2 className="h-4 w-4 text-red-500" />
                        <span className="sr-only">Delete</span>
                      </Button>
                    </div>
                  </TableCell>
                )}
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>

      {/* User Edit/Create Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingUser ? "Edit User" : "Create New User"}</DialogTitle>
            <DialogDescription>
              {editingUser ? "Update the user details and role" : "Add a new user to the system"}
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit}>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="name" className="text-right">
                  Name
                </Label>
                <Input
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  className="col-span-3"
                  required
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="email" className="text-right">
                  Email
                </Label>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  className="col-span-3"
                  required
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="department" className="text-right">
                  Department
                </Label>
                <Input
                  id="department"
                  name="department"
                  value={formData.department}
                  onChange={handleInputChange}
                  className="col-span-3"
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="role" className="text-right">
                  Role
                </Label>
                <Select value={formData.role} onValueChange={handleRoleChange}>
                  <SelectTrigger className="col-span-3">
                    <SelectValue placeholder="Select a role" />
                  </SelectTrigger>
                  <SelectContent>
                    {roles.map((role) => (
                      <SelectItem
                        key={role.id}
                        value={role.id}
                        disabled={role.id === "super_admin" && currentUser?.role !== "super_admin"}
                      >
                        {role.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" disabled={loading}>
                {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Save
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the user {userToDelete?.name}. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDeleteUser} className="bg-red-600 hover:bg-red-700">
              {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
