import type { Metadata } from "next"
import EmployeesClientWrapper from "./client-wrapper"

export const metadata: Metadata = {
  title: "IPPIS - Employees",
  description: "Manage and view all approved employees in the system.",
}

export default function EmployeesPage() {
  return <EmployeesClientWrapper />
}
