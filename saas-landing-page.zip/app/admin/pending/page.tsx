import type { Metadata } from "next"
import ClientWrapper from "./client-wrapper"

export const metadata: Metadata = {
  title: "Pending Employees | IPPIS Admin",
  description: "Review and approve employee registration requests",
}

export default function PendingEmployeesPage() {
  return <ClientWrapper />
}
