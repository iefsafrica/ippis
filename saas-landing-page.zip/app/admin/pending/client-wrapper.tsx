"use client"

import { Suspense } from "react"
import { Loader2 } from "lucide-react"
import dynamic from "next/dynamic"

const PendingContent = dynamic(() => import("./pending-content"), {
  ssr: false,
  loading: () => (
    <div className="flex items-center justify-center h-[calc(100vh-200px)]">
      <div className="flex flex-col items-center">
        <Loader2 className="h-8 w-8 text-green-700 animate-spin mb-4" />
        <p className="text-muted-foreground">Loading pending employees...</p>
      </div>
    </div>
  ),
})

export default function ClientWrapper() {
  return (
    <Suspense
      fallback={
        <div className="flex items-center justify-center h-[calc(100vh-200px)]">
          <div className="flex flex-col items-center">
            <Loader2 className="h-8 w-8 text-green-700 animate-spin mb-4" />
            <p className="text-muted-foreground">Loading pending employees...</p>
          </div>
        </div>
      }
    >
      <PendingContent />
    </Suspense>
  )
}
