"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Textarea } from "@/components/ui/textarea"
import {
  Filter,
  MoreHorizontal,
  Search,
  SlidersHorizontal,
  Clock,
  CheckCircle,
  X,
  Eye,
  AlertCircle,
  Loader2,
  FileWarning,
  Mail,
} from "lucide-react"
import { Pagination } from "../components/pagination"
import { type PendingEmployee, PendingEmployeeService } from "../services/mock-data-service"
import { useToast } from "@/components/ui/use-toast"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { EmailService } from "../services/email-service"
import { DataExportMenu } from "../components/data-export-menu"
import { AdvancedSearch } from "../components/advanced-search"
import ExportService from "../services/export-service"

export default function PendingContent() {
  const [searchTerm, setSearchTerm] = useState("")
  const [dateFilter, setDateFilter] = useState("all")
  const [departmentFilter, setDepartmentFilter] = useState("all")
  const [sourceFilter, setSourceFilter] = useState("all")
  const [statusFilter, setStatusFilter] = useState("all")
  const [pendingEmployees, setPendingEmployees] = useState<PendingEmployee[]>([])
  const [filteredEmployees, setFilteredEmployees] = useState<PendingEmployee[]>([])
  const [loading, setLoading] = useState(true)
  const [currentPage, setCurrentPage] = useState(1)
  const [itemsPerPage] = useState(10)
  const [selectedEmployee, setSelectedEmployee] = useState<PendingEmployee | null>(null)
  const [showMissingFieldsDialog, setShowMissingFieldsDialog] = useState(false)
  const [showApproveDialog, setShowApproveDialog] = useState(false)
  const [showRejectDialog, setShowRejectDialog] = useState(false)
  const [approveComment, setApproveComment] = useState("")
  const [rejectComment, setRejectComment] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [advancedSearchParams, setAdvancedSearchParams] = useState<Record<string, string>>({})

  const { toast } = useToast()

  // Load pending employees with filters
  useEffect(() => {
    const loadPendingEmployees = async () => {
      setLoading(true)
      try {
        const data = await PendingEmployeeService.getPendingEmployees({
          search: searchTerm,
          date: dateFilter,
          department: departmentFilter,
          source: sourceFilter === "form" ? "form" : sourceFilter === "import" ? "import" : undefined,
          status: statusFilter !== "all" ? statusFilter : undefined,
        })
        setPendingEmployees(data)
        setFilteredEmployees(data)
      } catch (error) {
        console.error("Failed to load pending employees:", error)
        toast({
          title: "Error",
          description: "Failed to load pending employees. Please try again.",
          variant: "destructive",
        })
      } finally {
        setLoading(false)
      }
    }

    // Add a small delay to prevent too many API calls while typing
    const handler = setTimeout(() => {
      loadPendingEmployees()
    }, 300)

    return () => clearTimeout(handler)
  }, [searchTerm, dateFilter, departmentFilter, sourceFilter, statusFilter, toast])

  // Apply advanced search filters
  useEffect(() => {
    if (Object.keys(advancedSearchParams).length === 0) {
      setFilteredEmployees(pendingEmployees)
      return
    }

    const filtered = pendingEmployees.filter((employee) => {
      return Object.entries(advancedSearchParams).every(([key, value]) => {
        if (!value) return true

        switch (key) {
          case "name":
            return employee.name.toLowerCase().includes(value.toLowerCase())
          case "email":
            return employee.email.toLowerCase().includes(value.toLowerCase())
          case "department":
            return employee.department === value
          case "position":
            return employee.position.toLowerCase().includes(value.toLowerCase())
          case "status":
            return employee.status === value
          case "submissionDate":
            const employeeDate = new Date(employee.submissionDate).toISOString().split("T")[0]
            return employeeDate === value
          case "source":
            return employee.source === value
          default:
            return true
        }
      })
    })

    setFilteredEmployees(filtered)
  }, [advancedSearchParams, pendingEmployees])

  // Open approve dialog
  const openApproveDialog = (employee: PendingEmployee) => {
    setSelectedEmployee(employee)
    setApproveComment("")
    setShowApproveDialog(true)
  }

  // Open reject dialog
  const openRejectDialog = (employee: PendingEmployee) => {
    setSelectedEmployee(employee)
    setRejectComment("")
    setShowRejectDialog(true)
  }

  // Handle approving a pending employee
  const handleApproveEmployee = async () => {
    if (!selectedEmployee) return

    setIsSubmitting(true)
    try {
      const approvedEmployee = await PendingEmployeeService.approvePendingEmployee(selectedEmployee.id)

      // Send email notification
      await EmailService.sendEmail(selectedEmployee.email, "employeeApproved", {
        name: selectedEmployee.name,
        employeeId: approvedEmployee.id,
        portalLink: EmailService.generatePortalLink(approvedEmployee.id),
        comment: approveComment,
      })

      // Refresh the pending employees list
      const updatedPendingEmployees = await PendingEmployeeService.getPendingEmployees({
        search: searchTerm,
        date: dateFilter,
        department: departmentFilter,
        source: sourceFilter === "form" ? "form" : sourceFilter === "import" ? "import" : undefined,
        status: statusFilter !== "all" ? statusFilter : undefined,
      })
      setPendingEmployees(updatedPendingEmployees)
      setFilteredEmployees(updatedPendingEmployees)

      toast({
        title: "Success",
        description: `Employee ${selectedEmployee.name} has been approved and moved to the employees list.`,
      })

      setShowApproveDialog(false)
    } catch (error) {
      console.error("Failed to approve employee:", error)
      toast({
        title: "Error",
        description: "Failed to approve employee. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  // Handle rejecting a pending employee
  const handleRejectEmployee = async () => {
    if (!selectedEmployee) return

    if (!rejectComment.trim()) {
      toast({
        title: "Validation Error",
        description: "Please provide a reason for rejection.",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)
    try {
      await PendingEmployeeService.rejectPendingEmployee(selectedEmployee.id)

      // Send email notification
      await EmailService.sendEmail(selectedEmployee.email, "employeeRejected", {
        name: selectedEmployee.name,
        updateLink: EmailService.generateUpdateLink(selectedEmployee.id),
        comment: rejectComment,
      })

      // Refresh the pending employees list
      const updatedPendingEmployees = await PendingEmployeeService.getPendingEmployees({
        search: searchTerm,
        date: dateFilter,
        department: departmentFilter,
        source: sourceFilter === "form" ? "form" : sourceFilter === "import" ? "import" : undefined,
        status: statusFilter !== "all" ? statusFilter : undefined,
      })
      setPendingEmployees(updatedPendingEmployees)
      setFilteredEmployees(updatedPendingEmployees)

      toast({
        title: "Success",
        description: `Employee ${selectedEmployee.name}'s application has been rejected.`,
      })

      setShowRejectDialog(false)
    } catch (error) {
      console.error("Failed to reject employee:", error)
      toast({
        title: "Error",
        description: "Failed to reject employee. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  // View missing fields
  const handleViewMissingFields = (employee: PendingEmployee) => {
    setSelectedEmployee(employee)
    setShowMissingFieldsDialog(true)
  }

  // Handle advanced search
  const handleAdvancedSearch = (params: Record<string, string>) => {
    setAdvancedSearchParams(params)
    setCurrentPage(1) // Reset to first page when applying new search
  }

  // Export functions
  const handleExportPDF = () => {
    const columns = [
      { header: "Name", accessor: "name" },
      { header: "Email", accessor: "email" },
      { header: "Department", accessor: "department" },
      { header: "Position", accessor: "position" },
      { header: "Status", accessor: "status" },
      { header: "Source", accessor: "source" },
      { header: "Submission Date", accessor: "submissionDate" },
    ]

    ExportService.exportToPDF(filteredEmployees, {
      title: "Pending Employees List",
      filename: "pending-employees-list",
      columns,
    })

    toast({
      title: "Export Complete",
      description: "The PDF has been generated successfully.",
    })
  }

  const handleExportCSV = () => {
    const columns = [
      { header: "Name", accessor: "name" },
      { header: "Email", accessor: "email" },
      { header: "Department", accessor: "department" },
      { header: "Position", accessor: "position" },
      { header: "Status", accessor: "status" },
      { header: "Source", accessor: "source" },
      { header: "Submission Date", accessor: "submissionDate" },
    ]

    ExportService.exportToCSV(filteredEmployees, {
      title: "Pending Employees List",
      filename: "pending-employees-list",
      columns,
    })

    toast({
      title: "Export Complete",
      description: "The CSV file has been generated successfully.",
    })
  }

  const handlePrint = () => {
    const columns = [
      { header: "Name", accessor: "name" },
      { header: "Email", accessor: "email" },
      { header: "Department", accessor: "department" },
      { header: "Position", accessor: "position" },
      { header: "Status", accessor: "status" },
      { header: "Source", accessor: "source" },
      { header: "Submission Date", accessor: "submissionDate" },
    ]

    ExportService.printData(filteredEmployees, {
      title: "Pending Employees List",
      filename: "pending-employees-list",
      columns,
    })
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending_approval":
        return (
          <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
            <Clock className="h-3 w-3 mr-1" /> Pending Approval
          </Badge>
        )
      case "document_verification":
        return (
          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
            <Eye className="h-3 w-3 mr-1" /> Document Verification
          </Badge>
        )
      case "data_incomplete":
        return (
          <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
            <FileWarning className="h-3 w-3 mr-1" /> Data Incomplete
          </Badge>
        )
      default:
        return null
    }
  }

  const getSourceBadge = (source: string) => {
    switch (source) {
      case "form":
        return (
          <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200">
            Form Submission
          </Badge>
        )
      case "import":
        return (
          <Badge variant="outline" className="bg-teal-50 text-teal-700 border-teal-200">
            CSV Import
          </Badge>
        )
      default:
        return null
    }
  }

  // Advanced search fields
  const searchFields = [
    { name: "name", label: "Name", type: "text" as const },
    { name: "email", label: "Email", type: "text" as const },
    {
      name: "department",
      label: "Department",
      type: "select" as const,
      options: [
        { value: "Finance", label: "Finance" },
        { value: "HR", label: "HR" },
        { value: "IT", label: "IT" },
        { value: "Operations", label: "Operations" },
        { value: "Legal", label: "Legal" },
        { value: "Marketing", label: "Marketing" },
      ],
    },
    { name: "position", label: "Position", type: "text" as const },
    {
      name: "status",
      label: "Status",
      type: "select" as const,
      options: [
        { value: "pending_approval", label: "Pending Approval" },
        { value: "document_verification", label: "Document Verification" },
        { value: "data_incomplete", label: "Data Incomplete" },
      ],
    },
    {
      name: "source",
      label: "Source",
      type: "select" as const,
      options: [
        { value: "form", label: "Form Submission" },
        { value: "import", label: "CSV Import" },
      ],
    },
    { name: "submissionDate", label: "Submission Date", type: "date" as const },
  ]

  // Pagination logic
  const indexOfLastItem = currentPage * itemsPerPage
  const indexOfFirstItem = indexOfLastItem - itemsPerPage
  const currentItems = filteredEmployees.slice(indexOfFirstItem, indexOfLastItem)
  const totalPages = Math.ceil(filteredEmployees.length / itemsPerPage)

  const handlePageChange = (pageNumber: number) => {
    setCurrentPage(pageNumber)
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Pending Employees</h1>
          <p className="text-muted-foreground">Review and approve employee registration requests.</p>
        </div>
        <div className="flex items-center gap-2">
          <DataExportMenu
            onExportPDF={handleExportPDF}
            onExportCSV={handleExportCSV}
            onPrint={handlePrint}
            title="Pending Employees"
          />
        </div>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle>Pending Registrations</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
              <Input
                type="search"
                placeholder="Search pending registrations..."
                className="pl-9"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="flex flex-wrap gap-2">
              <div className="w-[150px]">
                <Select value={dateFilter} onValueChange={setDateFilter}>
                  <SelectTrigger>
                    <div className="flex items-center gap-2">
                      <Filter className="h-4 w-4" />
                      <SelectValue placeholder="Date" />
                    </div>
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Dates</SelectItem>
                    <SelectItem value="today">Today</SelectItem>
                    <SelectItem value="week">This Week</SelectItem>
                    <SelectItem value="month">This Month</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="w-[150px]">
                <Select value={departmentFilter} onValueChange={setDepartmentFilter}>
                  <SelectTrigger>
                    <div className="flex items-center gap-2">
                      <SlidersHorizontal className="h-4 w-4" />
                      <SelectValue placeholder="Department" />
                    </div>
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Departments</SelectItem>
                    <SelectItem value="Finance">Finance</SelectItem>
                    <SelectItem value="HR">HR</SelectItem>
                    <SelectItem value="IT">IT</SelectItem>
                    <SelectItem value="Operations">Operations</SelectItem>
                    <SelectItem value="Legal">Legal</SelectItem>
                    <SelectItem value="Marketing">Marketing</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="w-[150px]">
                <Select value={sourceFilter} onValueChange={setSourceFilter}>
                  <SelectTrigger>
                    <div className="flex items-center gap-2">
                      <Filter className="h-4 w-4" />
                      <SelectValue placeholder="Source" />
                    </div>
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Sources</SelectItem>
                    <SelectItem value="form">Form Submission</SelectItem>
                    <SelectItem value="import">CSV Import</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="w-[150px]">
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger>
                    <div className="flex items-center gap-2">
                      <Filter className="h-4 w-4" />
                      <SelectValue placeholder="Status" />
                    </div>
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    <SelectItem value="pending_approval">Pending Approval</SelectItem>
                    <SelectItem value="document_verification">Document Verification</SelectItem>
                    <SelectItem value="data_incomplete">Data Incomplete</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <AdvancedSearch onSearch={handleAdvancedSearch} fields={searchFields} title="Pending Employees" />
            </div>
          </div>

          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Applicant</TableHead>
                  <TableHead>Department</TableHead>
                  <TableHead>Position</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Source</TableHead>
                  <TableHead>Submission Date</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  <TableRow>
                    <TableCell colSpan={7} className="h-24 text-center">
                      <div className="flex justify-center items-center">
                        <Loader2 className="h-6 w-6 text-gray-500 animate-spin mr-2" />
                        <span>Loading pending employees...</span>
                      </div>
                    </TableCell>
                  </TableRow>
                ) : filteredEmployees.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="h-24 text-center">
                      No pending employees found.
                    </TableCell>
                  </TableRow>
                ) : (
                  currentItems.map((employee) => (
                    <TableRow key={employee.id}>
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <Avatar className="h-9 w-9">
                            <AvatarImage src={`/placeholder.svg?height=36&width=36`} alt={employee.name} />
                            <AvatarFallback>{employee.name.substring(0, 2).toUpperCase()}</AvatarFallback>
                          </Avatar>
                          <div>
                            <div className="font-medium">{employee.name}</div>
                            <div className="text-sm text-muted-foreground">{employee.email}</div>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>{employee.department}</TableCell>
                      <TableCell>{employee.position}</TableCell>
                      <TableCell>{getStatusBadge(employee.status)}</TableCell>
                      <TableCell>{getSourceBadge(employee.source)}</TableCell>
                      <TableCell>{new Date(employee.submissionDate).toLocaleDateString()}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-1">
                          {employee.status !== "data_incomplete" && (
                            <>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-8 w-8 text-green-600"
                                onClick={() => openApproveDialog(employee)}
                              >
                                <CheckCircle className="h-4 w-4" />
                                <span className="sr-only">Approve</span>
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-8 w-8 text-red-600"
                                onClick={() => openRejectDialog(employee)}
                              >
                                <X className="h-4 w-4" />
                                <span className="sr-only">Reject</span>
                              </Button>
                            </>
                          )}
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon" className="h-8 w-8">
                                <MoreHorizontal className="h-4 w-4" />
                                <span className="sr-only">Open menu</span>
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuLabel>Actions</DropdownMenuLabel>
                              <DropdownMenuItem>View details</DropdownMenuItem>
                              <DropdownMenuItem>View documents</DropdownMenuItem>
                              {employee.missingFields && employee.missingFields.length > 0 && (
                                <DropdownMenuItem onClick={() => handleViewMissingFields(employee)}>
                                  View missing fields
                                </DropdownMenuItem>
                              )}
                              <DropdownMenuSeparator />
                              {employee.status !== "data_incomplete" ? (
                                <>
                                  <DropdownMenuItem
                                    className="text-green-600"
                                    onClick={() => openApproveDialog(employee)}
                                  >
                                    Approve
                                  </DropdownMenuItem>
                                  <DropdownMenuItem className="text-red-600" onClick={() => openRejectDialog(employee)}>
                                    Reject
                                  </DropdownMenuItem>
                                </>
                              ) : (
                                <DropdownMenuItem className="text-amber-600">
                                  Waiting for data completion
                                </DropdownMenuItem>
                              )}
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>

          {filteredEmployees.length > 0 && (
            <div className="mt-4 flex items-center justify-end">
              <Pagination currentPage={currentPage} totalPages={totalPages} onPageChange={handlePageChange} />
            </div>
          )}
        </CardContent>
      </Card>

      {/* Missing Fields Dialog */}
      <Dialog open={showMissingFieldsDialog} onOpenChange={setShowMissingFieldsDialog}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Missing Fields</DialogTitle>
            <DialogDescription>
              The following fields are missing from {selectedEmployee?.name}'s profile. An email has been sent to the
              employee to complete these fields.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <div className="rounded-md bg-amber-50 p-4 border border-amber-200">
              <div className="flex items-start">
                <AlertCircle className="h-5 w-5 text-amber-600 mt-0.5 mr-3" />
                <div>
                  <h3 className="text-sm font-medium text-amber-800">Missing Information</h3>
                  <div className="mt-2 text-sm text-amber-700">
                    <ul className="list-disc pl-5 space-y-1">
                      {selectedEmployee?.missingFields?.map((field) => (
                        <li key={field}>
                          {field
                            .split("_")
                            .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
                            .join(" ")}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div className="mt-3 text-sm">
                    <p className="text-amber-700">
                      An email was sent to {selectedEmployee?.email} with a link to update this information.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button onClick={() => setShowMissingFieldsDialog(false)}>Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Approve Dialog */}
      <Dialog open={showApproveDialog} onOpenChange={setShowApproveDialog}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Approve Employee</DialogTitle>
            <DialogDescription>
              You are about to approve {selectedEmployee?.name}'s registration. An email notification will be sent to
              the employee.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4 space-y-4">
            <div className="space-y-2">
              <label htmlFor="approve-comment" className="text-sm font-medium">
                Additional Comments (Optional)
              </label>
              <Textarea
                id="approve-comment"
                placeholder="Add any additional information or instructions for the employee..."
                value={approveComment}
                onChange={(e) => setApproveComment(e.target.value)}
                rows={4}
              />
            </div>
            <div className="rounded-md bg-blue-50 p-4 border border-blue-200">
              <div className="flex items-start">
                <Mail className="h-5 w-5 text-blue-600 mt-0.5 mr-3" />
                <div>
                  <h3 className="text-sm font-medium text-blue-800">Email Notification</h3>
                  <div className="mt-1 text-sm text-blue-700">
                    <p>An email will be sent to {selectedEmployee?.email} with:</p>
                    <ul className="list-disc pl-5 mt-2 space-y-1">
                      <li>Employee ID and login information</li>
                      <li>Link to access the employee portal</li>
                      <li>Your additional comments (if provided)</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowApproveDialog(false)} disabled={isSubmitting}>
              Cancel
            </Button>
            <Button onClick={handleApproveEmployee} disabled={isSubmitting} className="bg-green-700 hover:bg-green-800">
              {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Approve & Send Email
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Reject Dialog */}
      <Dialog open={showRejectDialog} onOpenChange={setShowRejectDialog}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Reject Employee</DialogTitle>
            <DialogDescription>
              You are about to reject {selectedEmployee?.name}'s registration. Please provide a reason for rejection.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4 space-y-4">
            <div className="space-y-2">
              <label htmlFor="reject-comment" className="text-sm font-medium">
                Reason for Rejection <span className="text-red-500">*</span>
              </label>
              <Textarea
                id="reject-comment"
                placeholder="Explain why this registration is being rejected..."
                value={rejectComment}
                onChange={(e) => setRejectComment(e.target.value)}
                rows={4}
                required
              />
              {rejectComment.trim() === "" && (
                <p className="text-sm text-red-500">Please provide a reason for rejection</p>
              )}
            </div>
            <div className="rounded-md bg-amber-50 p-4 border border-amber-200">
              <div className="flex items-start">
                <Mail className="h-5 w-5 text-amber-600 mt-0.5 mr-3" />
                <div>
                  <h3 className="text-sm font-medium text-amber-800">Email Notification</h3>
                  <div className="mt-1 text-sm text-amber-700">
                    <p>An email will be sent to {selectedEmployee?.email} with:</p>
                    <ul className="list-disc pl-5 mt-2 space-y-1">
                      <li>The reason for rejection</li>
                      <li>Link to update their information</li>
                      <li>Instructions on how to resubmit</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowRejectDialog(false)} disabled={isSubmitting}>
              Cancel
            </Button>
            <Button
              onClick={handleRejectEmployee}
              disabled={isSubmitting || rejectComment.trim() === ""}
              variant="destructive"
            >
              {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Reject & Send Email
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
