"use client"

import Script from "next/script"

export default function HeadScript() {
  return (
    <Script
      id="initialize-patch"
      strategy="beforeInteractive"
      dangerouslySetInnerHTML={{
        __html: `
          // Patch to fix "initialize is not a function" errors
          (function() {
            // Add a global initialize function
            window.initialize = function() {
              console.log("Global initialize called");
              return true;
            };
            
            // Add initialize to Object.prototype
            if (!Object.prototype.hasOwnProperty('initialize')) {
              Object.defineProperty(Object.prototype, 'initialize', {
                value: function() {
                  console.log("Prototype initialize called");
                  return true;
                },
                writable: true,
                configurable: true,
                enumerable: false
              });
            }
            
            // Patch Function.prototype.apply to handle initialize calls
            const originalApply = Function.prototype.apply;
            Function.prototype.apply = function(thisArg, args) {
              if (this.name === 'initialize' && (!thisArg || typeof thisArg.initialize !== 'function')) {
                console.log("Intercepted initialize call on invalid object");
                return true;
              }
              return originalApply.call(this, thisArg, args);
            };
            
            console.log("Initialize patches applied");
          })();
        `,
      }}
    />
  )
}
