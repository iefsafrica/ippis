"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import {
  Users,
  UserCheck,
  UserPlus,
  FileText,
  AlertTriangle,
  CheckCircle2,
  Clock,
  TrendingUp,
  TrendingDown,
  Loader2,
  RefreshCw,
  Calendar,
  BarChart4,
  PieChart,
  ArrowRight,
  ChevronRight,
  Bell,
  Shield,
} from "lucide-react"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { RecentEmployeesTable } from "./components/recent-employees-table"
import { ActivityFeed } from "./components/activity-feed"
import { DashboardChart } from "./components/dashboard-chart"
import { DashboardService } from "./services/mock-data-service"
import { useToast } from "@/components/ui/use-toast"
import { PendingEmployeeService } from "./services/pending-employee-service"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { DashboardPieChart } from "./components/dashboard-pie-chart"
import { cn } from "@/lib/utils"

export default function DashboardContent() {
  const [stats, setStats] = useState({
    totalEmployees: 0,
    activeEmployees: 0,
    pendingRegistrations: 0,
    documentVerifications: 0,
    employeesByStatus: [] as { status: string; count: number }[],
    recentActivity: [] as { action: string; user: string; time: string; description: string }[],
  })
  const [chartData, setChartData] = useState({
    labels: [] as string[],
    datasets: [] as { label: string; data: number[] }[],
  })
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)
  const { toast } = useToast()
  const [currentDate] = useState(new Date())

  const loadDashboardData = async () => {
    setLoading(true)
    try {
      // Load statistics
      const statistics = await DashboardService.getStatistics()
      setStats(statistics)

      // Load chart data
      const chartData = await DashboardService.getChartData()
      setChartData(chartData)

      // Check for recent submissions (last 5 minutes)
      const recentPendingEmployees = await PendingEmployeeService.getPendingEmployees({
        date: "today",
      })

      // If there are recent submissions, show a toast notification
      if (recentPendingEmployees.length > 0) {
        const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000).toISOString()
        const veryRecentSubmissions = recentPendingEmployees.filter((emp) => emp.submissionDate >= fiveMinutesAgo)

        if (veryRecentSubmissions.length > 0) {
          toast({
            title: "New Submissions Received",
            description: `${veryRecentSubmissions.length} new employee submission(s) in the last 5 minutes.`,
            variant: "default",
          })
        }
      }
    } catch (error) {
      console.error("Failed to load dashboard data:", error)
      toast({
        title: "Error",
        description: "Failed to load dashboard data. Please try again.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadDashboardData()

    // Set up a refresh interval
    const refreshInterval = setInterval(() => {
      loadDashboardData()
    }, 30000) // Refresh every 30 seconds

    return () => clearInterval(refreshInterval)
  }, [toast])

  const handleRefresh = async () => {
    setRefreshing(true)
    await loadDashboardData()
    setRefreshing(false)

    toast({
      title: "Dashboard Refreshed",
      description: "Dashboard data has been updated.",
    })
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-[calc(100vh-200px)]">
        <div className="flex flex-col items-center">
          <Loader2 className="h-8 w-8 text-green-700 animate-spin mb-4" />
          <p className="text-muted-foreground">Loading dashboard data...</p>
        </div>
      </div>
    )
  }

  // Format date for display
  const formattedDate = new Intl.DateTimeFormat("en-US", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  }).format(currentDate)

  return (
    <div className="space-y-8">
      {/* Dashboard Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-gradient-to-r from-green-50 to-white p-6 rounded-xl shadow-sm">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-green-800">Welcome to IPPIS Admin</h1>
          <div className="flex items-center mt-2 text-muted-foreground">
            <Calendar className="h-4 w-4 mr-2" />
            <span>{formattedDate}</span>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <Button
            variant="outline"
            onClick={handleRefresh}
            disabled={refreshing}
            className="flex items-center gap-2 border-green-200 hover:bg-green-50 hover:text-green-700 transition-all"
          >
            {refreshing ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
            Refresh Dashboard
          </Button>
          <Button className="bg-green-700 hover:bg-green-800 text-white">
            <Bell className="h-4 w-4 mr-2" />
            <span className="hidden md:inline">Notifications</span>
            <Badge variant="secondary" className="ml-2 bg-white text-green-800">
              {stats.pendingRegistrations}
            </Badge>
          </Button>
        </div>
      </div>

      {/* Quick Stats Cards */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card className="overflow-hidden border-none shadow-md hover:shadow-lg transition-all duration-300">
          <div className="absolute top-0 right-0 h-20 w-20 bg-green-100 rounded-bl-full opacity-70"></div>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Employees</CardTitle>
            <div className="h-10 w-10 rounded-full bg-green-100 flex items-center justify-center">
              <Users className="h-5 w-5 text-green-700" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-800">{stats.totalEmployees.toLocaleString()}</div>
            <div className="flex items-center mt-2">
              <TrendingUp className="h-4 w-4 text-green-600 mr-1" />
              <span className="text-green-600 font-medium text-sm">+2.5%</span>
              <span className="text-xs text-muted-foreground ml-1">from last month</span>
            </div>
          </CardContent>
        </Card>

        <Card className="overflow-hidden border-none shadow-md hover:shadow-lg transition-all duration-300">
          <div className="absolute top-0 right-0 h-20 w-20 bg-blue-100 rounded-bl-full opacity-70"></div>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Employees</CardTitle>
            <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center">
              <UserCheck className="h-5 w-5 text-blue-700" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-blue-800">{stats.activeEmployees.toLocaleString()}</div>
            <div className="flex items-center mt-2">
              <TrendingUp className="h-4 w-4 text-green-600 mr-1" />
              <span className="text-green-600 font-medium text-sm">+1.2%</span>
              <span className="text-xs text-muted-foreground ml-1">from last month</span>
            </div>
          </CardContent>
        </Card>

        <Card className="overflow-hidden border-none shadow-md hover:shadow-lg transition-all duration-300">
          <div className="absolute top-0 right-0 h-20 w-20 bg-amber-100 rounded-bl-full opacity-70"></div>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Registrations</CardTitle>
            <div className="h-10 w-10 rounded-full bg-amber-100 flex items-center justify-center">
              <UserPlus className="h-5 w-5 text-amber-700" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-amber-800">{stats.pendingRegistrations.toLocaleString()}</div>
            <div className="flex items-center mt-2">
              <TrendingDown className="h-4 w-4 text-red-600 mr-1" />
              <span className="text-red-600 font-medium text-sm">-12.5%</span>
              <span className="text-xs text-muted-foreground ml-1">from last month</span>
            </div>
          </CardContent>
        </Card>

        <Card className="overflow-hidden border-none shadow-md hover:shadow-lg transition-all duration-300">
          <div className="absolute top-0 right-0 h-20 w-20 bg-purple-100 rounded-bl-full opacity-70"></div>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Document Verifications</CardTitle>
            <div className="h-10 w-10 rounded-full bg-purple-100 flex items-center justify-center">
              <FileText className="h-5 w-5 text-purple-700" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-purple-800">{stats.documentVerifications.toLocaleString()}</div>
            <div className="flex items-center mt-2">
              <TrendingUp className="h-4 w-4 text-green-600 mr-1" />
              <span className="text-green-600 font-medium text-sm">+18.7%</span>
              <span className="text-xs text-muted-foreground ml-1">from last month</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts Section */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-7">
        <Card className="lg:col-span-4 border-none shadow-md hover:shadow-lg transition-all duration-300">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-lg font-bold">Employee Statistics</CardTitle>
                <CardDescription>Monthly employee registration and verification trends</CardDescription>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                  <BarChart4 className="h-3 w-3 mr-1" />
                  Registrations
                </Badge>
                <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                  <FileText className="h-3 w-3 mr-1" />
                  Verifications
                </Badge>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <DashboardChart data={chartData} />
          </CardContent>
        </Card>

        <Card className="lg:col-span-3 border-none shadow-md hover:shadow-lg transition-all duration-300">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-lg font-bold">Registration Status</CardTitle>
                <CardDescription>Current status of employee registrations</CardDescription>
              </div>
              <PieChart className="h-5 w-5 text-muted-foreground" />
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex justify-center mb-4">
              <DashboardPieChart data={stats.employeesByStatus} />
            </div>
            {stats.employeesByStatus.map((status) => {
              const total = stats.totalEmployees + stats.pendingRegistrations
              const percentage = total > 0 ? (status.count / total) * 100 : 0

              let icon = <CheckCircle2 className="h-4 w-4 text-green-500 mr-2" />
              let color = "bg-green-500"
              let textColor = "text-green-700"
              let bgColor = "bg-green-50"

              if (status.status === "Pending") {
                icon = <Clock className="h-4 w-4 text-amber-500 mr-2" />
                color = "bg-amber-500"
                textColor = "text-amber-700"
                bgColor = "bg-amber-50"
              } else if (status.status === "Inactive") {
                icon = <AlertTriangle className="h-4 w-4 text-red-500 mr-2" />
                color = "bg-red-500"
                textColor = "text-red-700"
                bgColor = "bg-red-50"
              }

              return (
                <div key={status.status} className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <div className={cn("flex items-center px-2 py-1 rounded-full", bgColor)}>
                      {icon}
                      <span className={textColor}>{status.status}</span>
                    </div>
                    <div className="flex items-center">
                      <span className="font-medium">{status.count.toLocaleString()}</span>
                      <span className="text-xs text-muted-foreground ml-2">({percentage.toFixed(1)}%)</span>
                    </div>
                  </div>
                  <Progress value={percentage} className="h-2 bg-gray-100" indicatorClassName={color} />
                </div>
              )
            })}
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="border-none shadow-md hover:shadow-lg transition-all duration-300 bg-gradient-to-br from-green-50 to-white">
          <CardHeader>
            <CardTitle className="flex items-center text-green-800">
              <Shield className="h-5 w-5 mr-2" />
              Quick Actions
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button
              variant="outline"
              className="w-full justify-between group hover:bg-green-50 hover:text-green-700 border-green-200"
            >
              <span className="flex items-center">
                <UserPlus className="h-4 w-4 mr-2" />
                Add New Employee
              </span>
              <ChevronRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
            </Button>
            <Button
              variant="outline"
              className="w-full justify-between group hover:bg-green-50 hover:text-green-700 border-green-200"
            >
              <span className="flex items-center">
                <FileText className="h-4 w-4 mr-2" />
                Verify Documents
              </span>
              <ChevronRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
            </Button>
            <Button
              variant="outline"
              className="w-full justify-between group hover:bg-green-50 hover:text-green-700 border-green-200"
            >
              <span className="flex items-center">
                <BarChart4 className="h-4 w-4 mr-2" />
                Generate Reports
              </span>
              <ChevronRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
            </Button>
          </CardContent>
        </Card>

        {/* Employees Section */}
        <Card className="md:col-span-2 border-none shadow-md hover:shadow-lg transition-all duration-300">
          <Tabs defaultValue="pending">
            <CardHeader className="pb-0">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg font-bold">Employees</CardTitle>
                <TabsList className="bg-gray-100">
                  <TabsTrigger value="recent" className="data-[state=active]:bg-white">
                    Recent
                  </TabsTrigger>
                  <TabsTrigger value="pending" className="data-[state=active]:bg-white">
                    Pending
                  </TabsTrigger>
                </TabsList>
              </div>
            </CardHeader>
            <CardContent>
              <TabsContent value="recent" className="mt-0 pt-3">
                <RecentEmployeesTable />
              </TabsContent>
              <TabsContent value="pending" className="mt-0 pt-3">
                <RecentEmployeesTable pending />
              </TabsContent>
            </CardContent>
            <CardFooter className="border-t pt-4 flex justify-center">
              <Button
                variant="outline"
                className="flex items-center gap-2 hover:bg-green-50 hover:text-green-700 border-green-200"
              >
                View All Employees
                <ArrowRight className="h-4 w-4" />
              </Button>
            </CardFooter>
          </Tabs>
        </Card>
      </div>

      {/* Activity Feed */}
      <Card className="border-none shadow-md hover:shadow-lg transition-all duration-300">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-lg font-bold">Recent Activity</CardTitle>
              <CardDescription>Latest actions in the system</CardDescription>
            </div>
            <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
              Today
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <ActivityFeed activities={stats.recentActivity} />
        </CardContent>
        <CardFooter className="border-t pt-4 flex justify-center">
          <Button
            variant="outline"
            className="flex items-center gap-2 hover:bg-green-50 hover:text-green-700 border-green-200"
          >
            View All Activity
            <ArrowRight className="h-4 w-4" />
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}
