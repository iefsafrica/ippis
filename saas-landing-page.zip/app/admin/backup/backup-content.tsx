"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Database, Download, CheckCircle, AlertTriangle, RefreshCw, HardDrive, Save } from "lucide-react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function BackupContent() {
  const [backupInProgress, setBackupInProgress] = useState(false)
  const [backupProgress, setBackupProgress] = useState(0)
  const [restoreInProgress, setRestoreInProgress] = useState(false)
  const [restoreProgress, setRestoreProgress] = useState(0)

  const handleBackup = () => {
    setBackupInProgress(true)
    setBackupProgress(0)

    // Simulate backup progress
    const interval = setInterval(() => {
      setBackupProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          setBackupInProgress(false)
          return 100
        }
        return prev + 5
      })
    }, 300)
  }

  const handleRestore = () => {
    setRestoreInProgress(true)
    setRestoreProgress(0)

    // Simulate restore progress
    const interval = setInterval(() => {
      setRestoreProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          setRestoreInProgress(false)
          return 100
        }
        return prev + 2
      })
    }, 200)
  }

  // Mock data for backup history
  const backupHistory = [
    {
      id: "BKP12345",
      date: "2023-11-20T08:30:00",
      size: "256 MB",
      type: "Automatic",
      status: "Completed",
    },
    {
      id: "BKP12344",
      date: "2023-11-19T08:30:00",
      size: "255 MB",
      type: "Automatic",
      status: "Completed",
    },
    {
      id: "BKP12343",
      date: "2023-11-18T14:15:00",
      size: "254 MB",
      type: "Manual",
      status: "Completed",
    },
    {
      id: "BKP12342",
      date: "2023-11-17T08:30:00",
      size: "253 MB",
      type: "Automatic",
      status: "Completed",
    },
    {
      id: "BKP12341",
      date: "2023-11-16T08:30:00",
      size: "252 MB",
      type: "Automatic",
      status: "Completed",
    },
    {
      id: "BKP12340",
      date: "2023-11-15T08:30:00",
      size: "251 MB",
      type: "Automatic",
      status: "Failed",
    },
    {
      id: "BKP12339",
      date: "2023-11-14T08:30:00",
      size: "250 MB",
      type: "Automatic",
      status: "Completed",
    },
  ]

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Database Backup</h1>
        <p className="text-muted-foreground">Manage database backups and restoration.</p>
      </div>

      <Tabs defaultValue="backup" className="space-y-6">
        <TabsList className="grid grid-cols-3 w-full max-w-md">
          <TabsTrigger value="backup">Backup</TabsTrigger>
          <TabsTrigger value="restore">Restore</TabsTrigger>
          <TabsTrigger value="history">History</TabsTrigger>
        </TabsList>

        <TabsContent value="backup" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Create Database Backup</CardTitle>
              <CardDescription>Create a backup of the entire database or specific tables.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid gap-6 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="backup-type">Backup Type</Label>
                  <Select defaultValue="full">
                    <SelectTrigger id="backup-type">
                      <SelectValue placeholder="Select backup type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="full">Full Backup</SelectItem>
                      <SelectItem value="incremental">Incremental Backup</SelectItem>
                      <SelectItem value="differential">Differential Backup</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="backup-location">Backup Location</Label>
                  <Select defaultValue="local">
                    <SelectTrigger id="backup-location">
                      <SelectValue placeholder="Select backup location" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="local">Local Storage</SelectItem>
                      <SelectItem value="cloud">Cloud Storage</SelectItem>
                      <SelectItem value="external">External Drive</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="compression">Compression Level</Label>
                  <Select defaultValue="medium">
                    <SelectTrigger id="compression">
                      <SelectValue placeholder="Select compression level" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">None</SelectItem>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="encryption">Encryption</Label>
                  <Select defaultValue="aes256">
                    <SelectTrigger id="encryption">
                      <SelectValue placeholder="Select encryption method" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">None</SelectItem>
                      <SelectItem value="aes128">AES-128</SelectItem>
                      <SelectItem value="aes256">AES-256</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="backup-name">Backup Name (Optional)</Label>
                <Input id="backup-name" placeholder="Enter a name for this backup" />
              </div>

              {backupInProgress && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span>Backup in progress...</span>
                    <span>{backupProgress}%</span>
                  </div>
                  <Progress value={backupProgress} className="h-2" />
                </div>
              )}

              {backupProgress === 100 && !backupInProgress && (
                <Alert className="bg-green-50 border-green-200">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <AlertTitle className="text-green-600">Backup Completed</AlertTitle>
                  <AlertDescription className="text-green-700">
                    Database backup has been successfully created and stored.
                  </AlertDescription>
                </Alert>
              )}
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button onClick={handleBackup} disabled={backupInProgress} className="bg-green-700 hover:bg-green-800">
                {backupInProgress ? (
                  <>
                    <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                    Backing Up...
                  </>
                ) : (
                  <>
                    <Database className="h-4 w-4 mr-2" />
                    Create Backup
                  </>
                )}
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Scheduled Backups</CardTitle>
              <CardDescription>Configure automatic backup schedules.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid gap-6 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="schedule-frequency">Backup Frequency</Label>
                  <Select defaultValue="daily">
                    <SelectTrigger id="schedule-frequency">
                      <SelectValue placeholder="Select frequency" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="hourly">Hourly</SelectItem>
                      <SelectItem value="daily">Daily</SelectItem>
                      <SelectItem value="weekly">Weekly</SelectItem>
                      <SelectItem value="monthly">Monthly</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="schedule-time">Backup Time</Label>
                  <Input id="schedule-time" type="time" defaultValue="02:00" />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="retention-period">Retention Period (days)</Label>
                  <Input id="retention-period" type="number" defaultValue="30" />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="max-backups">Maximum Backups to Keep</Label>
                  <Input id="max-backups" type="number" defaultValue="10" />
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button className="bg-green-700 hover:bg-green-800">
                <Save className="h-4 w-4 mr-2" />
                Save Schedule
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="restore" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Restore Database</CardTitle>
              <CardDescription>Restore the database from a previous backup.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <Alert className="bg-amber-50 border-amber-200">
                <AlertTriangle className="h-4 w-4 text-amber-600" />
                <AlertTitle className="text-amber-600">Warning</AlertTitle>
                <AlertDescription className="text-amber-700">
                  Restoring a database will overwrite the current data. This action cannot be undone.
                </AlertDescription>
              </Alert>

              <div className="space-y-2">
                <Label htmlFor="restore-source">Restore Source</Label>
                <Select defaultValue="local">
                  <SelectTrigger id="restore-source">
                    <SelectValue placeholder="Select restore source" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="local">Local Backup</SelectItem>
                    <SelectItem value="cloud">Cloud Backup</SelectItem>
                    <SelectItem value="upload">Upload Backup File</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="backup-file">Select Backup</Label>
                <Select defaultValue="BKP12345">
                  <SelectTrigger id="backup-file">
                    <SelectValue placeholder="Select backup file" />
                  </SelectTrigger>
                  <SelectContent>
                    {backupHistory.map((backup) => (
                      <SelectItem key={backup.id} value={backup.id}>
                        {backup.id} - {new Date(backup.date).toLocaleString()} ({backup.size})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="restore-options">Restore Options</Label>
                <Select defaultValue="complete">
                  <SelectTrigger id="restore-options">
                    <SelectValue placeholder="Select restore options" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="complete">Complete Restore</SelectItem>
                    <SelectItem value="data-only">Data Only</SelectItem>
                    <SelectItem value="structure-only">Structure Only</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {restoreInProgress && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span>Restore in progress...</span>
                    <span>{restoreProgress}%</span>
                  </div>
                  <Progress value={restoreProgress} className="h-2" />
                </div>
              )}

              {restoreProgress === 100 && !restoreInProgress && (
                <Alert className="bg-green-50 border-green-200">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <AlertTitle className="text-green-600">Restore Completed</AlertTitle>
                  <AlertDescription className="text-green-700">
                    Database has been successfully restored from the backup.
                  </AlertDescription>
                </Alert>
              )}
            </CardContent>
            <CardFooter className="flex justify-end">
              <Button onClick={handleRestore} disabled={restoreInProgress} className="bg-green-700 hover:bg-green-800">
                {restoreInProgress ? (
                  <>
                    <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                    Restoring...
                  </>
                ) : (
                  <>
                    <HardDrive className="h-4 w-4 mr-2" />
                    Restore Database
                  </>
                )}
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="history" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Backup History</CardTitle>
              <CardDescription>View and manage previous database backups.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Backup ID</TableHead>
                      <TableHead>Date & Time</TableHead>
                      <TableHead>Size</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {backupHistory.map((backup) => (
                      <TableRow key={backup.id}>
                        <TableCell className="font-medium">{backup.id}</TableCell>
                        <TableCell>{new Date(backup.date).toLocaleString()}</TableCell>
                        <TableCell>{backup.size}</TableCell>
                        <TableCell>{backup.type}</TableCell>
                        <TableCell>
                          {backup.status === "Completed" ? (
                            <span className="flex items-center text-green-600 text-sm">
                              <CheckCircle className="h-3 w-3 mr-1" /> {backup.status}
                            </span>
                          ) : (
                            <span className="flex items-center text-red-600 text-sm">
                              <AlertTriangle className="h-3 w-3 mr-1" /> {backup.status}
                            </span>
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-1">
                            <Button variant="ghost" size="icon" className="h-8 w-8">
                              <Download className="h-4 w-4" />
                              <span className="sr-only">Download</span>
                            </Button>
                            <Button variant="ghost" size="icon" className="h-8 w-8">
                              <HardDrive className="h-4 w-4" />
                              <span className="sr-only">Restore</span>
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
