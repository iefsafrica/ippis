import type React from "react"
import type { Metadata } from "next"
import { AdminSidebar } from "./components/admin-sidebar"
import { AdminHeader } from "./components/admin-header"
import { Suspense } from "react"
import AdminLoading from "./loading"
import GlobalPatch from "./global-patch"
import HeadScript from "./head-script"
import { headers } from "next/headers"

export const metadata: Metadata = {
  title: "Admin Dashboard | IPPIS Nigeria",
  description: "Administrative dashboard for the Integrated Personnel and Payroll Information System",
}

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  // Get the current pathname from headers
  const headersList = headers()
  const pathname = headersList.get("x-pathname") || ""

  // Check if the current path is the login page
  const isLoginPage = pathname.includes("/admin/login")

  // If it's the login page, don't apply the admin layout
  if (isLoginPage) {
    return <>{children}</>
  }

  // Otherwise, apply the full admin layout with sidebar
  return (
    <>
      <HeadScript />
      <div className="min-h-screen bg-gray-50 flex">
        {/* Apply global patches to fix initialization errors */}
        <GlobalPatch />

        <AdminSidebar />
        <div className="flex-1 flex flex-col">
          <AdminHeader />
          <main className="flex-1 p-6 overflow-y-auto">
            <Suspense fallback={<AdminLoading />}>{children}</Suspense>
          </main>
        </div>
      </div>
    </>
  )
}
