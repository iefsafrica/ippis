import type { Metadata } from "next"
import HelpClientWrapper from "./client-wrapper"

export const metadata: Metadata = {
  title: "IPPIS - Help & Support",
  description: "Get help and support for the IPPIS system",
}

export default function HelpPage() {
  return <HelpClientWrapper />
}
