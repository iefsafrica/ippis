"use client"

import type React from "react"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { useState } from "react"
import { useToast } from "@/components/ui/use-toast"
import { Download, Mail, Phone, Clock } from "lucide-react"

export default function HelpContent() {
  const [searchQuery, setSearchQuery] = useState("")
  const [contactForm, setContactForm] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const { toast } = useToast()

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value)
  }

  const handleContactFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setContactForm((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate form submission
    setTimeout(() => {
      setIsSubmitting(false)
      toast({
        title: "Support request submitted",
        description: "We'll get back to you as soon as possible.",
      })
      setContactForm({
        name: "",
        email: "",
        subject: "",
        message: "",
      })
    }, 1500)
  }

  const faqs = [
    {
      question: "How do I reset my password?",
      answer:
        "You can reset your password by clicking on the 'Forgot Password' link on the login page. You will receive an email with instructions to reset your password.",
    },
    {
      question: "How do I update my personal information?",
      answer:
        "You can update your personal information by logging into your account and navigating to the Profile section. Click on 'Edit Profile' to make changes.",
    },
    {
      question: "How do I submit a document for approval?",
      answer:
        "You can submit documents for approval by navigating to the Documents section and clicking on the 'Upload Document' button. Follow the prompts to complete the submission.",
    },
    {
      question: "How long does the approval process take?",
      answer:
        "The approval process typically takes 2-3 business days, but may take longer during peak periods or if additional information is required.",
    },
    {
      question: "Can I track the status of my submission?",
      answer:
        "Yes, you can track the status of your submission by going to the 'Track' page and entering your submission ID or by checking your dashboard.",
    },
    {
      question: "What file formats are supported for document uploads?",
      answer:
        "We support PDF, JPG, PNG, and DOCX file formats for document uploads. The maximum file size is 10MB per document.",
    },
  ]

  const userGuides = [
    {
      title: "Employee User Guide",
      description: "Complete guide for employees on using the IPPIS system",
      fileSize: "2.4 MB",
      fileType: "PDF",
    },
    {
      title: "Administrator User Guide",
      description: "Comprehensive guide for system administrators",
      fileSize: "3.1 MB",
      fileType: "PDF",
    },
    {
      title: "Document Submission Guide",
      description: "Step-by-step instructions for submitting documents",
      fileSize: "1.8 MB",
      fileType: "PDF",
    },
    {
      title: "Registration Process Guide",
      description: "Guide to completing the registration process",
      fileSize: "1.5 MB",
      fileType: "PDF",
    },
  ]

  const filteredFaqs = searchQuery
    ? faqs.filter(
        (faq) =>
          faq.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
          faq.answer.toLowerCase().includes(searchQuery.toLowerCase()),
      )
    : faqs

  const filteredGuides = searchQuery
    ? userGuides.filter(
        (guide) =>
          guide.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          guide.description.toLowerCase().includes(searchQuery.toLowerCase()),
      )
    : userGuides

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Help & Support</h1>
        <p className="text-muted-foreground">Get assistance with using the IPPIS system.</p>
      </div>

      <div className="relative mb-6">
        <Input
          type="search"
          placeholder="Search for help topics..."
          value={searchQuery}
          onChange={handleSearchChange}
          className="pl-4 pr-10"
        />
      </div>

      <Tabs defaultValue="faqs" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="faqs">FAQs</TabsTrigger>
          <TabsTrigger value="guides">User Guides</TabsTrigger>
          <TabsTrigger value="contact">Contact Support</TabsTrigger>
        </TabsList>

        <TabsContent value="faqs" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Frequently Asked Questions</CardTitle>
            </CardHeader>
            <CardContent>
              {filteredFaqs.length === 0 ? (
                <p className="text-center py-4 text-muted-foreground">No FAQs match your search query.</p>
              ) : (
                <Accordion type="single" collapsible className="w-full">
                  {filteredFaqs.map((faq, index) => (
                    <AccordionItem key={index} value={`item-${index}`}>
                      <AccordionTrigger>{faq.question}</AccordionTrigger>
                      <AccordionContent>{faq.answer}</AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="guides" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>User Guides & Documentation</CardTitle>
            </CardHeader>
            <CardContent>
              {filteredGuides.length === 0 ? (
                <p className="text-center py-4 text-muted-foreground">No guides match your search query.</p>
              ) : (
                <div className="grid gap-4">
                  {filteredGuides.map((guide, index) => (
                    <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                      <div>
                        <h3 className="font-medium">{guide.title}</h3>
                        <p className="text-sm text-muted-foreground">{guide.description}</p>
                        <p className="text-xs text-muted-foreground mt-1">
                          {guide.fileSize} • {guide.fileType}
                        </p>
                      </div>
                      <Button variant="outline" size="sm" className="gap-1">
                        <Download className="h-4 w-4" />
                        Download
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="contact" className="mt-6">
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Contact Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-3">
                  <Mail className="h-5 w-5 text-muted-foreground" />
                  <div>
                    <p className="font-medium">Email Support</p>
                    <p className="text-sm text-muted-foreground">support@ippis.gov.ng</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Phone className="h-5 w-5 text-muted-foreground" />
                  <div>
                    <p className="font-medium">Phone Support</p>
                    <p className="text-sm text-muted-foreground">+234 (0) 1234 5678</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Clock className="h-5 w-5 text-muted-foreground" />
                  <div>
                    <p className="font-medium">Support Hours</p>
                    <p className="text-sm text-muted-foreground">Monday - Friday, 8:00 AM - 5:00 PM</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Send a Message</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleContactSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Name</Label>
                    <Input id="name" name="name" value={contactForm.name} onChange={handleContactFormChange} required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      value={contactForm.email}
                      onChange={handleContactFormChange}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="subject">Subject</Label>
                    <Input
                      id="subject"
                      name="subject"
                      value={contactForm.subject}
                      onChange={handleContactFormChange}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="message">Message</Label>
                    <Textarea
                      id="message"
                      name="message"
                      rows={4}
                      value={contactForm.message}
                      onChange={handleContactFormChange}
                      required
                    />
                  </div>
                  <Button type="submit" className="w-full bg-green-700 hover:bg-green-800" disabled={isSubmitting}>
                    {isSubmitting ? "Sending..." : "Send Message"}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
