"use client"

import { useEffect } from "react"
import { initializeServices } from "./services/initialize-services"

export default function ClientInitializer() {
  useEffect(() => {
    // Initialize services on the client side
    initializeServices()
  }, [])

  // This component doesn't render anything
  return null
}
