"use client"

import { useState, useEffect } from "react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  CheckCircle,
  Clock,
  AlertTriangle,
  MoreHorizontal,
  Loader2,
  RefreshCw,
  Eye,
  UserCheck,
  UserX,
  FileText,
} from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { type Employee, EmployeeService, type PendingEmployee } from "../services/mock-data-service"
import { PendingEmployeeService } from "../services/pending-employee-service"
import { useToast } from "@/components/ui/use-toast"
import { CommentDialog } from "./comment-dialog"
import { cn } from "@/lib/utils"

interface RecentEmployeesTableProps {
  pending?: boolean
}

export function RecentEmployeesTable({ pending = false }: RecentEmployeesTableProps) {
  const [employees, setEmployees] = useState<Employee[] | PendingEmployee[]>([])
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)
  const [showApproveDialog, setShowApproveDialog] = useState(false)
  const [showRejectDialog, setShowRejectDialog] = useState(false)
  const [selectedEmployee, setSelectedEmployee] = useState<PendingEmployee | null>(null)
  const { toast } = useToast()

  const loadEmployees = async () => {
    setLoading(true)
    try {
      if (pending) {
        const data = await PendingEmployeeService.getPendingEmployees()
        setEmployees(data.slice(0, 5)) // Show only 5 most recent
      } else {
        const data = await EmployeeService.getEmployees()
        setEmployees(data.slice(0, 5)) // Show only 5 most recent
      }
    } catch (error) {
      console.error("Failed to load employees:", error)
      toast({
        title: "Error",
        description: "Failed to load employees. Please try again.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadEmployees()

    // Set up a refresh interval
    const refreshInterval = setInterval(() => {
      loadEmployees()
    }, 30000) // Refresh every 30 seconds

    return () => clearInterval(refreshInterval)
  }, [pending, toast])

  // Handle manual refresh
  const handleRefresh = async () => {
    setRefreshing(true)
    await loadEmployees()
    setRefreshing(false)

    toast({
      title: "Refreshed",
      description: "Employee data has been refreshed.",
    })
  }

  // Handle opening the approve dialog
  const handleOpenApproveDialog = (employee: PendingEmployee) => {
    setSelectedEmployee(employee)
    setShowApproveDialog(true)
  }

  // Handle opening the reject dialog
  const handleOpenRejectDialog = (employee: PendingEmployee) => {
    setSelectedEmployee(employee)
    setShowRejectDialog(true)
  }

  // Handle approving a pending employee with comment
  const handleApprove = async (comment: string) => {
    if (!selectedEmployee) return

    try {
      await PendingEmployeeService.approvePendingEmployee(selectedEmployee.id, comment)

      // Refresh the list
      loadEmployees()

      toast({
        title: "Success",
        description: `${selectedEmployee.name} has been approved successfully.`,
      })
    } catch (error) {
      console.error("Failed to approve employee:", error)
      toast({
        title: "Error",
        description: "Failed to approve employee. Please try again.",
        variant: "destructive",
      })
      throw error // Re-throw to be caught by the CommentDialog
    }
  }

  // Handle rejecting a pending employee with comment
  const handleReject = async (comment: string) => {
    if (!selectedEmployee) return

    try {
      await PendingEmployeeService.rejectPendingEmployee(selectedEmployee.id, comment)

      // Refresh the list
      loadEmployees()

      toast({
        title: "Success",
        description: `${selectedEmployee.name} has been rejected.`,
      })
    } catch (error) {
      console.error("Failed to reject employee:", error)
      toast({
        title: "Error",
        description: "Failed to reject employee. Please try again.",
        variant: "destructive",
      })
      throw error // Re-throw to be caught by the CommentDialog
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "active":
        return (
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200 font-normal">
            <CheckCircle className="h-3 w-3 mr-1" /> Active
          </Badge>
        )
      case "pending":
      case "pending_approval":
        return (
          <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200 font-normal">
            <Clock className="h-3 w-3 mr-1" /> Pending
          </Badge>
        )
      case "document_verification":
        return (
          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200 font-normal">
            <Clock className="h-3 w-3 mr-1" /> Verification
          </Badge>
        )
      case "inactive":
        return (
          <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200 font-normal">
            <AlertTriangle className="h-3 w-3 mr-1" /> Inactive
          </Badge>
        )
      default:
        return null
    }
  }

  return (
    <>
      <div className="overflow-x-auto">
        <div className="flex justify-end mb-2">
          <Button
            variant="outline"
            size="sm"
            onClick={handleRefresh}
            disabled={refreshing || loading}
            className="text-xs border-green-200 hover:bg-green-50 hover:text-green-700"
          >
            {refreshing ? <Loader2 className="h-3 w-3 mr-1 animate-spin" /> : <RefreshCw className="h-3 w-3 mr-1" />}
            Refresh
          </Button>
        </div>

        {loading ? (
          <div className="flex justify-center items-center h-[200px]">
            <Loader2 className="h-6 w-6 text-green-500 animate-spin mr-2" />
            <span>Loading...</span>
          </div>
        ) : employees.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">No employees found.</div>
        ) : (
          <div className="bg-white rounded-lg overflow-hidden shadow-sm">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-gray-50 border-b border-gray-200">
                  <th className="text-left font-medium text-gray-500 py-3 px-4">Employee</th>
                  <th className="text-left font-medium text-gray-500 py-3 px-4">Department</th>
                  <th className="text-left font-medium text-gray-500 py-3 px-4">Status</th>
                  <th className="text-right font-medium text-gray-500 py-3 px-4"></th>
                </tr>
              </thead>
              <tbody>
                {employees.map((employee, index) => (
                  <tr
                    key={employee.id}
                    className={cn(
                      "border-b border-gray-100 hover:bg-gray-50 transition-colors",
                      // Highlight rows for employees submitted today
                      new Date(employee.submissionDate || employee.joinDate).toDateString() ===
                        new Date().toDateString()
                        ? "bg-green-50"
                        : "",
                      // Add alternating row colors
                      index % 2 === 0 ? "bg-white" : "bg-gray-50",
                    )}
                  >
                    <td className="py-3 px-4">
                      <div className="flex items-center">
                        <Avatar className="h-9 w-9 mr-3 border-2 border-white shadow-sm">
                          <AvatarImage src={`/placeholder.svg?height=36&width=36`} alt={employee.name} />
                          <AvatarFallback className="bg-green-100 text-green-800">
                            {employee.name.substring(0, 2).toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="font-medium text-gray-800">{employee.name}</div>
                          <div className="text-gray-500 text-xs">{employee.email}</div>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="px-2 py-1 bg-gray-100 text-gray-800 rounded-full text-xs inline-block">
                        {employee.department}
                      </div>
                    </td>
                    <td className="py-3 px-4">{getStatusBadge(employee.status)}</td>
                    <td className="py-3 px-4 text-right">
                      {pending ? (
                        <div className="flex justify-end gap-1">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-green-600 hover:bg-green-50"
                            onClick={() => handleOpenApproveDialog(employee as PendingEmployee)}
                          >
                            <UserCheck className="h-4 w-4" />
                            <span className="sr-only">Approve</span>
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-red-600 hover:bg-red-50"
                            onClick={() => handleOpenRejectDialog(employee as PendingEmployee)}
                          >
                            <UserX className="h-4 w-4" />
                            <span className="sr-only">Reject</span>
                          </Button>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon" className="h-8 w-8 hover:bg-gray-100">
                                <MoreHorizontal className="h-4 w-4" />
                                <span className="sr-only">Open menu</span>
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end" className="w-48">
                              <DropdownMenuLabel>Actions</DropdownMenuLabel>
                              <DropdownMenuItem className="flex items-center">
                                <Eye className="h-4 w-4 mr-2" />
                                View details
                              </DropdownMenuItem>
                              <DropdownMenuItem className="flex items-center">
                                <FileText className="h-4 w-4 mr-2" />
                                View documents
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem
                                className="text-green-600 flex items-center"
                                onClick={() => handleOpenApproveDialog(employee as PendingEmployee)}
                              >
                                <UserCheck className="h-4 w-4 mr-2" />
                                Approve
                              </DropdownMenuItem>
                              <DropdownMenuItem
                                className="text-red-600 flex items-center"
                                onClick={() => handleOpenRejectDialog(employee as PendingEmployee)}
                              >
                                <UserX className="h-4 w-4 mr-2" />
                                Reject
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                      ) : (
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8 hover:bg-gray-100">
                              <MoreHorizontal className="h-4 w-4" />
                              <span className="sr-only">Open menu</span>
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" className="w-48">
                            <DropdownMenuLabel>Actions</DropdownMenuLabel>
                            <DropdownMenuItem className="flex items-center">
                              <Eye className="h-4 w-4 mr-2" />
                              View details
                            </DropdownMenuItem>
                            <DropdownMenuItem className="flex items-center">
                              <RefreshCw className="h-4 w-4 mr-2" />
                              Edit employee
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem className="text-red-600 flex items-center">
                              <AlertTriangle className="h-4 w-4 mr-2" />
                              Deactivate
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Approve Dialog */}
      <CommentDialog
        isOpen={showApproveDialog}
        onClose={() => setShowApproveDialog(false)}
        onSubmit={handleApprove}
        title="Approve Employee"
        description={`Are you sure you want to approve ${selectedEmployee?.name}? This will move them to the active employees list.`}
        type="approve"
        entityName={selectedEmployee?.name || ""}
      />

      {/* Reject Dialog */}
      <CommentDialog
        isOpen={showRejectDialog}
        onClose={() => setShowRejectDialog(false)}
        onSubmit={handleReject}
        title="Reject Employee"
        description={`Are you sure you want to reject ${selectedEmployee?.name}? Please provide a reason for rejection.`}
        type="reject"
        entityName={selectedEmployee?.name || ""}
      />
    </>
  )
}
