"use client"

import { useRouter } from "next/navigation"
import { useEffect } from "react"

interface LogoutHandlerProps {
  redirectTo?: string
}

export default function LogoutHandler({ redirectTo = "/login" }: LogoutHandlerProps) {
  const router = useRouter()

  useEffect(() => {
    const handleLogout = async () => {
      try {
        // Call the logout API route
        await fetch("/logout", { method: "GET" })

        // Clear any client-side state if needed
        // For example, if using a state management library:
        // dispatch(clearUserState());

        // Redirect to login page
        router.push(redirectTo)
      } catch (error) {
        console.error("Logout failed:", error)
        // Fallback: redirect anyway
        router.push(redirectTo)
      }
    }

    handleLogout()
  }, [router, redirectTo])

  return (
    <div className="flex items-center justify-center min-h-screen">
      <div className="text-center">
        <h1 className="text-2xl font-bold mb-4">Logging out...</h1>
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-gray-900 mx-auto"></div>
      </div>
    </div>
  )
}
