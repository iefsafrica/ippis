"use client"

import { useEffect, useRef } from "react"
import { cn } from "@/lib/utils"
import { Chart } from "chart.js/auto"

interface DashboardChartProps {
  className?: string
  data?: {
    labels: string[]
    datasets: {
      label: string
      data: number[]
    }[]
  }
}

export function DashboardChart({ className, data }: DashboardChartProps) {
  const chartRef = useRef<HTMLCanvasElement>(null)
  const chartInstanceRef = useRef<Chart | null>(null)

  useEffect(() => {
    if (!chartRef.current || !data) return

    // Destroy previous chart instance if it exists
    if (chartInstanceRef.current) {
      chartInstanceRef.current.destroy()
    }

    const ctx = chartRef.current.getContext("2d")
    if (!ctx) return

    // Create chart with safe defaults if data is missing
    const labels = data.labels || []
    const datasets = data.datasets || []

    // Create the chart
    chartInstanceRef.current = new Chart(ctx, {
      type: "bar",
      data: {
        labels,
        datasets: datasets.map((dataset, index) => ({
          label: dataset.label,
          data: dataset.data,
          backgroundColor:
            index === 0
              ? "rgba(34, 197, 94, 0.7)" // Green for registrations
              : "rgba(59, 130, 246, 0.7)", // Blue for verifications
          borderColor: index === 0 ? "rgb(34, 197, 94)" : "rgb(59, 130, 246)",
          borderWidth: 1,
          borderRadius: 6,
          barPercentage: 0.6,
          categoryPercentage: 0.7,
        })),
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          y: {
            beginAtZero: true,
            grid: {
              color: "rgba(0, 0, 0, 0.05)",
              drawBorder: false,
            },
            ticks: {
              padding: 10,
              color: "rgba(0, 0, 0, 0.6)",
            },
          },
          x: {
            grid: {
              display: false,
              drawBorder: false,
            },
            ticks: {
              padding: 10,
              color: "rgba(0, 0, 0, 0.6)",
            },
          },
        },
        plugins: {
          legend: {
            position: "top",
            labels: {
              usePointStyle: true,
              padding: 20,
              boxWidth: 8,
            },
          },
          tooltip: {
            backgroundColor: "rgba(255, 255, 255, 0.9)",
            titleColor: "#000",
            bodyColor: "#000",
            borderColor: "rgba(0, 0, 0, 0.1)",
            borderWidth: 1,
            padding: 12,
            boxPadding: 6,
            usePointStyle: true,
            callbacks: {
              label: (context) => {
                let label = context.dataset.label || ""
                if (label) {
                  label += ": "
                }
                if (context.parsed.y !== null) {
                  label += context.parsed.y
                }
                return label
              },
            },
          },
        },
        interaction: {
          mode: "index",
          intersect: false,
        },
        animation: {
          duration: 1000,
        },
      },
    })

    // Cleanup function
    return () => {
      if (chartInstanceRef.current) {
        chartInstanceRef.current.destroy()
      }
    }
  }, [data])

  if (!data) {
    return (
      <div className="h-[300px] flex items-center justify-center text-gray-500">
        <p>No chart data available</p>
      </div>
    )
  }

  return (
    <div className={cn("h-[300px] w-full", className)}>
      <canvas ref={chartRef} />
    </div>
  )
}
