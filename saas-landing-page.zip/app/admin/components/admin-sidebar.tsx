"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import Image from "next/image"
import { cn } from "@/lib/utils"
import {
  LayoutDashboard,
  Users,
  UserCog,
  Upload,
  FileText,
  BarChart3,
  Settings,
  Database,
  ChevronLeft,
  ChevronRight,
  LogOut,
  HelpCircle,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

export function AdminSidebar() {
  const pathname = usePathname()
  const [collapsed, setCollapsed] = useState(false)

  const navItems = [
    {
      title: "Dashboard",
      href: "/admin",
      icon: LayoutDashboard,
    },
    {
      title: "Employees List",
      href: "/admin/employees",
      icon: Users,
    },
    {
      title: "Pending Employees",
      href: "/admin/pending",
      icon: UserCog,
    },
    {
      title: "Import Employees",
      href: "/admin/import",
      icon: Upload,
    },
    {
      title: "Documents",
      href: "/admin/documents",
      icon: FileText,
    },
    {
      title: "Reports",
      href: "/admin/reports",
      icon: BarChart3,
    },
    {
      title: "Settings",
      href: "/admin/settings",
      icon: Settings,
    },
    {
      title: "Backup Database",
      href: "/admin/backup",
      icon: Database,
    },
  ]

  return (
    <div
      className={cn(
        "bg-white border-r border-gray-200 flex flex-col transition-all duration-300 ease-in-out",
        collapsed ? "w-[70px]" : "w-[250px]",
      )}
    >
      <div className="p-4 border-b border-gray-200 flex items-center justify-between">
        <div className={cn("flex items-center", collapsed ? "justify-center" : "justify-start")}>
          <Image
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Coat_of_arms_of_Nigeria.svg-IFrFqiae8fXtNsVx4Ip0AeHFPjj7Mp.png"
            width={32}
            height={32}
            alt="IPPIS Logo"
            className="h-8 w-auto"
          />
          {!collapsed && <span className="ml-2 font-bold text-lg">IPPIS Admin</span>}
        </div>
        <Button
          variant="ghost"
          size="icon"
          className="h-8 w-8"
          onClick={() => setCollapsed(!collapsed)}
          aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
        >
          {collapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
        </Button>
      </div>

      <div className="flex-1 py-6 flex flex-col justify-between">
        <nav className="px-2 space-y-1">
          <TooltipProvider delayDuration={0}>
            {navItems.map((item) => {
              const isActive = pathname === item.href
              return (
                <Tooltip key={item.href} delayDuration={collapsed ? 100 : 1000000}>
                  <TooltipTrigger asChild>
                    <Link
                      href={item.href}
                      className={cn(
                        "flex items-center px-3 py-2 rounded-md text-sm font-medium transition-colors",
                        isActive ? "bg-green-50 text-green-700" : "text-gray-700 hover:bg-gray-100 hover:text-gray-900",
                      )}
                    >
                      <item.icon className={cn("h-5 w-5", isActive ? "text-green-700" : "text-gray-500")} />
                      {!collapsed && <span className="ml-3">{item.title}</span>}
                    </Link>
                  </TooltipTrigger>
                  {collapsed && <TooltipContent side="right">{item.title}</TooltipContent>}
                </Tooltip>
              )
            })}
          </TooltipProvider>
        </nav>

        <div className="px-2 space-y-1 mt-6">
          <TooltipProvider delayDuration={0}>
            <Tooltip delayDuration={collapsed ? 100 : 1000000}>
              <TooltipTrigger asChild>
                <Link
                  href="/admin/help"
                  className="flex items-center px-3 py-2 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-100 hover:text-gray-900 transition-colors"
                >
                  <HelpCircle className="h-5 w-5 text-gray-500" />
                  {!collapsed && <span className="ml-3">Help & Support</span>}
                </Link>
              </TooltipTrigger>
              {collapsed && <TooltipContent side="right">Help & Support</TooltipContent>}
            </Tooltip>

            <Tooltip delayDuration={collapsed ? 100 : 1000000}>
              <TooltipTrigger asChild>
                <Link
                  href="/admin/logout"
                  className="flex items-center px-3 py-2 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-100 hover:text-gray-900 transition-colors"
                >
                  <LogOut className="h-5 w-5 text-gray-500" />
                  {!collapsed && <span className="ml-3">Logout</span>}
                </Link>
              </TooltipTrigger>
              {collapsed && <TooltipContent side="right">Logout</TooltipContent>}
            </Tooltip>
          </TooltipProvider>
        </div>
      </div>
    </div>
  )
}
