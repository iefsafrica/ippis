import { CheckCircle, AlertTriangle, FileText, UserPlus, RefreshCw, Clock } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { cn } from "@/lib/utils"

interface Activity {
  action: string
  user: string
  time: string
  description: string
}

interface ActivityFeedProps {
  activities: Activity[]
}

export function ActivityFeed({ activities = [] }: ActivityFeedProps) {
  const getActivityIcon = (action: string) => {
    switch (action) {
      case "approved":
        return <CheckCircle className="h-5 w-5 text-green-500" />
      case "rejected":
        return <AlertTriangle className="h-5 w-5 text-red-500" />
      case "verified":
        return <FileText className="h-5 w-5 text-blue-500" />
      case "added":
        return <UserPlus className="h-5 w-5 text-purple-500" />
      case "updated":
        return <RefreshCw className="h-5 w-5 text-amber-500" />
      case "pending":
        return <Clock className="h-5 w-5 text-gray-500" />
      default:
        return <FileText className="h-5 w-5 text-gray-500" />
    }
  }

  const getActivityColor = (action: string) => {
    switch (action) {
      case "approved":
        return "bg-green-100"
      case "rejected":
        return "bg-red-100"
      case "verified":
        return "bg-blue-100"
      case "added":
        return "bg-purple-100"
      case "updated":
        return "bg-amber-100"
      case "pending":
        return "bg-gray-100"
      default:
        return "bg-gray-100"
    }
  }

  return (
    <div className="space-y-6">
      {activities.length === 0 ? (
        <div className="text-center py-8 text-muted-foreground">No recent activity found.</div>
      ) : (
        <div className="relative">
          {/* Timeline line */}
          <div className="absolute left-6 top-0 bottom-0 w-0.5 bg-gray-100"></div>

          {activities.map((activity, index) => (
            <div key={index} className="flex items-start gap-4 relative mb-6">
              <div className={cn("p-2 rounded-full z-10", getActivityColor(activity.action))}>
                {getActivityIcon(activity.action)}
              </div>
              <div className="flex-1 bg-gray-50 rounded-lg p-4 shadow-sm hover:shadow-md transition-shadow">
                <div className="flex items-start justify-between">
                  <div className="font-medium text-gray-800">{activity.description}</div>
                  <div className="text-xs text-muted-foreground bg-white px-2 py-1 rounded-full">{activity.time}</div>
                </div>
                <div className="flex items-center mt-2">
                  <Avatar className="h-6 w-6 mr-2">
                    <AvatarImage src={`/placeholder.svg?height=24&width=24`} alt={activity.user} />
                    <AvatarFallback className="text-xs">{activity.user.substring(0, 2).toUpperCase()}</AvatarFallback>
                  </Avatar>
                  <span className="text-sm text-muted-foreground">{activity.user}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
