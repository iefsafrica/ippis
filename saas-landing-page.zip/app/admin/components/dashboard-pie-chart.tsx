"use client"

import { useEffect, useRef } from "react"
import { Chart, type ChartConfiguration } from "chart.js/auto"

interface DashboardPieChartProps {
  data: { status: string; count: number }[]
}

export function DashboardPieChart({ data }: DashboardPieChartProps) {
  const chartRef = useRef<HTMLCanvasElement>(null)
  const chartInstanceRef = useRef<Chart | null>(null)

  useEffect(() => {
    if (!chartRef.current || !data || data.length === 0) return

    // Destroy previous chart instance if it exists
    if (chartInstanceRef.current) {
      chartInstanceRef.current.destroy()
    }

    const ctx = chartRef.current.getContext("2d")
    if (!ctx) return

    // Define colors for each status
    const colors = {
      Active: {
        backgroundColor: "rgba(34, 197, 94, 0.7)",
        borderColor: "rgb(34, 197, 94)",
      },
      Pending: {
        backgroundColor: "rgba(245, 158, 11, 0.7)",
        borderColor: "rgb(245, 158, 11)",
      },
      Inactive: {
        backgroundColor: "rgba(239, 68, 68, 0.7)",
        borderColor: "rgb(239, 68, 68)",
      },
      Verification: {
        backgroundColor: "rgba(59, 130, 246, 0.7)",
        borderColor: "rgb(59, 130, 246)",
      },
    }

    // Prepare data for the chart
    const labels = data.map((item) => item.status)
    const values = data.map((item) => item.count)
    const backgroundColors = data.map((item) => {
      const color = colors[item.status as keyof typeof colors]
      return color ? color.backgroundColor : "rgba(156, 163, 175, 0.7)" // Default gray
    })
    const borderColors = data.map((item) => {
      const color = colors[item.status as keyof typeof colors]
      return color ? color.borderColor : "rgb(156, 163, 175)" // Default gray
    })

    // Create the chart configuration
    const config: ChartConfiguration = {
      type: "doughnut",
      data: {
        labels,
        datasets: [
          {
            data: values,
            backgroundColor: backgroundColors,
            borderColor: borderColors,
            borderWidth: 1,
            hoverOffset: 4,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: true,
        plugins: {
          legend: {
            position: "bottom",
            labels: {
              usePointStyle: true,
              padding: 15,
            },
          },
          tooltip: {
            callbacks: {
              label: (context) => {
                const label = context.label || ""
                const value = context.raw as number
                const total = (context.dataset.data as number[]).reduce((a, b) => (a as number) + (b as number), 0)
                const percentage = Math.round((value / total) * 100)
                return `${label}: ${value} (${percentage}%)`
              },
            },
          },
        },
        cutout: "70%",
        animation: {
          animateScale: true,
          animateRotate: true,
        },
      },
    }

    // Create the chart
    chartInstanceRef.current = new Chart(ctx, config)

    // Cleanup function
    return () => {
      if (chartInstanceRef.current) {
        chartInstanceRef.current.destroy()
      }
    }
  }, [data])

  if (!data || data.length === 0) {
    return (
      <div className="h-[200px] flex items-center justify-center text-gray-500">
        <p>No chart data available</p>
      </div>
    )
  }

  return (
    <div className="h-[200px] w-full">
      <canvas ref={chartRef} />
    </div>
  )
}
