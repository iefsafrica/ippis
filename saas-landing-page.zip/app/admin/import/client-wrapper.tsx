"use client"

import dynamic from "next/dynamic"
import { Suspense } from "react"

// Import the content component with SSR disabled
const ImportContent = dynamic(() => import("./import-content"), {
  ssr: false,
  loading: () => <div className="p-8 text-center">Loading import functionality...</div>,
})

export default function ClientWrapper() {
  return (
    <Suspense fallback={<div className="p-8 text-center">Loading import functionality...</div>}>
      <ImportContent />
    </Suspense>
  )
}
