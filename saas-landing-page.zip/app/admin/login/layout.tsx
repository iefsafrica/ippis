import type React from "react"
export default function AdminLoginLayout({
  children,
}: {
  children: React.ReactNode
}) {
  // This is a completely standalone layout that doesn't inherit from admin layout
  return <>{children}</>
}
