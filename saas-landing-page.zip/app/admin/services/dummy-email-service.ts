// A completely new implementation that doesn't rely on initialization

// Define the interface for email options
interface EmailOptions {
  to: string
  subject: string
  body: string
}

// Define the interface for email results
interface EmailResult {
  success: boolean
  messageId?: string
  error?: string
}

// Define the email template types
export type EmailTemplate =
  | "document_approved"
  | "document_rejected"
  | "registration_approved"
  | "registration_rejected"
  | "profile_update_required"

// Create a simple dummy email service
const DummyEmailService = {
  // This is the initialize method that's causing problems
  initialize: () => {
    console.log("DummyEmailService initialize called")
    return true
  },

  // Send an email
  sendEmail: async (
    to: string,
    subject: string,
    template: EmailTemplate,
    data: Record<string, any>,
  ): Promise<EmailResult> => {
    console.log(`[DummyEmailService] Sending email to ${to} with template ${template}`)
    console.log("[DummyEmailService] Email data:", data)

    // Simulate a delay
    await new Promise((resolve) => setTimeout(resolve, 500))

    // Always return success
    return {
      success: true,
      messageId: `dummy_msg_${Date.now()}`,
    }
  },

  // Send an approval notification
  sendApprovalNotification: async (
    email: string,
    name: string,
    type: string,
    comments: string,
    link: string,
  ): Promise<EmailResult> => {
    console.log(`[DummyEmailService] Sending approval notification to ${email}`)

    // Simulate a delay
    await new Promise((resolve) => setTimeout(resolve, 500))

    // Always return success
    return {
      success: true,
      messageId: `dummy_approval_${Date.now()}`,
    }
  },

  // Send a rejection notification
  sendRejectionNotification: async (
    email: string,
    name: string,
    type: string,
    comments: string,
    link: string,
  ): Promise<EmailResult> => {
    console.log(`[DummyEmailService] Sending rejection notification to ${email}`)

    // Simulate a delay
    await new Promise((resolve) => setTimeout(resolve, 500))

    // Always return success
    return {
      success: true,
      messageId: `dummy_rejection_${Date.now()}`,
    }
  },
}

// Export the dummy service
export { DummyEmailService }

// Also export it as EmailService for compatibility
export const EmailService = DummyEmailService

// Export as default
export default DummyEmailService
