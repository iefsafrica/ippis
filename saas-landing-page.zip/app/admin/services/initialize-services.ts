// This file initializes all services on the client side
import { notificationEmailService } from "./notification-email-service"

export function initializeServices() {
  console.log("Initializing all services...")

  // Initialize email service
  try {
    notificationEmailService.initialize()
    console.log("Email service initialized successfully")
  } catch (error) {
    console.error("Failed to initialize email service:", error)
  }

  // Initialize other services as needed

  console.log("All services initialized")
}

// Export a default function for dynamic imports
export default initializeServices
