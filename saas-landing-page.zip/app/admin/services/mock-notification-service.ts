// Mock notification data and service functions

export interface Notification {
  id: string
  title: string
  message: string
  timestamp: Date
  read: boolean
  type: "info" | "warning" | "success" | "error"
  link?: string
}

// Generate mock notifications
export function generateMockNotifications(count = 5): Notification[] {
  const types: ("info" | "warning" | "success" | "error")[] = ["info", "warning", "success", "error"]
  const titles = [
    "New employee registration",
    "Document verification required",
    "System update",
    "Backup completed",
    "Security alert",
    "Payroll processed",
    "Leave request",
    "New policy update",
  ]

  const messages = [
    "A new employee has registered and requires approval.",
    "New documents have been uploaded and need verification.",
    "The system will undergo maintenance tonight at 10 PM.",
    "Database backup has been completed successfully.",
    "Multiple failed login attempts detected.",
    "Monthly payroll has been processed successfully.",
    "An employee has requested leave approval.",
    "New government policy update requires action.",
  ]

  return Array.from({ length: count }).map((_, index) => {
    const type = types[Math.floor(Math.random() * types.length)]
    const titleIndex = Math.floor(Math.random() * titles.length)

    // Create a random date within the last 7 days
    const date = new Date()
    date.setDate(date.getDate() - Math.floor(Math.random() * 7))
    date.setHours(Math.floor(Math.random() * 24), Math.floor(Math.random() * 60))

    return {
      id: `notification-${index + 1}`,
      title: titles[titleIndex],
      message: messages[titleIndex],
      timestamp: date,
      read: Math.random() > 0.7, // 30% chance of being read
      type,
      link:
        Math.random() > 0.5
          ? `/admin/${["employees", "documents", "pending", "settings"][Math.floor(Math.random() * 4)]}`
          : undefined,
    }
  })
}

// Mock notification service
export const mockNotificationService = {
  getNotifications: (): Promise<Notification[]> => {
    return Promise.resolve(generateMockNotifications(8))
  },

  markAsRead: (id: string): Promise<void> => {
    console.log(`Marking notification ${id} as read`)
    return Promise.resolve()
  },

  markAllAsRead: (): Promise<void> => {
    console.log("Marking all notifications as read")
    return Promise.resolve()
  },

  deleteNotification: (id: string): Promise<void> => {
    console.log(`Deleting notification ${id}`)
    return Promise.resolve()
  },

  clearAllNotifications: (): Promise<void> => {
    console.log("Clearing all notifications")
    return Promise.resolve()
  },
}
