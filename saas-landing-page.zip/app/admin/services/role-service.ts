import type { AuthUser, Permission, Role, UserRole } from "@/app/types/auth-types"

// Default roles with their permissions
const DEFAULT_ROLES: Role[] = [
  {
    id: "super_admin",
    name: "Super Administrator",
    description: "Full system access with all permissions",
    permissions: [
      "view_employees",
      "create_employees",
      "edit_employees",
      "delete_employees",
      "approve_employees",
      "reject_employees",
      "view_documents",
      "upload_documents",
      "verify_documents",
      "reject_documents",
      "manage_roles",
      "view_reports",
      "export_data",
      "manage_settings",
      "backup_database",
      "import_data",
    ],
    isDefault: true,
  },
  {
    id: "admin",
    name: "Administrator",
    description: "Administrative access with most permissions",
    permissions: [
      "view_employees",
      "create_employees",
      "edit_employees",
      "approve_employees",
      "reject_employees",
      "view_documents",
      "upload_documents",
      "verify_documents",
      "reject_documents",
      "view_reports",
      "export_data",
      "manage_settings",
      "backup_database",
      "import_data",
    ],
    isDefault: true,
  },
  {
    id: "editor",
    name: "Editor",
    description: "Can edit and manage content but not system settings",
    permissions: [
      "view_employees",
      "create_employees",
      "edit_employees",
      "approve_employees",
      "reject_employees",
      "view_documents",
      "upload_documents",
      "verify_documents",
      "reject_documents",
      "view_reports",
      "export_data",
    ],
    isDefault: true,
  },
  {
    id: "viewer",
    name: "Viewer",
    description: "Read-only access to system data",
    permissions: ["view_employees", "view_documents", "view_reports"],
    isDefault: true,
  },
]

// In-memory storage for roles (in a real app, this would be in a database)
let roles: Role[] = [...DEFAULT_ROLES]

export class RoleService {
  // Get all roles
  static getRoles(): Role[] {
    return roles
  }

  // Get a role by ID
  static getRole(id: UserRole): Role | undefined {
    return roles.find((role) => role.id === id)
  }

  // Create a new role
  static createRole(role: Omit<Role, "id">): Role {
    const id = role.name.toLowerCase().replace(/\s+/g, "_")
    const newRole: Role = { ...role, id: id as UserRole }
    roles.push(newRole)
    return newRole
  }

  // Update an existing role
  static updateRole(id: UserRole, updates: Partial<Omit<Role, "id">>): Role | null {
    const index = roles.findIndex((role) => role.id === id)
    if (index === -1) return null

    const updatedRole = { ...roles[index], ...updates }
    roles[index] = updatedRole
    return updatedRole
  }

  // Delete a role
  static deleteRole(id: UserRole): boolean {
    // Don't allow deletion of default roles
    const role = this.getRole(id)
    if (role?.isDefault) return false

    const initialLength = roles.length
    roles = roles.filter((role) => role.id !== id)
    return roles.length < initialLength
  }

  // Reset to default roles
  static resetToDefault(): void {
    roles = [...DEFAULT_ROLES]
  }

  // Check if a user has a specific permission
  static hasPermission(user: AuthUser, permission: Permission): boolean {
    // For development/testing, always return true to avoid permission issues
    return true

    // In production, use this code instead:
    /*
    // If user has explicit permissions, check those first
    if (user.permissions) {
      return user.permissions.includes(permission)
    }
    
    // Otherwise check role-based permissions
    const role = this.getRole(user.role)
    return role ? role.permissions.includes(permission) : false
    */
  }
}
