import type { Document } from "./mock-data-service"
import { EmailService } from "./email-service"

// Simulate API delay
const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms))

// In-memory storage for documents
let documents: Document[] = []

// Helper function to generate a unique ID
const generateId = (prefix: string) => {
  return `${prefix}${Math.floor(10000 + Math.random() * 90000)}`
}

// Mock API service for Documents
export const DocumentService = {
  // Initialize with data
  initialize: (initialDocuments: Document[]) => {
    documents = [...initialDocuments]
  },

  // Get all documents with filtering
  getDocuments: async (filters?: {
    search?: string
    status?: string
    type?: string
    employeeId?: string
  }): Promise<Document[]> => {
    await delay(500)

    let result = [...documents]

    if (filters) {
      if (filters.search) {
        const searchTerm = filters.search.toLowerCase()
        result = result.filter(
          (doc) =>
            doc.name.toLowerCase().includes(searchTerm) ||
            doc.employeeName.toLowerCase().includes(searchTerm) ||
            doc.id.toLowerCase().includes(searchTerm) ||
            doc.employeeId.toLowerCase().includes(searchTerm),
        )
      }

      if (filters.status && filters.status !== "all") {
        result = result.filter((doc) => doc.status === filters.status)
      }

      if (filters.type && filters.type !== "all") {
        result = result.filter((doc) => doc.type === filters.type)
      }

      if (filters.employeeId) {
        result = result.filter((doc) => doc.employeeId === filters.employeeId)
      }
    }

    return result
  },

  // Get document by ID
  getDocumentById: async (id: string): Promise<Document | null> => {
    await delay(300)
    return documents.find((doc) => doc.id === id) || null
  },

  // Get documents by employee ID
  getDocumentsByEmployeeId: async (employeeId: string): Promise<Document[]> => {
    await delay(400)
    return documents.filter((doc) => doc.employeeId === employeeId)
  },

  // Add new document
  addDocument: async (document: Omit<Document, "id">): Promise<Document> => {
    await delay(700)
    const newId = generateId("DOC")
    const newDocument = { ...document, id: newId }
    documents = [...documents, newDocument]
    return newDocument
  },

  // Add documents from registration form
  addDocumentsFromRegistration: async (
    employeeId: string,
    employeeName: string,
    files: Record<string, File | null>,
  ): Promise<Document[]> => {
    await delay(1000)

    const newDocuments: Document[] = []

    // Map file keys to document types
    const fileTypeMap: Record<string, Document["type"]> = {
      appointmentLetter: "Appointment Letter",
      educationalCertificates: "Educational Certificate",
      promotionLetter: "Promotion Letter",
      otherDocuments: "Other Document",
      profileImage: "Profile Image",
      signature: "Signature",
    }

    console.log("Adding documents for employee:", employeeId, employeeName)
    console.log("Files received:", Object.keys(files).filter((key) => files[key] !== null).length)

    // Create a document for each file
    for (const [key, file] of Object.entries(files)) {
      if (file) {
        const docType = fileTypeMap[key]
        if (docType) {
          const newDoc: Document = {
            id: generateId("DOC"),
            name: `${docType} - ${employeeName}`,
            type: docType,
            employeeName,
            employeeId,
            status: "pending",
            uploadDate: new Date().toISOString().split("T")[0],
            fileSize: file.size,
            fileType: file.type,
            fileUrl: URL.createObjectURL(file), // This would be a server URL in a real app
          }

          newDocuments.push(newDoc)
          documents = [...documents, newDoc]

          console.log(`Added document: ${newDoc.name} (${newDoc.id})`)
        }
      }
    }

    // Send notification email about document upload
    try {
      if (newDocuments.length > 0) {
        await EmailService.sendEmail("admin@ippis.gov.ng", "New Documents Uploaded", "document_upload", {
          employeeName,
          employeeId,
          documentCount: newDocuments.length,
          documentTypes: newDocuments.map((doc) => doc.type).join(", "),
        })
      }
    } catch (error) {
      console.error("Failed to send document notification email:", error)
    }

    return newDocuments
  },

  // Update document status
  updateDocumentStatus: async (
    id: string,
    status: "verified" | "pending" | "rejected",
    comment?: string,
  ): Promise<Document> => {
    await delay(500)
    const index = documents.findIndex((doc) => doc.id === id)
    if (index === -1) throw new Error("Document not found")

    const updatedDocument = { ...documents[index], status, comment }
    documents = [...documents.slice(0, index), updatedDocument, ...documents.slice(index + 1)]

    // Send email notification about document status change
    try {
      // In a real app, we would get the employee's email from a user service
      // For now, we'll just log it
      console.log(`Document ${id} status updated to ${status}. Email notification would be sent.`)

      // If we had the employee's email:
      // await EmailService.sendEmail(
      //   employee.email,
      //   `Document ${status === 'verified' ? 'Approved' : 'Rejected'}`,
      //   `document_${status}`,
      //   {
      //     documentName: updatedDocument.name,
      //     comment: comment || '',
      //   }
      // );
    } catch (error) {
      console.error(`Failed to send document ${status} email:`, error)
    }

    return updatedDocument
  },

  // Delete document
  deleteDocument: async (id: string): Promise<boolean> => {
    await delay(500)
    const index = documents.findIndex((doc) => doc.id === id)
    if (index === -1) return false

    documents = [...documents.slice(0, index), ...documents.slice(index + 1)]
    return true
  },

  // Verify all documents for an employee
  verifyAllDocumentsForEmployee: async (employeeId: string, comment?: string): Promise<Document[]> => {
    await delay(800)

    const employeeDocs = documents.filter((doc) => doc.employeeId === employeeId)
    const updatedDocs: Document[] = []

    for (const doc of employeeDocs) {
      if (doc.status === "pending") {
        const index = documents.findIndex((d) => d.id === doc.id)
        const updatedDoc = { ...doc, status: "verified", comment }
        documents[index] = updatedDoc
        updatedDocs.push(updatedDoc)
      } else {
        updatedDocs.push(doc)
      }
    }

    // Send email notification about bulk document verification
    try {
      const verifiedCount = updatedDocs.filter((doc) => doc.status === "verified").length
      if (verifiedCount > 0) {
        console.log(`${verifiedCount} documents verified for employee ${employeeId}. Email notification would be sent.`)
      }
    } catch (error) {
      console.error("Failed to send bulk verification email:", error)
    }

    return updatedDocs
  },

  // Reject all documents for an employee
  rejectAllDocumentsForEmployee: async (employeeId: string, comment?: string): Promise<Document[]> => {
    await delay(800)

    const employeeDocs = documents.filter((doc) => doc.employeeId === employeeId)
    const updatedDocs: Document[] = []

    for (const doc of employeeDocs) {
      if (doc.status === "pending") {
        const index = documents.findIndex((d) => d.id === doc.id)
        const updatedDoc = { ...doc, status: "rejected", comment }
        documents[index] = updatedDoc
        updatedDocs.push(updatedDoc)
      } else {
        updatedDocs.push(doc)
      }
    }

    // Send email notification about bulk document rejection
    try {
      const rejectedCount = updatedDocs.filter((doc) => doc.status === "rejected").length
      if (rejectedCount > 0) {
        console.log(`${rejectedCount} documents rejected for employee ${employeeId}. Email notification would be sent.`)
      }
    } catch (error) {
      console.error("Failed to send bulk rejection email:", error)
    }

    return updatedDocs
  },
}

// Initialize with empty documents array
DocumentService.initialize([])
