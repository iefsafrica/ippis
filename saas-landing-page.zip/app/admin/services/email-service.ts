// Import the dummy email service
import { DummyEmailService } from "./dummy-email-service"

// Re-export the dummy service as EmailService
export const EmailService = DummyEmailService

// Also export it as default
export default DummyEmailService

// Export the email template type
export type { EmailTemplate } from "./dummy-email-service"

// For backward compatibility, also export these
export const emailService = DummyEmailService
export const EmailServiceOld = DummyEmailService
