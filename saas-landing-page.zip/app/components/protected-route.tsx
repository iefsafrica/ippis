"use client"

import type React from "react"
import { useAuth } from "../contexts/auth-context"
import type { Permission } from "../types/auth-types"
import { useRouter } from "next/navigation"
import { useEffect, useState } from "react"
import { Loader2 } from "lucide-react"

interface ProtectedRouteProps {
  children: React.ReactNode
  requiredPermission?: Permission
  fallbackUrl?: string
}

export default function ProtectedRoute({ children, requiredPermission, fallbackUrl = "/login" }: ProtectedRouteProps) {
  const { user, loading, hasPermission } = useAuth()
  const router = useRouter()
  const [authorized, setAuthorized] = useState<boolean | null>(null)

  useEffect(() => {
    // Wait until auth state is loaded
    if (!loading) {
      // Check if user is logged in
      if (!user) {
        router.push(fallbackUrl)
        setAuthorized(false)
        return
      }

      // If a specific permission is required, check for it
      if (requiredPermission && !hasPermission(requiredPermission)) {
        router.push("/admin") // Redirect to dashboard
        setAuthorized(false)
        return
      }

      // User is authorized
      setAuthorized(true)
    }
  }, [user, loading, requiredPermission, hasPermission, router, fallbackUrl])

  // Show loading state
  if (loading || authorized === null) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-green-600" />
        <span className="ml-2 text-lg">Checking permissions...</span>
      </div>
    )
  }

  // If not authorized, don't render children (will redirect)
  if (!authorized) {
    return null
  }

  // Render children if authorized
  return <>{children}</>
}
