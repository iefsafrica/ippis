"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"
import type { AuthUser, Permission, UserRole } from "../types/auth-types"
import { RoleService } from "../admin/services/role-service"
import { useToast } from "@/hooks/use-toast"

// Mock function to get the current user - in a real app, this would call your API
const getCurrentUser = async (): Promise<AuthUser | null> => {
  // Simulate API call
  await new Promise((resolve) => setTimeout(resolve, 500))

  // For demo purposes, return a mock user with all permissions
  // In a real app, this would fetch from your authentication service
  return {
    id: "user-1",
    name: "Admin User",
    username: "admin", // Added username field
    email: "admin@ippis.gov.ng",
    role: "admin",
    permissions: [
      "view_employees",
      "create_employees",
      "edit_employees",
      "delete_employees",
      "approve_employees",
      "reject_employees",
      "view_documents",
      "upload_documents",
      "verify_documents",
      "reject_documents",
      "manage_roles",
      "view_reports",
      "export_data",
      "manage_settings",
      "backup_database",
      "import_data",
    ],
    avatar: "/placeholder.svg?height=32&width=32",
    lastLogin: new Date().toISOString(),
  }
}

interface AuthContextType {
  user: AuthUser | null
  loading: boolean
  hasPermission: (permission: Permission) => boolean
  login: (username: string, password: string) => Promise<boolean> // Updated to use username
  logout: () => Promise<void>
  updateUserRole: (role: UserRole) => Promise<void>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null)
  const [loading, setLoading] = useState(true)
  const { toast } = useToast()

  // Load user on initial mount
  useEffect(() => {
    const loadUser = async () => {
      try {
        const currentUser = await getCurrentUser()
        setUser(currentUser)
      } catch (error) {
        console.error("Failed to load user:", error)
      } finally {
        setLoading(false)
      }
    }

    loadUser()
  }, [])

  // Check if user has a specific permission
  const hasPermission = (permission: Permission): boolean => {
    if (!user) return false

    // If user has explicit permissions array, check it
    if (user.permissions) {
      return user.permissions.includes(permission)
    }

    // Otherwise fall back to role-based check
    return RoleService.hasPermission(user, permission)
  }

  // Login function - updated to use username
  const login = async (username: string, password: string): Promise<boolean> => {
    setLoading(true)
    try {
      // In a real app, this would validate credentials with your API
      if (username && password) {
        // Mock successful login
        const user = await getCurrentUser()
        setUser(user)
        return true
      }
      return false
    } catch (error) {
      console.error("Login failed:", error)
      return false
    } finally {
      setLoading(false)
    }
  }

  // Logout function
  const logout = async (): Promise<void> => {
    setLoading(true)
    try {
      // In a real app, this would call your logout API
      await new Promise((resolve) => setTimeout(resolve, 300))
      setUser(null)
    } catch (error) {
      console.error("Logout failed:", error)
    } finally {
      setLoading(false)
    }
  }

  // Update user role
  const updateUserRole = async (role: UserRole): Promise<void> => {
    if (!user) return

    try {
      // In a real app, this would call your API to update the user's role
      await new Promise((resolve) => setTimeout(resolve, 300))
      setUser({ ...user, role })

      toast({
        title: "Role updated",
        description: `Your role has been updated to ${role}`,
      })
    } catch (error) {
      console.error("Failed to update role:", error)
      toast({
        title: "Update failed",
        description: "Failed to update your role",
        variant: "destructive",
      })
    }
  }

  return (
    <AuthContext.Provider value={{ user, loading, hasPermission, login, logout, updateUserRole }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
