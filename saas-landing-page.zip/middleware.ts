import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"

export function middleware(request: NextRequest) {
  // Get the pathname
  const pathname = request.nextUrl.pathname

  // Clone the response
  const response = NextResponse.next()

  // Add the pathname as a header so we can access it in the layout
  response.headers.set("x-pathname", pathname)

  return response
}

export const config = {
  matcher: ["/admin/:path*"],
}
